#!/usr/bin/env python3
"""
Repository Analysis Script
Analyzes repositories for game automation techniques and stores results in database
"""

import sys
import os

# Add core modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'core'))

from core.repository_analyzer import RepositoryAnalyzer
import logging

def main():
    """Main analysis function"""
    
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Repository URLs to analyze
    repo_urls = [
        "https://github.com/paulonteri/play-game-with-computer-vision.git",
        "https://replit.com/@jnossiter1/ContentCaptureAssistant",
        "https://github.com/rasbt/python-machine-learning-book-2nd-edition.git",
        "https://github.com/rasbt/LLMs-from-scratch.git",
        "https://github.com/SerpentAI/SerpentAI.git",
        "https://github.com/SerpentAI/D3DShot.git",
        "https://github.com/SerpentAI/sneakysnek.git",
        "https://github.com/SerpentAI/SerpentAIsaacGameAgentPlugin.git",
        "https://github.com/SerpentAI/SerpentAI-Image.git",
        "https://github.com/rasbt/mlxtend.git",
        "https://github.com/rasbt/gpt-2.git",
        "https://github.com/Lightning-AI/litData.git",
        "https://github.com/Lightning-AI/lightning-thunder.git",
        "https://github.com/Lightning-AI/torchmetrics.git",
        "https://github.com/Lightning-AI/litgpt.git",
        "https://github.com/geo278/SmartAimBot.git",
        "https://github.com/hoangchunghien/ai-isolation-game.git",
        "https://github.com/nosyliam/revolution-macro-updates.git",
        "https://github.com/hoangchunghien/ml-examples.git",
        "https://github.com/openai/gpt-2.git",
        "https://github.com/hoangchunghien/AI-Planning.git",
        "https://github.com/zaheenSyed/Starcraft_AI_Bot_pythonSC.git",
        "https://github.com/zaheenSyed/python-log-parse-example.git",
        "https://github.com/darrylschaefer/ai-text-editor.git",
        "https://github.com/Lightning-AI/litAI.git",
        "https://github.com/KroSheChKa/PandaBot.git"
    ]
    
    print(f"Starting analysis of {len(repo_urls)} repositories...")
    print("This will clone, analyze, and store patterns in the database.")
    print("Each repository is analyzed for:")
    print("- Computer vision techniques")
    print("- Automation patterns") 
    print("- AI/ML approaches")
    print("- Configuration patterns")
    print("- Learning resources")
    print("\nProcessing repositories...\n")
    
    try:
        # Initialize analyzer
        analyzer = RepositoryAnalyzer()
        
        # Analyze repositories
        results = analyzer.analyze_repositories(repo_urls)
        
        # Print results
        print("\n" + "="*60)
        print("REPOSITORY ANALYSIS COMPLETE")
        print("="*60)
        print(f"Total repositories processed: {results['total_repos']}")
        print(f"Successful clones: {results['successful_clones']}")
        print(f"Failed clones: {results['failed_clones']}")
        print(f"Total patterns found: {results['total_patterns_found']}")
        
        if results['processing_errors']:
            print(f"\nProcessing errors:")
            for error in results['processing_errors']:
                print(f"  - {error}")
        
        # Get analysis summary
        summary = analyzer.get_analysis_summary()
        print(f"\n📊 Database Summary:")
        print(f"  Repository status: {summary.get('repository_status', {})}")
        print(f"  Pattern distribution: {summary.get('pattern_distribution', {})}")
        print(f"  Total techniques: {summary.get('total_techniques', 0)}")
        
        print(f"\n✅ Analysis complete! All patterns stored in database.")
        print(f"🤖 Your AI game bot can now learn from these {results['successful_clones']} repositories!")
        
    except Exception as e:
        print(f"❌ Analysis failed: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())