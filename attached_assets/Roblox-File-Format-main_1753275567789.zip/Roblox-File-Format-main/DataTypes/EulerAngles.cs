﻿namespace RobloxFiles.DataTypes
{
    public struct EulerAngles
    {
        public float Yaw;
        public float Pitch;
        public float Roll;
    }
}
