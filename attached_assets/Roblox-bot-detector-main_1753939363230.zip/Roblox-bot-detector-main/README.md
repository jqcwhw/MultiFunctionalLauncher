# Roblox-bot-detector
Read the comments in the python script to figure out how to configure it.\
Fully scanning a big game will take ages.

**This project was just done for fun**

- How does this work?
  - This works by hashing the thumbnails and then comparing the hash to the other thumbnails in that server, if 2 thumbnails have a similar hash it will count them as bots.
- How do i configure this?
  - The only thing you really gotta do is add your cookie to the script, all the other configurations are if you wanna experiement with the script.
- Does this script get false positives?
  - Yes, it can get false positives when 2 people have similar avatars. On games like tower of hell 10% or less are "bots" which is likely a false positive.

Credits to kanibals on discord for improving the script.

Planning on adding this to RoValra at some point
