--[[
last updated 25.11.2024 (DD.MM.YY)
Roblox Chat Bypasser Script

join the discord: https://dsc.gg/vadriftz (paste in browsers/dms)
--]]

loadstring(game:HttpGet("https://raw.githubusercontent.com/vqmpjayZ/Bypass/main/vadrifts.lua"))()
