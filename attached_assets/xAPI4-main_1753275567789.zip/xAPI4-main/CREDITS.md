# xAPI - Credits

**Author**: Eskue (@SQLanguage)  
**Version**: 4.4  

## Credits

### [HashLib](https://devforum.roblox.com/t/open-source-hashlib/416732/1)
By Egor Skriptunoff, boatbomber, and howmanysmall  

### [LZ4](https://gist.github.com/metatablecat/92345df2fd6d450da288c28272555faf)  
By metatablecat  

### [lxm](https://github.com/metatablecat/lxm)  
By metatablecat  

### [Fiu](https://github.com/rce-incorporated/Fiu)  
By rce incorporated (TheGreatSageEqualToHeaven, aka James Napora)  

### [LuauCeption](https://github.com/RealEthanPlayzDev/LuauCeption)  
By RealEthanPlayzDev  

### [RoProxy](https://devforum.roblox.com/t/roproxycom-a-free-rotating-proxy-for-roblox-apis/1508367)  
By okfalse  

### [WebhookProxy](https://webhook.lewisakura.moe/)  
By lewisakura  

---
