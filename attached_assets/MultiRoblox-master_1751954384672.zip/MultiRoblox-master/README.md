# MultiRoblox
## What is MultiRoblox?
MultiRoblox is an open-source program that allows you to open multiple instances of ROBLOX!
## How do I get MultiRoblox?
Simply download from here: https://github.com/Dashbloxx/MultiRoblox/releases
## Where can I recieve support for MultiRoblox?
Recieve support for MultiRoblox here: [https://discord.gg/U28WHhRHUS](https://discord.gg/QBY5ybZUDQ)
