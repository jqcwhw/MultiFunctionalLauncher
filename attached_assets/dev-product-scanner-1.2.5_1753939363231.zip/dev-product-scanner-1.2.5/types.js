class Types {
    static newItem = "newItem";
    static newPrice = "newPrice";
    static newImage = "newImage";
    static newName = "newName";
    static newDescription = "newDescription";
}

module.exports = Types;