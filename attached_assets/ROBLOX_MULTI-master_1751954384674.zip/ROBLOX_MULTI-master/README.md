# ROBLOX_MULTI
Allows you to run/create multiple roblox instances, make sure to run this before joining a game. This was not made by me, it was posted on a v3rmillion a very long time ago and I don't remember who posted it but all credits go to them.
