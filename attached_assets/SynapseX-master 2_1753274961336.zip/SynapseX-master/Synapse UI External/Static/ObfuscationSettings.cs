﻿using System.Reflection;

[assembly: Obfuscation(Feature = "type renaming pattern '__SXINTLIB'.*", Exclude = false)]
[assembly: Obfuscation(Feature = "encrypt symbol names with password vubhIUfr6t3u90N6eNAEvM3NO5A6unxW", Exclude = false)]
[assembly: Obfuscation(Feature = "embed Newtonsoft.Json.dll", Exclude = false)]
[assembly: Obfuscation(Feature = "embed RestSharp.dll", Exclude = false)]
[assembly: Obfuscation(Feature = "embed websocket-sharp.dll", Exclude = false)]
[assembly: Obfuscation(Feature = "code control flow obfuscation", Exclude = false)]