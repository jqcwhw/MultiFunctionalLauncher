
# Bhaggo's Roblox Optimizer (B.R.O) 🔧

![image](https://github.com/user-attachments/assets/ef9d8477-33c2-474f-a59b-d12428ff4524)


simple program created in batch to replace files in roblox that increases fps

Includes instant changing settings such as:
* 


# Instructions:

1. Download "B.R.O.bat" from the releases tab
2. Allow it to be kept on the computer
3. If the "Windows protected your PC" window shows up, click "More info" and then "Run Anyway"
 ![image](https://github.com/user-attachments/assets/82666228-b98e-41a3-99f3-b1127c002f96)
5. You're done with the process. You can always revert the changes through the app and if you want to uninstall, just uninstall the app by deleting the .bat file or the .exe file.

# Preview of the settings
![image](https://github.com/user-attachments/assets/55b60cb1-4ce8-48b3-9eeb-c94fd84d8e4f)


# If you are using Bloxstrap, my files ****WILL**** transfer over to your settings
# Overall setting changes:
* Built-in FPS capper (30fps-240fps)
* Beta performance mode fflag used
* Disable Post FX
* Disable player shadows
* Disables anti aliasing
* (lower overall just gives voxel and less texture quality)

# Super Low GFX setting changes:
* Force voxel lighting (may not work properly with some games)
* Disable shadows
* Disable textures
* Beta Performance mode fflag used
* Enables grey sky to increase performance
* Disables anti aliasing
* Enables longer AFK times
* Sets a cache limit for meshes
* Lower terrain quality (low-poly like)
* Removes grass and grass waving animations
* Removes light tracing
* Sets maximum texture size to 1024
* Disables shaders after increasing quality
* Disables Post Fx

# MAX Graphic file changes:
* Forces future lighting technology
* Higher resolution textures
* Enables "Future is bright phase 3" lighting technology
* Enables water reflection fastflag

