export type SortOrder = "Asc" | "Desc"

export type RestMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE" 