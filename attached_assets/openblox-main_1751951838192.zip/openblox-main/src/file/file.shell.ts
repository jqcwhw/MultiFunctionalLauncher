export const readFile = async (path: string) => {
  throw new Error("Can't read files using cloudflare workers!")
}