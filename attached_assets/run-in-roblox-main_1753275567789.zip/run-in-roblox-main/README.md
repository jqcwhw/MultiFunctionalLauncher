# run-in-roblox

For usage see `run-in-install --help`. The TL;DR is `run-in-install --script path/to/script.luau --place path/to/place`.

A more complete README will be written eventually.
