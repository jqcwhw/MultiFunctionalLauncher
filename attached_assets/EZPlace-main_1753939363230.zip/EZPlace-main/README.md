## Keybinds
- **F1** - starts the arrow/placement thing
- **F2** - Restarts the script 
- **F3** - Closes the scriptt
## Up/Down/Left/Right arrow keys
 - **When toggled on** - the cursor moves 1 pixel in either direction
 - **When toggled off** - the arrow keys work as intended
