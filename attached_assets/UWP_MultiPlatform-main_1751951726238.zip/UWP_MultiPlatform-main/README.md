# UWP_MultiPlatform

An open source project that allows you to create multi instances of ROBLOX UWP without modifying all the values and files yourself.
Simply install ROBLOX UWP, open this program as admin, and click Create Instance.

You can also remove instances you've created by highlighting them and clicking Remove Instance.

Do note that created instances do not auto update, you'll have to remove all of them and recreate them each UWP update.
