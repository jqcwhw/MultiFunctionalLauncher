pub async fn try_detect_launcher() -> Option<super::Launcher> {
    // FUTURE: Try to detect if this process was launched from Finder / Linux equivalent
    None
}
