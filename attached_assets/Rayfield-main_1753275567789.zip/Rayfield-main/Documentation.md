This documentation is outdated.
Forwarding you to: https://docs.sirius.menu/rayfield
