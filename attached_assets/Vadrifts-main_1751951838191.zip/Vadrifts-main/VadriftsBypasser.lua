--[[

 __   __   ______     _____     ______     __     ______   ______   ______    
/\ \ / /  /\  __ \   /\  __-.  /\  == \   /\ \   /\  ___\ /\__  _\ /\  ___\   
\ \ \'/   \ \  __ \  \ \ \/\ \ \ \  __<   \ \ \  \ \  __\ \/_/\ \/ \ \___  \  
 \ \__|    \ \_\ \_\  \ \____-  \ \_\ \_\  \ \_\  \ \_\      \ \_\  \/\_____\ 
  \/_/      \/_/\/_/   \/____/   \/_/ /_/   \/_/   \/_/       \/_/   \/_____/ 
                                                                              
dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz・dsc.gg/vadriftz


discord.gg/25ms for the obfuscation
--]]

loadstring(game:HttpGet("https://raw.githubusercontent.com/vqmpjayZ/Bypass/main/vadrifts.lua"))()
