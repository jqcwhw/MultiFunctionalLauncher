-- // This is just an anti-kick lol, thats all you need
loadstring(game:HttpGet("https://raw.githubusercontent.com/Stefanuk12/ROBLOX/master/Universal/AntiKick.lua"))()