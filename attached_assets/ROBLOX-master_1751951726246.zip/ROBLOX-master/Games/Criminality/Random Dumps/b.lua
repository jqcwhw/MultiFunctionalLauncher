1206 

1207 

1305 

1306 

1308 

1309 

1311 

1312 

8446 -- Decompiled with the Synapse X Luau decompiler.

return local l__UPVAL_0__1();


11234 

11235 

11240 

11241 

11244 

11245 

11348 

11349 

11352 

11353 

11359 

11360 

12664 

12665 

12667 

12668 

12735 

12736 

12738 

12739 

12741 

12742 

12779 

12780 

12782 

12783 

12785 

12786 

12788 

12789 

12791 

12792 

12794 

12795 

12797 

12798 

12800 

12801 

16245 

16246 

16248 

16249 

16251 

16252 

16254 

16255 

16257 

16258 

16260 

16261 

16263 

16264 

16266 

16267 

30207 -- Decompiled with the Synapse X Luau decompiler.

local l__UPVAL_0__1.Unequip();


30208 -- Decompiled with the Synapse X Luau decompiler.

local l__UPVAL_0__1.Equip();


30209 -- Decompiled with the Synapse X Luau decompiler.

local l__UPVAL_0__1.Disconnect();


30223 -- Decompiled with the Synapse X Luau decompiler.




30231 -- Decompiled with the Synapse X Luau decompiler.

local l__UPVAL_0__1.Stepped:Wait();
return _G.DoorLockCheck and _G.DoorLockCheck() or false;


30234 

30275 

30276 

30285 

30293 

33003 

34441 -- Decompiled with the Synapse X Luau decompiler.

if local l__UPVAL_0__1.UserInputService.TouchEnabled and not l__UPVAL_0__1.UserInputService.MouseEnabled and not l__UPVAL_0__1.UserInputService.KeyboardEnabled then
	return true;
end;
return false;


34443 

34445 

34446 

35292 

35300 -- Decompiled with the Synapse X Luau decompiler.

while true do
	local l__UPVAL_0__1.yield(...);
end;


35303 

36313 

36317 

36321 

