# hi
pretty much just my scripts and stuff

[docs branch here](https://github.com/Stefanuk12/ROBLOX/tree/documentation)

note: this repo was made when this account was created but i accidentally deleted the repo (hence the missing history and massive dump)
