export function ButtonGroup({ children }: { children: React.ReactNode }) {
  return <span className="buttonGroup">{children}</span>;
}
