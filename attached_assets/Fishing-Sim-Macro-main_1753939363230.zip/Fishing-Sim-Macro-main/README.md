# Fishing-Sim-Macro
Simple macro for the game Fishing Simulator. this is made for fun - WIP

F1 - Start/Pause
F2 - Reload
F3 - Close

This should work for any type of rod.
Have not digged deep into the games mechantics to find out more stuff.
