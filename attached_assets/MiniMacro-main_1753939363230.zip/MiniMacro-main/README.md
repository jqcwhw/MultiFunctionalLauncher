# MiniMacro
A very obvious and bad tiny task clone, designed to be used within other programs.
