#include <stdio.h>
#include <stdlib.h>
#include "config.h"

int main(int argc, char** argv)
{
    printf("hello %s\n", HELLO);
    return 0;
}
