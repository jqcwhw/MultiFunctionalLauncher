#include <stdio.h>
#include <stdlib.h>
#include "config2.h"

int main(int argc, char** argv)
{
    printf("hello2 %s\n", HELLO2);
    return 0;
}
