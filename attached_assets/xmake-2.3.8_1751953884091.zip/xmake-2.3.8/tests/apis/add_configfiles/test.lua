function main()
    os.exec("xmake")
end
