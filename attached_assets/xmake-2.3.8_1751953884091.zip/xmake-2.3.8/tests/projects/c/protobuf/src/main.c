#include <stdio.h>
#include "test.pb-c.h"
#include "subdir/test2.pb-c.h"

int main(int argc, char** argv)
{
    return 0;
}
