﻿#include <stdio.h>
#include <wchar.h>
#include <标头🎟.h>

void hello()
{
    printf("你好\n");
}
