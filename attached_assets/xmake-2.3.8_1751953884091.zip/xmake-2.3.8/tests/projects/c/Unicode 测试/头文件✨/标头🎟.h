﻿#pragma once

void hello();