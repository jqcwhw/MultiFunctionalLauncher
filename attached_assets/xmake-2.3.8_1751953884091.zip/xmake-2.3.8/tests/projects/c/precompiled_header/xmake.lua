target("main")
    set_kind("binary")
    set_pcheader("src/header.h")
    add_files("src/*.c", "src/*.cpp")

