#include "header.h"

int main(int argc, char** argv) 
{
    std::string s("xmake");
    printf("hello %s!\n", s.c_str());
    return 0;
}
