// header.h
#ifndef HEADER_H
#define HEADER_H
   
#include <algorithm>
#include <deque>
#include <iostream>
#include <map>
#include <memory>
#include <set>
//#include <thread>
#include <utility>
#include <vector>
#include <string>
#include <queue>
#include <cstdlib>
#include <utility>
#include <exception>
#include <list>
#include <stack>
#include <complex>
#include <fstream>
#include <cstdio>
#include <iomanip>

#endif

