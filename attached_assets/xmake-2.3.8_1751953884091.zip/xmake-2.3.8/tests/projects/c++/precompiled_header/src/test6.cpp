
// main.cpp
#include "header.h"

int test6()
{
    return 0;
}
