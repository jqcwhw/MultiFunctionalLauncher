
// main.cpp
#include "header.h"

int test2()
{
    return 0;
}
