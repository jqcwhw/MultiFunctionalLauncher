
void test_c(void)
{
}
