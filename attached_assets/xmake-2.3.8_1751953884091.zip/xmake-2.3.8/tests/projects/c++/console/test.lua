-- main entry
function main(t)

    -- build project
    t:build()
end
