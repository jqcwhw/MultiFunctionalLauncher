module mod;
import hello;

namespace mod {
    int foo() {
        return hello::data__;
    }
}
