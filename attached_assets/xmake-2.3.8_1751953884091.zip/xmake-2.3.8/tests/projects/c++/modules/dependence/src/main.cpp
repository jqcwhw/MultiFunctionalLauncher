import hello;

int main() {
    hello::data__ = 123;
    hello::say_hello();
    hello::say(sizeof(hello::say)).hello();
    return 0;
}

