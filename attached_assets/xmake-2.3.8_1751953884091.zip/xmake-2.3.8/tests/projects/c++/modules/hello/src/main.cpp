import hello;

int main() {
    hello::say("hello module!");
    return 0;
}