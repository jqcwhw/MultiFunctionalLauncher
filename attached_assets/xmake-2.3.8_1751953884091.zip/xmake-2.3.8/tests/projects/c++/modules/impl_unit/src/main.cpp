import hello;

int main() {
    hello::say_hello();
    hello::say_xz();
    // hello::say_hi();
    return 0;
}