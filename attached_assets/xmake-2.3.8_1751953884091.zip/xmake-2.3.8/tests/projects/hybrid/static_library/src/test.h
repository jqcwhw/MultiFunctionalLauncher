#ifdef __cplusplus
extern "C" {
#endif

void test1(void);
void test2(void);
void test3(void);
void test4(void);
int  test5(void);

#ifdef __cplusplus
}
#endif
