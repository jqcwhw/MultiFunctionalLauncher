target("test")
    set_kind("binary")
    add_files("src/*.S")
