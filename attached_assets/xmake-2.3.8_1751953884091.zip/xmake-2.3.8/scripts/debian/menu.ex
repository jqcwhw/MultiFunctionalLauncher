?package(xmake):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="xmake" command="/usr/bin/xmake"
