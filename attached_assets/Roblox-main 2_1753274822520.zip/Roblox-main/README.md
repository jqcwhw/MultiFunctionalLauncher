# 613222s

**Founded by BitsProxy**
<br> *Service is no longer providing bypassing assets. - Mass uploader will be continued to be made.*

![BitProxy Avatar](https://cdn.bitsproxy.dev/bitproxie.png "BitsProxy | This is bitsproxy's roblox avatar. BitsProxy has since been terminated. R.I.P.")

## Description

613222s is a project founded by BitsProxy. It encompasses various tools and scripts, aiming to enhance different aspects of development for Roblox's Systems. 

## Contents

| Folder     | Description                                  | Updated   |
|------------|----------------------------------------------|-----------|
| MassUpload | Roblox's free mass upload script & Inventory Checkers | 6/10/2024 |
| Scripts | Free Roblox's scripts by 613222s. | OUT SOON |

## Services

| Title      | Description                                  | Status    |
|------------|----------------------------------------------|-----------|
| Terminating Users | This service offers free termination towards any Roblox account or bans **with proof else method is used**. | Inactive |
| Asset Uploader | This service provides to upload any asset **Audio, Decal, Image, TShirt, Shirt, Pants**. This service guarantees a 25% **bypassable** image as it follows under our [terms](https://cdn.bitsproxy.dev/au-terms.txt). | Inactive |

Mass Upload lil service soon. **Last updated: 4/25/2024**

Stay cool fellow **proxies** 💖
