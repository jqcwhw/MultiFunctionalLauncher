# Mass Upload
**This script was made Python, comes with Inventory-checker (self, private inventory supported & group checker).**

> **A roblox mass uploader script in Python by BitProxy.**

## Version

* Version 1.27.0
* Date: 6/10/2024

yes skip a bunch of versions lol

![BitProxy Avatar](https://cdn.bitsproxy.dev/bitproxie.png "BitsProxy | This is bitsproxy's roblox avatar. BitsProxy has since been terminated. R.I.P.")

## Setup

* You must install the following packages

| Package | Command |
| ------- | ------- |
| requests | `pip install requests` |
| Pillow | `pip install Pillow` |
| cv2 | `pip install opencv-python` |
| numpy | `pip install numpy` |

## config.json

* You can change the settings in config.json

DisplayName will change **the assets name.** The description will provide a description for **the asset.**
<br> Auto changing theme sets **the roblox account's setting theme to Dark.**

## Running the Program

You must run "main.py." Where the environment supports Python, and it's packages. On Visual Studio Code, you may use the Debugger or the run command `python main.py` / `python3 main.py` or simply running the Python with Terminal by running main.py as "**Python (version)**"

**You must agree to the Terms Of Use (Use Of Service & Use Of Files) provided on the website [here](https://www.bitsproxy.dev/terms).**

## Errors And Warnings ⚠️
### Environmental Warnings And Errors

* **No module named (e.g. requests, cv2, numpy ...)**

If you are running this on [VSC](https://code.visualstudio.com/), you will need to change the python environment. To do this step, you need to press at the bottom right of the application next on the right to where it says "{•} Python", press the python version, you need to use the **(Recommended)** interpreter path version **(Local / Microsoft Store)**.

Source: https://code.visualstudio.com/docs/python/environments

## Social Links

| Social | Link |
| -------- | ----------- |
| Roblox | [lazyproxie](https://www.roblox.com/users/6089365305) |
| YouTube | [Subscribe](https://www.youtube.com/channel/UCprblXVQA5o0Krbiq9GFmxQ?sub_confirmation=1) |
| GitHub | [User](https://github.com/613222) |
| Discord | @boiboikisser |

[bitsproxy.dev](https://www.bitsproxy.dev/home) &copy; 2024