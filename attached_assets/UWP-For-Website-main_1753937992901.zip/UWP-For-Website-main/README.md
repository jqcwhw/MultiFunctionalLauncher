# Roblox UWP for the Roblox website

This Userscript replaces the protocal for the 64x bit client (also known as the web-client), with the protocol for opening the UWP Roblox (Microsoft store Roblox).

You can also replace the protocol used in the script with a custom one if you decide to do so.

## Supported ✴️ 
- Joining friends (even with account mismatch)
- Private servers
- Public servers

To use this script, you will need: [Tampermonkey](https://www.tampermonkey.net/)
<br/>

https://github.com/depthso/Roblox-auto-UWP/assets/86912923/ceed8ef6-c9a4-49b4-b49a-99cdac9a7e76

