# RoValra
- **Only Official Website https://rovalra.com**

- **ROREGION IS NOT MADE OR CONTROLLED BY ME, THEY ARE USING ROVALRAS SOURCE CODE FOR THEIR EXTENSION**

<a href="https://chromewebstore.google.com/detail/RoValra%20-%20Roblox%20Improved/njcickgebhnpgmoodjdgohkclfplejli" title="Available in the Chrome Web Store"><img src="/Assets/ChromeWebStore_BadgeWBorder_v2_206x58.png" alt="Available in the Chrome Web Store"></a>\
<img alt="GitHub Downloads (all assets, all releases)" src="https://img.shields.io/github/downloads/NotValra/RoValra/total">
- **If you like this project, consider giving it a star⭐, it really helps!**


**[Discord Server](https://discord.gg/GHd5cSKJRk)**





## Sections
- [**Features**](https://github.com/NotValra/RoValra?tab=readme-ov-file#features)
- [**FAQ**](https://github.com/NotValra/RoValra?tab=readme-ov-file#FAQ)
- [**Known incompatibilies**](https://github.com/NotValra/RoValra?tab=readme-ov-file#known-incompatibilies)
- [**How to install**](https://github.com/NotValra/RoValra?tab=readme-ov-file#how-to-install)
- [**Credits**](https://github.com/NotValra/RoValra?tab=readme-ov-file#credits) 

# Features
- **Games**
    - **Join preffered region play button**
    - **Shows hidden games on profiles and groups**
    - **Join a server in a specific region**
    - **Shows Subplaces of a game**
    - **Universal game invitation link**
    - **Universal user sniper that does not require you to be friends with them (PATCHED)**
    - **Bot detector, shows if a game is botted**
    - **Shows full server id in the server list**
    - **Copy deeplink for friends servers and shows if they are playing in a private server**
    - **Quick invite link copy for private servers**
    - **Quick Regenarate invite link for private servers**
- **Catalog**
    - **Hidden catalog, which allows you to view Roblox made items before they are on the official catalog.**     
    - **Shows sales and revenue on specific items.**
- **Profile**
  - <details>
    <summary><strong>Instant Joiner</strong></summary>
    <ul>
        <li><strong>Basically this feature allows you to join anyone with their joins on or whose on ur friends list instantly.</strong></li>
    
     <li><strong>lets say for example you wanna join someone whose streaming a game with viewers, you could just use the instant join feature, and you would almost instantly join (Depending on your pc ofc)</strong></li>
    </ul>
    </details>
  - **Check if a user with a private inventory owns a specific item**
  
- **Avatar**
    - **Remove R6 Warning**
    - **R6 Fix. Stops Roblox from automatically switching your character to R15 when equipping dynamic heads.**
- **Misc**
    - **Shows an estimated for how many Robux will stop pending within 24 hours**
- **Fun stuff**
    - **All ban reasons on Roblox**
    - **All ban durations on Roblox**



- **And more to come, if you have a feature you want me to add just lmk**

# FAQ
- **Is this extension a cookie logger?**
    - **No. But dont just take my word for it read the source code yourself.**
- **Does this extension support firefox?**
    - **No, but it might be coming at some point.**
- **Is it bannable to use the extension?**
    - **No, This extension follows Roblox's ToS, if Roblox doesnt like a feature being possible they can just patch it.**
- **Is everything free?**
    - **Yes, everything is free and will forever be free.**
- **Why are you making a completely free extension?**
    - **I made this extension for myself to use, and I just made it public cuz why not.**
- **I have a feature request, where do I request it?**
    - **You can request it in my [Discord Server.](https://discord.gg/GHd5cSKJRk)**
- **Are you actively updating the extension?**
    - **Yes and no. I only really update / add stuff if I want to or something breaks. Cuz I don't make anything out of this, so I still wanna keep it fun for me.**
- **I have feedback where can I tell you it?**
    - **You can send the feedback in my [Discord Server](https://discord.gg/GHd5cSKJRk) in the suggestions channel.**
- **If I suggest a feature and it gets added will I be credited?**
    - **No sadly not, most of the features in the extension are suggestions made by people, and the credits page would be way too long. Tho i might do it at some point**
- **Is this extension ever going paid?**
    - **No, I dont wanna make this extension paid since I dont pay anything to run it. This also means no features will be locked behind a paywall.**
- **Is this an add on to bloxstrap / fishstrap?**
    - **No and Yes, the extension isnt an add on to bloxstrap/fishstrap but you can get a boot theme which is themed around RoValra. Links to the theme: **[Fishstraps discord](https://discord.com/channels/1299397064165429360/1355098180810707044)** **[Bloxstraps discord](https://discord.com/channels/1099468797410283540/1356294984554516562)****

# To do list
- [x] **~~Hidden Catalog allowing you to browse up coming unreleased Roblox items.~~ ADDED**
- [x] **~~Reworked Region selector ui~~ ADDED**
- [x] **~~Feature showing if a game is botted or not~~ ADDED**
- [x] **~~Fixing the invite system~~ ADDED**
- [x] **~~Roblox server list improvements~~ ADDED**
- [ ] **Big region selector improvements and server uptime**
- [ ] **Maybe FireFox support (For now check the forks, Remember to verify the source code.)**

# Known incompatibilies
<details>
  <summary>Expand</summary>
  
- **The hidden games of groups bugs out a bit if you use [RoSeal](https://chromewebstore.google.com/detail/roseal-augmented-roblox-e/hfjngafpndganmdggnapblamgbfjhnof?hl=en) with the "Seamless navigation of communities" setting on.**
</details>

# Known Issues
- **In rare cases it shows unowned items under the owned tab when viewing private inventories**
# How to install

<details>
  <summary>Expand</summary>

- If you want a simple install you can install it on from the [chrome web store.](https://chromewebstore.google.com/detail/RoValra%20-%20Roblox%20Improved/njcickgebhnpgmoodjdgohkclfplejli)
- Everything below is purely a tutorial on how to install it from GitHub.
- Enable developer mode on your browser of choice.
![image](https://github.com/user-attachments/assets/301ab762-7b3b-4f5f-9eb0-9e7699212546)
- Unzip the file in [releases](https://github.com/NotValra/Hidden-Games/releases)
- Import the unzipped folder into your browser. Ensure that you import the folder that contains direct access to background.js, content.js and manifest.json etc.
![image](https://github.com/user-attachments/assets/2b238201-c297-4106-a5ad-6db4c9259dc6)
</details>

# Credits
- **Sales / revenue thingy: https://github.com/workframes/roblox-owner-counts**
  
- **Thanks to mmfw for making the pictures on the chrome web store and general help with UI design of the extension.**

- **Coding: Chatgpt (more like gemini but what ever) 😘 and little me**

- **Region searcher, originally a python script made by l5se on dc that I improved in python and then recoded to add to my extension (with permission)**

- **Extra coding help when chatgpt and me didnt know how: [Aspect](https://github.com/Aspectise)**
  
- **Extensions logo is gilbert, which is a fish I caught in [Fisch](https://www.roblox.com/games/16732694052/Fisch)**
- **7_lz on dc helped me a lot with the process of switching away from third party APIs by providing me with the json and just general help**
- **Thanks to Julia for creating a Github repo that documented all the Roblox datacenter ips, which i now use for my region selector https://github.com/RoSeal-Extension/Top-Secret-Thing**
- **Credit to coweggs on dc for coming up with the name RoValra, it was just too funny I had to use it**
