We release tons of resources, including source files like "Display Framerate" in our <a href="https://discord.gg/v4ZTG26h4j" target="_blank">Discord Server</a>, so be sure to check us out.

## What is Display-Framerate?

Display-Framerate outputs your current framerate to the console on Roblox.

## When was this last updated?

Display-Framerate is updated as of 06/05/2023 for version-21bedf9513a74867 the Byfron/Hyperion client.
