﻿namespace Bloxstrap.Enums
{
    public enum CustomThemeTemplate
    {
        Blank,
        Simple
    }
}
