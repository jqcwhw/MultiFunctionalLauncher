export const ModalEvent = {
  OpenAccessManagementVerificationModal: 'OpenAccessManagementVerificationModal'
};

export default { ModalEvent };
