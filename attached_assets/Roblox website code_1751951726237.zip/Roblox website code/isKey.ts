export default (value: string) => /^\w*$/.test(value);
