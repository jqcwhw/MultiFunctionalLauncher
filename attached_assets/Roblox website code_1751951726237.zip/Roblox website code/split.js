import { ApolloLink } from "./ApolloLink.js";
export var split = ApolloLink.split;
//# sourceMappingURL=split.js.map