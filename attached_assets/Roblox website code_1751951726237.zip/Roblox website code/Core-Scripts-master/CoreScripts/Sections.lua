settings().FastLogSettings:SetGroupEnable("Network", 1, true)
settings().FastLogSettings:SetGroupEnable("MegaClusterNetwork", 1, true)
settings().FastLogSettings:SetGroupEnable("MegaClusterNetworkInit", 1, true)