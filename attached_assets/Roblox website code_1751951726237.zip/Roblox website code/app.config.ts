export const rootElementId = 'access-management-upsell-container-v1';

export const accessManagementUpsellTranslationConfig = {
  common: [] as string[],
  feature: 'Feature.AgeVerificationUpsell'
};
