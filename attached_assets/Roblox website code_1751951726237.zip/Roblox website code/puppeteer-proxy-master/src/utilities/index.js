// @flow

export {default as formatPuppeteerCookieAsToughCookie} from './formatPuppeteerCookieAsToughCookie';
