// @flow

import Roarr from 'roarr';

export default Roarr.child({
  package: 'puppeteer-proxy',
});
