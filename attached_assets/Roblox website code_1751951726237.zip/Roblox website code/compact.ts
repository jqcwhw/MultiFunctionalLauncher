export default (value: any[]) => value.filter(Boolean);
