Roblox-API
==========

A library of all my PHP Roblox APIs

Some APIs are not shared publicly on robloxapi.com but are open to take and use here.

How to use
==========

You must have allow_url_fopen enabled in your PHP settings

Please give credit if you are going to use this.
