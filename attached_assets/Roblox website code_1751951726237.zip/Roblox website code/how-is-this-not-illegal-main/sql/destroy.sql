-- pokemon table for postgresql
DROP TABLE pokemon;
