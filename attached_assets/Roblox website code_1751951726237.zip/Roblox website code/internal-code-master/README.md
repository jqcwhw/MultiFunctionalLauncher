This repository contains Lua code used internally by ROBLOX. This repository contains the source of the ROBLOX Lua libraries and of the core scripts used to create the GUI interface.

See [the wiki](https://github.com/ROBLOX/internal-code/wiki) for more information.
