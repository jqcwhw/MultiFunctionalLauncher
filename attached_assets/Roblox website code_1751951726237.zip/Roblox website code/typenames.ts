const typenames = {
  UserProfiles: 'UserProfiles'
};

export default typenames;
