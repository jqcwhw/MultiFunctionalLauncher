export default (value: unknown): value is boolean => typeof value === 'boolean';
