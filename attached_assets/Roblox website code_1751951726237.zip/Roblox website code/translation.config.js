export const translationConfig = {
  common: ['CommonUI.Features'],
  feature: 'Feature.ProfileBadges'
};

export default translationConfig;
