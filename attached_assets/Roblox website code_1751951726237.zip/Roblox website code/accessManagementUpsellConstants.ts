const accessManagementUpsellConstants = {
  TitleText: 'Modal.Title',
  BodyText: 'Modal.ContentText',
  AccountInfoButtonText: 'Button.AccountInfo',
  accountSettingsPath: '/my/account#!/info'
};

export { accessManagementUpsellConstants as default };
