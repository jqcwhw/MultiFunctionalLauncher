# vapoursynth-portable-FATPACK
A (beginners) bundle with nearly all plugins, many usefull scripts and multiple editors. Only 64Bit!
