# RAMDecrypt
## [DOWNLOAD THE BINARIES, NOT THE PROJECT!!!](https://github.com/ic3w0lf22/RAMDecrypt/releases/tag/1.0)
Decrypt and Encrypt your AccountData.json with one simple drag and drop!

![github-large](HOW_TO_USE.gif)

# License
Licensed under the [DWTFYWWI](https://github.com/avar/DWTFYWWI) License]
