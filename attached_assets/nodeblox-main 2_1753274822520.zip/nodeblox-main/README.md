# nodeblox [WIP]
drone delivery for lego game

Put client.lua in autoexecute

As of right now its mostly unfinished idk how to make a checklist so here is my very shitty checklist of core features

- [x] Joining
- [X] Execution (broken as of right now, something in synapse auto attach changed or my synapse is just bugged idk)
- [ ] Returns
- [X] Wiki / Documentation
- [ ] Multi account at once (somewhat works)
- [X] Upload to npm

Under MIT open source license
