print(scripletarg1)
print(scripletarg2)
print(scripletarg3)