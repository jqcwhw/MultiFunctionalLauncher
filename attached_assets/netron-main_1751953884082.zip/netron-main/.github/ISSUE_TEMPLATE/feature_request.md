---
name: Feature request
about: Suggest an idea for this project
labels: feature
---
<!-- Please search existing issues to avoid creating duplicates. -->
<!-- Describe the feature you'd like. -->
