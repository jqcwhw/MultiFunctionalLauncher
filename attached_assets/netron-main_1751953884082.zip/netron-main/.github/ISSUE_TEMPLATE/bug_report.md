---
name: Bug report
about: Create a report to help us improve
labels: bug
---

- Netron app and version: <!-- For example: 3.8.2 Desktop app, 2.9.0 Website or 3.9.2 Python Server -->
- OS and browser version: <!-- For example macOS 10.15.6 (19G73) + Chrome 84.0.4147.89 -->

Steps to Reproduce:

1.
2.

Please attach or link model files to reproduce the issue.
