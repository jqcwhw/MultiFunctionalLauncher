import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const assets = pgTable("assets", {
  id: varchar("id").primaryKey(),
  assetId: text("asset_id").notNull().unique(),
  name: text("name").notNull(),
  creator: text("creator"),
  creatorId: text("creator_id"),
  description: text("description"),
  category: text("category"),
  sourceGroup: text("source_group"),
  thumbnailUrl: text("thumbnail_url"),
  robloxUrl: text("roblox_url"),
  assetType: text("asset_type"),
  isVerified: boolean("is_verified").default(false),
  isExclusive: boolean("is_exclusive").default(false),
  metadata: jsonb("metadata"),
  discoveredAt: timestamp("discovered_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const discoveries = pgTable("discoveries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assetId: text("asset_id").notNull().references(() => assets.assetId),
  discoveryType: text("discovery_type").notNull(), // 'new', 'updated', 'verified'
  sourceEndpoint: text("source_endpoint"),
  rawData: jsonb("raw_data"),
  webhookSent: boolean("webhook_sent").default(false),
  webhookSentAt: timestamp("webhook_sent_at"),
  discoveredAt: timestamp("discovered_at").defaultNow(),
});

export const scannerStatus = pgTable("scanner_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  source: text("source").notNull().unique(), // 'BIG Games Pets', 'BIG Games™', etc.
  isActive: boolean("is_active").default(true),
  lastScanAt: timestamp("last_scan_at"),
  nextScanAt: timestamp("next_scan_at"),
  scanCount: integer("scan_count").default(0),
  errorCount: integer("error_count").default(0),
  lastError: text("last_error"),
  rateLimited: boolean("rate_limited").default(false),
  rateLimitResetAt: timestamp("rate_limit_reset_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const webhookLogs = pgTable("webhook_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assetId: text("asset_id").references(() => assets.assetId),
  webhookUrl: text("webhook_url").notNull(),
  payload: jsonb("payload"),
  response: jsonb("response"),
  success: boolean("success").default(false),
  sentAt: timestamp("sent_at").defaultNow(),
});

// Relations
export const assetsRelations = relations(assets, ({ many }) => ({
  discoveries: many(discoveries),
}));

export const discoveriesRelations = relations(discoveries, ({ one }) => ({
  asset: one(assets, {
    fields: [discoveries.assetId],
    references: [assets.assetId],
  }),
}));

// Schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertAssetSchema = createInsertSchema(assets).omit({
  id: true,
  discoveredAt: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDiscoverySchema = createInsertSchema(discoveries).omit({
  id: true,
  discoveredAt: true,
});

export const insertScannerStatusSchema = createInsertSchema(scannerStatus).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertWebhookLogSchema = createInsertSchema(webhookLogs).omit({
  id: true,
  sentAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Asset = typeof assets.$inferSelect;

export type InsertDiscovery = z.infer<typeof insertDiscoverySchema>;
export type Discovery = typeof discoveries.$inferSelect;

export type InsertScannerStatus = z.infer<typeof insertScannerStatusSchema>;
export type ScannerStatus = typeof scannerStatus.$inferSelect;

export type InsertWebhookLog = z.infer<typeof insertWebhookLogSchema>;
export type WebhookLog = typeof webhookLogs.$inferSelect;
