/**
 * Developer Product Scanner - Comprehensive Integration
 * Fully integrated from dev-product-scanner with all original functionality
 * Tracks developer products across Big Games properties and PS99
 */

import { placeChannelMapping } from './utils/placeChannelMapping';
import { getPlaceName } from './utils/getPlaceName';
import { productFetcher } from './utils/fetchProducts';
import { convertPlaceToUniverse } from './utils/convertPlaceToUniverse';
import { DevProductChangeTypes, DevProductChange, DevProductScanResult, DeveloperProduct } from './utils/devProductTypes';
import { buildAssetThumbnailUrl, buildDevProductUrl } from './utils/devProductTypes';
import { storage } from '../storage';
import { discordWebhook } from './discordWebhook';
import { placeChannelMapping } from './utils/placeChannelMapping';
import { getPlaceName } from './utils/getPlaceName';
import { productFetcher } from './utils/fetchProducts';
import { convertPlaceToUniverse } from './utils/convertPlaceToUniverse';
import { DevProductChangeTypes, DevProductChange, DevProductScanResult, DeveloperProduct } from './utils/devProductTypes';
import { buildAssetThumbnailUrl, buildDevProductUrl } from './utils/devProductTypes';
import { storage } from '../storage';
import { discordWebhook } from './discordWebhook';

export class DevProductScanner {
  private scanInProgress = false;
  private lastScanTime: Date | null = null;

  constructor() {
    console.log('DevProductScanner initialized with places:', placeChannelMapping.getAllPlaceIds());
  }

  async fetchDeveloperProducts(placeId: string): Promise<DeveloperProduct[]> {
    try {
      const robloxCookie = process.env.ROBLOX_COOKIE;
      return await productFetcher.fetchProducts(placeId, { 
        robloxCookie,
        includeInactive: false 
      });
    } catch (error) {
      console.error(`Error fetching products for place ${placeId}:`, error);
      return [];
    }
  }

  private detectChanges(newProducts: DeveloperProduct[], oldProducts: DeveloperProduct[], placeName: string): DevProductChange[] {
    const changes: DevProductChange[] = [];

    for (const newProduct of newProducts) {
      const oldProduct = oldProducts.find(p => 
        p.DeveloperProductId === newProduct.DeveloperProductId
      );

      if (!oldProduct) {
        changes.push({
          type: DevProductChangeTypes.NEW_ITEM,
          product: newProduct,
          placeName,
          channelId: placeChannelMapping.getChannelForPlace(newProduct.placeId.toString())
        });
        continue;
      }

      if (newProduct.PriceInRobux !== oldProduct.PriceInRobux) {
        changes.push({
          type: DevProductChangeTypes.NEW_PRICE,
          product: newProduct,
          oldProduct,
          placeName,
          channelId: placeChannelMapping.getChannelForPlace(newProduct.placeId.toString())
        });
      } else if (newProduct.IconImageAssetId !== oldProduct.IconImageAssetId) {
        changes.push({
          type: DevProductChangeTypes.NEW_IMAGE,
          product: newProduct,
          oldProduct,
          placeName,
          channelId: placeChannelMapping.getChannelForPlace(newProduct.placeId.toString())
        });
      } else if (newProduct.Name !== oldProduct.Name) {
        changes.push({
          type: DevProductChangeTypes.NEW_NAME,
          product: newProduct,
          oldProduct,
          placeName,
          channelId: placeChannelMapping.getChannelForPlace(newProduct.placeId.toString())
        });
      } else if (newProduct.Description !== oldProduct.Description && newProduct.Description !== "") {
        changes.push({
          type: DevProductChangeTypes.NEW_DESCRIPTION,
          product: newProduct,
          oldProduct,
          placeName,
          channelId: placeChannelMapping.getChannelForPlace(newProduct.placeId.toString())
        });
      }
    }

    return changes;
  }

  async scanAllPlaces(): Promise<DevProductScanResult[]> {
    const results: DevProductScanResult[] = [];
    const placeIds = placeChannelMapping.getAllPlaceIds();
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    for (const placeId of placeIds) {
      const scanResult: DevProductScanResult = {
        placeId,
        placeName: '',
        changes: [],
        totalProducts: 0,
        newProducts: 0,
        updatedProducts: 0,
        errors: []
      };

      try {
        console.log(`Scanning developer products for place ${placeId}...`);

        const placeName = await getPlaceName(placeId);
        scanResult.placeName = placeName;

        // Get existing products from storage (only from last 7 days)
        const existingAssets = await storage.getAssets({
          category: 'developer-product',
          sourceGroup: placeId,
          since: sevenDaysAgo
        });

        // Convert existing assets to developer products format
        const oldProducts: DeveloperProduct[] = existingAssets.map(asset => ({
          ProductId: parseInt(asset.metadata?.ProductId || '0'),
          DeveloperProductId: parseInt(asset.assetId),
          Name: asset.name,
          Description: asset.description || '',
          IconImageAssetId: asset.metadata?.IconImageAssetId || null,
          PriceInRobux: parseInt(asset.metadata?.PriceInRobux || '0'),
          placeId: parseInt(placeId)
        }));

        // Fetch current products
        const newProducts = await this.fetchDeveloperProducts(placeId);
        scanResult.totalProducts = newProducts.length;

        // Detect changes (only consider items as "new" if they're truly new within 7 days)
        const changes = this.detectChanges(newProducts, oldProducts, placeName);

        // Filter changes to only include recent ones (7 days)
        const recentChanges = changes.filter(change => {
          // Check if this asset was discovered in the last 7 days
          const assetAge = existingAssets.find(a => a.assetId === change.product.DeveloperProductId.toString());
          return !assetAge || new Date(assetAge.createdAt) >= sevenDaysAgo;
        });

        scanResult.changes = recentChanges;
        scanResult.newProducts = recentChanges.filter(c => c.type === DevProductChangeTypes.NEW_ITEM).length;
        scanResult.updatedProducts = recentChanges.length - scanResult.newProducts;

        // Store new/updated products and auto-post to webhook
        for (const change of recentChanges) {
          try {
            await storage.createAsset({
              assetId: change.product.DeveloperProductId.toString(),
              name: change.product.Name,
              creator: placeName,
              creatorId: placeId,
              description: change.product.Description,
              category: 'developer-product',
              sourceGroup: placeId,
              thumbnailUrl: buildAssetThumbnailUrl(change.product.IconImageAssetId),
              robloxUrl: buildDevProductUrl(change.product.DeveloperProductId),
              assetType: 'DeveloperProduct',
              isVerified: true,
              isExclusive: false,
              metadata: {
                ProductId: change.product.ProductId,
                IconImageAssetId: change.product.IconImageAssetId,
                PriceInRobux: change.product.PriceInRobux,
                placeId: change.product.placeId,
                changeType: change.type,
                oldPrice: change.oldProduct?.PriceInRobux,
                discoveryDate: new Date().toISOString()
              }
            });

            // Create discovery record
            const discovery = await storage.createDiscovery({
              assetId: change.product.DeveloperProductId.toString(),
              discoveryType: change.type === DevProductChangeTypes.NEW_ITEM ? 'new' : 'updated',
              sourceEndpoint: `developer-products/place/${placeId}`,
              rawData: change.product,
              webhookSent: false
            });

            // Auto-post to Discord webhook
            try {
              const { discordWebhook } = await import('./discordWebhook');
              await discordWebhook.sendDevProductDiscovery(change);

              // Mark webhook as sent
              await storage.updateDiscovery(discovery.id, { webhookSent: true });
              console.log(`✅ Posted new ${change.type} to Discord: ${change.product.Name}`);
            } catch (webhookError) {
              console.error(`❌ Failed to send webhook for ${change.product.Name}:`, webhookError);
            }
          } catch (assetError) {
            const errorMsg = `Failed to store asset ${change.product.DeveloperProductId}: ${assetError}`;
            console.error(errorMsg);
            scanResult.errors.push(errorMsg);
          }
        }

        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : 'Unknown error';
        console.error(`Failed to scan place ${placeId}:`, error);
        scanResult.errors.push(errorMsg);

        await storage.updateScannerStatus({
          source: `dev-products-${placeId}`,
          isActive: true,
          lastError: errorMsg,
          errorCount: 1
        });
      }

      results.push(scanResult);
    }

    return results;
  }

  async performFullScan(): Promise<DevProductScanResult[]> {
    if (this.scanInProgress) {
      console.log('Developer product scan already in progress, skipping...');
      return [];
    }

    this.scanInProgress = true;
    this.lastScanTime = new Date();

    console.log('Starting comprehensive developer product scan with ALL base methods...');

    // Use ALL methods from dev scanner base
    await this.performAllBaseMethods();

    try {
      const results = await this.scanAllPlaces();

      const totalChanges = results.reduce((sum, result) => sum + result.changes.length, 0);
      const totalErrors = results.reduce((sum, result) => sum + result.errors.length, 0);

      console.log(`Developer product scan completed:
        - ${results.length} places scanned
        - ${totalChanges} changes detected
        - ${totalErrors} errors encountered`);

      // Update scanner status for each place
      for (const result of results) {
        await storage.updateScannerStatus({
          source: `dev-products-${result.placeId}`,
          isActive: true,
          lastScanAt: new Date(),
          nextScanAt: new Date(Date.now() + 15 * 60 * 1000), // Next scan in 15 minutes
          scanCount: 1,
          errorCount: result.errors.length,
          lastError: result.errors.length > 0 ? result.errors[0] : null,
          rateLimited: false
        });
      }

      return results;
    } finally {
      this.scanInProgress = false;
    }
  }

  // Legacy compatibility method for routes integration
  async performLegacyScan(): Promise<void> {
    await this.performFullScan();
  }

  getMonitoredPlaces(): string[] {
    return placeChannelMapping.getAllPlaceIds();
  }

  getChannelForPlace(placeId: string): string | undefined {
    return placeChannelMapping.getChannelForPlace(placeId);
  }

  getPlaceMappings() {
    return placeChannelMapping.getAllMappings();
  }

  isScanInProgress(): boolean {
    return this.scanInProgress;
  }

  getLastScanTime(): Date | null {
    return this.lastScanTime;
  }

  /**
   * Perform ALL methods from dev scanner base folder
   */
  async performAllBaseMethods(): Promise<void> {
    console.log('🔍 Executing ALL dev scanner base methods...');

    try {
      // Method from base: Enhanced place to universe conversion
      await this.enhancedPlaceToUniverseScanning();

      // Method from base: Advanced product fetching with all options
      await this.advancedProductFetching();

      // Method from base: Comprehensive place name resolution
      await this.comprehensivePlaceNameScanning();

      // Method from base: Complete channel mapping integration
      await this.completeChannelMappingIntegration();

      // Method from base: Advanced embed generation
      await this.advancedEmbedGeneration();

    } catch (error) {
      console.error('Error in base methods execution:', error);
    }
  }

  /**
   * Enhanced place to universe conversion from base
   */
  async enhancedPlaceToUniverseScanning(): Promise<void> {
    const { convertPlaceToUniverse } = await import('./utils/convertPlaceToUniverse');
    const placeIds = placeChannelMapping.getAllPlaceIds();

    console.log(`Converting ${placeIds.length} places to universe IDs...`);

    for (const placeId of placeIds) {
      try {
        const universeId = await convertPlaceToUniverse(placeId);
        console.log(`✅ Place ${placeId} -> Universe ${universeId}`);

        // Store mapping for future use
        await storage.updateScannerStatus(`universe-${universeId}`, {
          placeId,
          universeId,
          mappedAt: new Date()
        });

      } catch (error) {
        console.error(`❌ Failed to convert place ${placeId}:`, error);
      }
    }
  }

  /**
   * Advanced product fetching using ALL options
   */
  async advancedProductFetching(): Promise<void> {
    const { productFetcher } = await import('./utils/fetchProducts');
    const placeIds = placeChannelMapping.getAllPlaceIds();

    console.log('Advanced product fetching with ALL options...');

    // Fetch with ALL possible options
    const options = {
      robloxCookie: process.env.ROBLOX_COOKIE,
      includeInactive: true, // Include inactive products too
      limit: 100
    };

    const productsMap = await productFetcher.fetchMultiplePlaces(placeIds, options);

    for (const [placeId, products] of productsMap.entries()) {
      console.log(`📦 Fetched ${products.length} products (including inactive) for place ${placeId}`);

      // Process ALL products including inactive ones
      for (const product of products) {
        await this.processAdvancedProduct(product, placeId);
      }
    }
  }

  /**
   * Process advanced product with all metadata
   */
  async processAdvancedProduct(product: any, placeId: string): Promise<void> {
    try {
      await storage.createAsset({
        assetId: product.DeveloperProductId.toString(),
        name: product.Name,
        creator: await getPlaceName(placeId),
        creatorId: placeId,
        description: product.Description || '',
        category: 'developer-product',
        sourceGroup: placeId,
        thumbnailUrl: buildAssetThumbnailUrl(product.IconImageAssetId),
        robloxUrl: buildDevProductUrl(product.DeveloperProductId),
        assetType: 'DeveloperProduct',
        isVerified: true,
        isExclusive: false,
        metadata: {
          ProductId: product.ProductId,
          IconImageAssetId: product.IconImageAssetId,
          PriceInRobux: product.PriceInRobux,
          placeId: product.placeId,
          universeId: product.universeId,
          isActive: product.PriceInRobux > 0,
          fetchedAt: new Date().toISOString(),
          methodUsed: 'advancedProductFetching'
        }
      });
    } catch (error) {
      console.error(`Error processing advanced product ${product.DeveloperProductId}:`, error);
    }
  }

  /**
   * Comprehensive place name scanning
   */
  async comprehensivePlaceNameScanning(): Promise<void> {
    const { getPlaceName } = await import('./utils/getPlaceName');
    const placeIds = placeChannelMapping.getAllPlaceIds();

    console.log('Comprehensive place name resolution...');

    for (const placeId of placeIds) {
      try {
        const placeName = await getPlaceName(placeId);
        console.log(`📍 Place ${placeId}: ${placeName}`);

        // Store comprehensive place data
        await storage.updateScannerStatus(`place-name-${placeId}`, {
          placeId,
          placeName,
          resolvedAt: new Date(),
          source: 'comprehensivePlaceNameScanning'
        });

      } catch (error) {
        console.error(`Error resolving place name for ${placeId}:`, error);
      }
    }
  }

  /**
   * Complete channel mapping integration
   */
  async completeChannelMappingIntegration(): Promise<void> {
    console.log('Complete channel mapping integration...');

    const allMappings = placeChannelMapping.getAllMappings();
    const allPlaceIds = placeChannelMapping.getAllPlaceIds();
    const allChannelIds = placeChannelMapping.getAllChannelIds();

    console.log(`📋 Total mappings: ${allMappings.length}`);
    console.log(`🏢 Total places: ${allPlaceIds.length}`);
    console.log(`💬 Total channels: ${allChannelIds.length}`);

    // Store complete mapping data
    for (const mapping of allMappings) {
      await storage.updateScannerStatus(`mapping-${mapping.placeId}`, {
        ...mapping,
        integratedAt: new Date(),
        source: 'completeChannelMappingIntegration'
      });
    }
  }

  /**
   * Advanced embed generation for all changes
   */
  async advancedEmbedGeneration(): Promise<void> {
    console.log('Advanced embed generation...');

    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentChanges = await storage.getDiscoveries({ 
      limit: 100,
      since: sevenDaysAgo,
      category: 'developer-product'
    });

    for (const change of recentChanges) {
      if (!change.webhookSent) {
        try {
          const asset = await storage.getAssetByAssetId(change.assetId);
          if (asset) {
            // Generate advanced embed with ALL metadata
            const { discordWebhook } = await import('./discordWebhook');
            await discordWebhook.sendDevProductDiscovery({
              type: change.discoveryType as any,
              product: {
                DeveloperProductId: parseInt(asset.assetId),
                Name: asset.name,
                Description: asset.description,
                PriceInRobux: asset.metadata?.PriceInRobux || 0,
                IconImageAssetId: asset.metadata?.IconImageAssetId,
                placeId: parseInt(asset.sourceGroup || '0')
              },
              placeName: asset.creator,
              channelId: placeChannelMapping.getChannelForPlace(asset.sourceGroup || '')
            });

            await storage.updateDiscovery(change.id, { webhookSent: true });
            console.log(`✅ Advanced embed sent for: ${asset.name}`);
          }
        } catch (error) {
          console.error(`Error generating advanced embed:`, error);
        }
      }
    }
  }
}

export const devProductScanner = new DevProductScanner();