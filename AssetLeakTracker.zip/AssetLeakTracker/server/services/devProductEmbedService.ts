/**
 * Developer Product Discord Embed Service
 * Integrated from dev-product-scanner sendEmbed.js
 */

import { 
  DevProductChange, 
  DevProductChangeTypes, 
  validateField,
  formatRobux,
  calculatePriceChange,
  buildDevProductUrl,
  buildAssetThumbnailUrl
} from './utils/devProductTypes';

interface EmbedField {
  name: string;
  value: string;
  inline?: boolean;
}

interface EmbedData {
  title: string;
  url?: string;
  description?: string;
  color: number;
  author?: {
    name: string;
  };
  thumbnail?: {
    url: string;
  };
  fields: EmbedField[];
  timestamp?: string;
  footer?: {
    text: string;
  };
}

export class DevProductEmbedService {
  
  generateEmbed(change: DevProductChange): EmbedData {
    const { type, product, oldProduct, placeName } = change;
    
    const baseFields: EmbedField[] = [
      {
        name: 'Place Name',
        value: placeName,
        inline: true,
      },
      {
        name: 'Developer Product ID',
        value: validateField(product.DeveloperProductId),
        inline: true,
      }
    ];

    const baseEmbed: Omit<EmbedData, 'color' | 'author'> = {
      title: validateField(product.Name),
      url: buildDevProductUrl(product.DeveloperProductId),
      thumbnail: product.IconImageAssetId ? {
        url: buildAssetThumbnailUrl(product.IconImageAssetId)!
      } : undefined,
      fields: baseFields,
      timestamp: new Date().toISOString(),
      footer: {
        text: 'PS99 Asset Tracker • Developer Products'
      }
    };

    switch (type) {
      case DevProductChangeTypes.NEW_ITEM:
        return {
          ...baseEmbed,
          color: 0x00ffff, // Cyan for new items
          author: {
            name: 'New Developer Product'
          },
          fields: [
            ...baseFields,
            {
              name: 'Description',
              value: validateField(product.Description) || 'No description',
              inline: true,
            },
            {
              name: 'Price',
              value: formatRobux(product.PriceInRobux),
              inline: true,
            },
            {
              name: 'Link',
              value: `[View Product](${buildDevProductUrl(product.DeveloperProductId)})`,
              inline: true,
            },
            {
              name: 'Image Asset ID',
              value: validateField(product.IconImageAssetId),
              inline: true,
            }
          ]
        };

      case DevProductChangeTypes.NEW_PRICE:
        if (!oldProduct) break;
        const priceChange = calculatePriceChange(oldProduct.PriceInRobux, product.PriceInRobux);
        return {
          ...baseEmbed,
          color: 0xffd700, // Gold for price changes
          author: {
            name: 'Price Change'
          },
          fields: [
            ...baseFields,
            {
              name: 'Old Price',
              value: formatRobux(oldProduct.PriceInRobux),
              inline: true,
            },
            {
              name: 'New Price',
              value: formatRobux(product.PriceInRobux),
              inline: true,
            },
            {
              name: 'Change',
              value: `${priceChange.difference > 0 ? '+' : ''}${formatRobux(priceChange.difference)} (${priceChange.percentChange}%)`,
              inline: true,
            },
            {
              name: 'Link',
              value: `[View Product](${buildDevProductUrl(product.DeveloperProductId)})`,
              inline: true,
            }
          ]
        };

      case DevProductChangeTypes.NEW_IMAGE:
        return {
          ...baseEmbed,
          color: 0x9932cc, // Purple for image changes
          author: {
            name: 'Image Change'
          },
          fields: [
            ...baseFields,
            {
              name: 'Old Image Asset ID',
              value: validateField(oldProduct?.IconImageAssetId),
              inline: true,
            },
            {
              name: 'New Image Asset ID',
              value: validateField(product.IconImageAssetId),
              inline: true,
            },
            {
              name: 'Price',
              value: formatRobux(product.PriceInRobux),
              inline: true,
            },
            {
              name: 'Link',
              value: `[View Product](${buildDevProductUrl(product.DeveloperProductId)})`,
              inline: true,
            }
          ]
        };

      case DevProductChangeTypes.NEW_NAME:
        return {
          ...baseEmbed,
          color: 0x32cd32, // Green for name changes
          author: {
            name: 'Name Change'
          },
          fields: [
            ...baseFields,
            {
              name: 'Old Name',
              value: validateField(oldProduct?.Name),
              inline: true,
            },
            {
              name: 'New Name',
              value: validateField(product.Name),
              inline: true,
            },
            {
              name: 'Price',
              value: formatRobux(product.PriceInRobux),
              inline: true,
            },
            {
              name: 'Link',
              value: `[View Product](${buildDevProductUrl(product.DeveloperProductId)})`,
              inline: true,
            }
          ]
        };

      case DevProductChangeTypes.NEW_DESCRIPTION:
        return {
          ...baseEmbed,
          color: 0xff6347, // Orange-red for description changes
          author: {
            name: 'Description Change'
          },
          fields: [
            ...baseFields,
            {
              name: 'Old Description',
              value: validateField(oldProduct?.Description) || 'No description',
              inline: false,
            },
            {
              name: 'New Description',
              value: validateField(product.Description) || 'No description',
              inline: false,
            },
            {
              name: 'Price',
              value: formatRobux(product.PriceInRobux),
              inline: true,
            },
            {
              name: 'Link',
              value: `[View Product](${buildDevProductUrl(product.DeveloperProductId)})`,
              inline: true,
            }
          ]
        };

      default:
        return {
          ...baseEmbed,
          color: 0x808080, // Gray for unknown changes
          author: {
            name: 'Product Update'
          }
        };
    }

    // Fallback
    return {
      ...baseEmbed,
      color: 0x808080,
      author: {
        name: 'Product Update'
      }
    };
  }

  async sendToDiscordWebhook(webhookUrl: string, embed: EmbedData): Promise<boolean> {
    try {
      const payload = {
        embeds: [embed]
      };

      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        console.error(`Discord webhook failed: ${response.status} ${response.statusText}`);
        return false;
      }

      console.log('Discord embed sent successfully');
      return true;
    } catch (error) {
      console.error('Error sending Discord embed:', error);
      return false;
    }
  }

  async sendChangeNotification(change: DevProductChange, webhookUrl?: string): Promise<boolean> {
    const embed = this.generateEmbed(change);
    
    const url = webhookUrl || process.env.DISCORD_WEBHOOK_URL;
    if (!url) {
      console.warn('No Discord webhook URL configured');
      return false;
    }

    return await this.sendToDiscordWebhook(url, embed);
  }
}

export const devProductEmbedService = new DevProductEmbedService();