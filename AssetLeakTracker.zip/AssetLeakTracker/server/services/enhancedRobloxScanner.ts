/**
 * Enhanced Roblox Scanner
 * Integrates dev product scanner functionality with comprehensive endpoint scanning
 */

import axios from 'axios';
import { storage } from '../storage';
import { 
  TRACKED_DEVELOPERS, 
  TRACKED_GROUPS, 
  PS99_GAME_INFO, 
  PRIORITY_ASSET_TYPES,
  PS99_KEYWORDS,
  getHighPriorityDevelopers,
  getAllDeveloperIds,
  getAllGroupIds
} from '../config/developerTracker';

// Enhanced endpoint registry from attached files
export const ROBLOX_ENDPOINTS = {
  // Core API endpoints
  CATALOG_API: 'https://catalog.roblox.com/v1',
  GAMES_API: 'https://games.roblox.com/v1',
  GROUPS_API: 'https://groups.roblox.com/v1',
  USERS_API: 'https://users.roblox.com/v1',
  INVENTORY_API: 'https://inventory.roblox.com/v2',
  ECONOMY_API: 'https://economy.roblox.com/v2',
  AVATAR_API: 'https://avatar.roblox.com/v1',
  THUMBNAILS_API: 'https://thumbnails.roblox.com/v1',
  BADGES_API: 'https://badges.roblox.com/v1',
  DEVELOPER_PRODUCTS_API: 'https://apis.roblox.com/developer-products/v1',
  ASSET_DELIVERY_API: 'https://assetdelivery.roblox.com/v1',

  // Function endpoints
  endpoints: {
    // Asset endpoints
    getAssetInfo: (assetId: string) => `https://economy.roblox.com/v2/assets/${assetId}/details`,
    searchCatalog: () => 'https://catalog.roblox.com/v1/search/items',
    getAssetThumbnail: (assetIds: string) => `https://thumbnails.roblox.com/v1/assets?assetIds=${assetIds}&size=420x420&format=Png`,
    getAssetContent: (assetId: string) => `https://assetdelivery.roblox.com/v1/asset/?id=${assetId}`,

    // User endpoints
    getUserProfile: (userId: number) => `https://users.roblox.com/v1/users/${userId}`,
    getUserInventory: (userId: number, assetType: string) => `https://inventory.roblox.com/v2/users/${userId}/inventory/${assetType}`,
    getUserCreations: (userId: number) => `https://develop.roblox.com/v1/users/${userId}/assets`,

    // Group endpoints
    getGroupInfo: (groupId: number) => `https://groups.roblox.com/v1/groups/${groupId}`,
    getGroupRoles: (groupId: number) => `https://groups.roblox.com/v1/groups/${groupId}/roles`,
    getGroupMembers: (groupId: number, roleId?: number) => `https://groups.roblox.com/v1/groups/${groupId}/users${roleId ? `?roleId=${roleId}` : ''}`,
    getGroupGames: (groupId: number) => `https://games.roblox.com/v2/groups/${groupId}/games`,
    getGroupAssets: (groupId: number) => `https://develop.roblox.com/v1/groups/${groupId}/assets`,

    // Game endpoints
    getGameInfo: (universeId: string) => `https://games.roblox.com/v1/games?universeIds=${universeId}`,
    getGamePasses: (universeId: string) => `https://games.roblox.com/v1/games/${universeId}/game-passes`,
    getGameBadges: (universeId: string) => `https://badges.roblox.com/v1/universes/${universeId}/badges`,
    getDeveloperProducts: (universeId: string) => `https://apis.roblox.com/developer-products/v1/universe-developer-products?universeId=${universeId}`,
    getGameThumbnails: (universeId: string) => `https://thumbnails.roblox.com/v1/games/multiget/thumbnails?universeIds=${universeId}&countPerUniverse=5&size=768x432&format=Png`,

    // Creator Hub endpoints
    creatorHubModels: 'https://create.roblox.com/marketplace/asset-type/Model',
    creatorHubMeshes: 'https://create.roblox.com/marketplace/asset-type/Mesh',
    creatorHubAnimations: 'https://create.roblox.com/marketplace/asset-type/Animation',
    creatorHubDecals: 'https://create.roblox.com/marketplace/asset-type/Decal',
    creatorHubAudio: 'https://create.roblox.com/marketplace/asset-type/Audio',
    creatorHubPlugins: 'https://create.roblox.com/marketplace/asset-type/Plugin',
  }
};

export class EnhancedRobloxScanner {
  private lastRequestTime = 0;
  private domainBackoff: Map<string, number> = new Map();
  private scanInProgress = false;

  constructor() {
    console.log('Enhanced Roblox Scanner initialized with dev product tracking');
  }

  /**
   * Extract domain from URL for rate limiting
   */
  private extractDomain(url: string): string {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch (e) {
      return 'unknown';
    }
  }

  /**
   * Wait for rate limit before making a request
   */
  private async waitForRateLimit(url: string): Promise<void> {
    const now = Date.now();
    const domain = this.extractDomain(url);

    const backoff = this.domainBackoff.get(domain) || 1000;
    const timeSinceLastRequest = now - this.lastRequestTime;

    if (timeSinceLastRequest < backoff) {
      const waitTime = backoff - timeSinceLastRequest;
      console.log(`Rate limiting: Waiting ${waitTime}ms for ${domain}`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }

    this.lastRequestTime = Date.now();
  }

  /**
   * Make a request with rate limiting and error handling
   */
  private async makeRequest(url: string, headers = {}): Promise<any> {
    await this.waitForRateLimit(url);

    const defaultHeaders = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'User-Agent': 'Pet Simulator 99 Asset Tracker/1.0',
      ...headers
    };

    try {
      const response = await axios.get(url, { 
        headers: defaultHeaders,
        timeout: 10000,
        validateStatus: (status) => status < 500 // Don't throw on 4xx errors
      });

      // Decrease backoff on success
      const domain = this.extractDomain(url);
      let currentBackoff = this.domainBackoff.get(domain) || 1000;
      if (currentBackoff > 1000) {
        currentBackoff = Math.max(1000, Math.floor(currentBackoff * 0.8));
        this.domainBackoff.set(domain, currentBackoff);
      }

      return response;
    } catch (error: any) {
      const domain = this.extractDomain(url);

      // Handle rate limiting
      if (error.response && error.response.status === 429) {
        const currentBackoff = this.domainBackoff.get(domain) || 1000;
        const newBackoff = Math.min(30000, currentBackoff * 2);
        this.domainBackoff.set(domain, newBackoff);

        console.log(`Rate limit exceeded for ${domain}. Increasing backoff to ${newBackoff}ms`);
      }

      throw error;
    }
  }

  /**
   * Scan high priority developers for new assets
   */
  async scanDeveloperAssets(): Promise<void> {
    console.log('Scanning tracked developers for assets...');

    let discoveredAssets = 0;

    for (const developer of TRACKED_DEVELOPERS.filter(dev => dev.priority <= 3)) {
      try {
        console.log(`Scanning developer: ${developer.username} (${developer.displayName}) - Priority ${developer.priority}`);

        // Enhanced tracking for chickenputty (Priority 1 PS99 Lead Developer)
        if (developer.id === 13365322) {
          console.log(`🎯 PRIORITY TRACKING: chickenputty (PS99 Lead Developer) - Full Scan`);

          // Track ALL asset types for priority developers
          const allAssetTypes = ['Model', 'Mesh', 'Animation', 'Decal', 'Audio', 'Package', 'Plugin', 'MeshPart', 'Place', 'Badge'];

          for (const assetType of allAssetTypes) {
            try {
              const inventoryUrl = ROBLOX_ENDPOINTS.endpoints.getUserInventory(developer.id, assetType);
              const response = await this.makeRequest(inventoryUrl);

              if (response.status === 200 && response.data?.data) {
                // Scan MORE assets for priority developers
                for (const asset of response.data.data.slice(0, 25)) {
                  const discovered = await this.processAssetDiscovery(asset, {
                    source: `PriorityDev:${developer.username}`,
                    priority: developer.priority,
                    developerInfo: developer,
                    isPriorityTarget: true
                  });

                  if (discovered) {
                    discoveredAssets++;
                    console.log(`🔥 NEW ASSET from ${developer.username}: ${asset.name} (${assetType})`);
                  }
                }
              }
            } catch (error) {
              console.error(`Error scanning ${assetType} for priority dev ${developer.username}:`, (error as Error).message);
            }
          }

          // Additional endpoints for priority developers
          try {
            // Scan user favorites
            const favoritesUrl = `https://catalog.roblox.com/v1/search/users/${developer.id}/favorites`;
            const favResponse = await this.makeRequest(favoritesUrl);

            if (favResponse.status === 200 && favResponse.data?.data) {
              for (const asset of favResponse.data.data.slice(0, 10)) {
                await this.processAssetDiscovery(asset, {
                  source: `PriorityDevFavorites:${developer.username}`,
                  priority: developer.priority,
                  developerInfo: developer
                });
              }
            }
          } catch (error) {
            console.error(`Error scanning favorites for ${developer.username}:`, error);
          }

        } else {
          // Standard tracking for other developers
          const assetTypes = ['Model', 'Mesh', 'Animation', 'Decal', 'Audio', 'Package'];

          for (const assetType of assetTypes) {
            try {
              const inventoryUrl = ROBLOX_ENDPOINTS.endpoints.getUserInventory(developer.id, assetType);
              const response = await this.makeRequest(inventoryUrl);

              if (response.status === 200 && response.data?.data) {
                for (const asset of response.data.data.slice(0, 10)) {
                  const discovered = await this.processAssetDiscovery(asset, {
                    source: `Developer:${developer.username}`,
                    priority: developer.priority,
                    developerInfo: developer
                  });

                  if (discovered) discoveredAssets++;
                }
              }
            } catch (error) {
              console.error(`Error scanning ${assetType} for ${developer.username}:`, (error as Error).message);
            }
          }
        }

        // Scan user creations for ALL developers
        try {
          const creationsUrl = ROBLOX_ENDPOINTS.endpoints.getUserCreations(developer.id);
          const response = await this.makeRequest(creationsUrl);

          if (response.status === 200 && response.data?.data) {
            const creationLimit = developer.id === 13365322 ? 15 : 5; // More for priority devs
            for (const asset of response.data.data.slice(0, creationLimit)) {
              const discovered = await this.processAssetDiscovery(asset, {
                source: `DeveloperCreations:${developer.username}`,
                priority: developer.priority,
                developerInfo: developer
              });

              if (discovered) discoveredAssets++;
            }
          }
        } catch (error) {
          console.error(`Error scanning creations for ${developer.username}:`, (error as Error).message);
        }

        // Rate limiting - less delay for priority developers
        const delay = developer.priority === 1 ? 500 : 1000;
        await new Promise(resolve => setTimeout(resolve, delay));

      } catch (error) {
        console.error(`Error scanning developer ${developer.username}:`, (error as Error).message);
      }
    }

    console.log(`Developer scan complete. Discovered ${discoveredAssets} new assets.`);
  }

  /**
   * Scan tracked groups for new content
   */
  async scanGroupAssets(): Promise<void> {
    console.log('Scanning tracked groups for assets...');

    let discoveredAssets = 0;

    for (const group of TRACKED_GROUPS) {
      try {
        console.log(`Scanning group: ${group.name} (${group.id})`);

        // Scan group games
        const gamesUrl = ROBLOX_ENDPOINTS.endpoints.getGroupGames(group.id);
        const gamesResponse = await this.makeRequest(gamesUrl);

        if (gamesResponse.status === 200 && gamesResponse.data?.data) {
          for (const game of gamesResponse.data.data) {
            // Scan game passes
            try {
              const gamePassesUrl = ROBLOX_ENDPOINTS.endpoints.getGamePasses(game.id);
              const passesResponse = await this.makeRequest(gamePassesUrl);

              if (passesResponse.status === 200 && passesResponse.data?.data) {
                for (const gamePass of passesResponse.data.data) {
                  const discovered = await this.processAssetDiscovery(gamePass, {
                    source: `GroupGamePass:${group.name}`,
                    priority: group.priority,
                    groupInfo: group,
                    gameInfo: game
                  });

                  if (discovered) discoveredAssets++;
                }
              }
            } catch (error) {
              console.error(`Error scanning game passes for ${game.name}:`, (error as Error).message);
            }

            // Scan developer products
            try {
              const devProductsUrl = ROBLOX_ENDPOINTS.endpoints.getDeveloperProducts(game.id);
              const productsResponse = await this.makeRequest(devProductsUrl);

              if (productsResponse.status === 200 && productsResponse.data?.data) {
                for (const product of productsResponse.data.data) {
                  const discovered = await this.processAssetDiscovery(product, {
                    source: `GroupDevProduct:${group.name}`,
                    priority: group.priority,
                    groupInfo: group,
                    gameInfo: game
                  });

                  if (discovered) discoveredAssets++;
                }
              }
            } catch (error) {
              console.error(`Error scanning dev products for ${game.name}:`, (error as Error).message);
            }

            // Scan game badges
            try {
              const badgesUrl = ROBLOX_ENDPOINTS.endpoints.getGameBadges(game.id);
              const badgesResponse = await this.makeRequest(badgesUrl);

              if (badgesResponse.status === 200 && badgesResponse.data?.data) {
                for (const badge of badgesResponse.data.data) {
                  const discovered = await this.processAssetDiscovery(badge, {
                    source: `GroupGameBadge:${group.name}`,
                    priority: group.priority,
                    groupInfo: group,
                    gameInfo: game
                  });

                  if (discovered) discoveredAssets++;
                }
              }
            } catch (error) {
              console.error(`Error scanning badges for ${game.name}:`, (error as Error).message);
            }
          }
        }

      } catch (error) {
        console.error(`Error scanning group ${group.name}:`, (error as Error).message);
      }
    }

    console.log(`Group scan complete. Discovered ${discoveredAssets} new assets.`);
  }

  /**
   * Scan Pet Simulator 99 game specifically
   */
  async scanPS99Game(): Promise<void> {
    console.log('Scanning Pet Simulator 99 game for new content...');

    let discoveredAssets = 0;

    try {
      // Scan PS99 game passes
      const gamePassesUrl = ROBLOX_ENDPOINTS.endpoints.getGamePasses(PS99_GAME_INFO.universeId);
      const passesResponse = await this.makeRequest(gamePassesUrl);

      if (passesResponse.status === 200 && passesResponse.data?.data) {
        for (const gamePass of passesResponse.data.data) {
          const discovered = await this.processAssetDiscovery(gamePass, {
            source: 'PS99:GamePass',
            priority: 1,
            gameInfo: PS99_GAME_INFO
          });

          if (discovered) discoveredAssets++;
        }
      }

      // Scan PS99 developer products
      const devProductsUrl = ROBLOX_ENDPOINTS.endpoints.getDeveloperProducts(PS99_GAME_INFO.universeId);
      const productsResponse = await this.makeRequest(devProductsUrl);

      if (productsResponse.status === 200 && productsResponse.data?.data) {
        for (const product of productsResponse.data.data) {
          const discovered = await this.processAssetDiscovery(product, {
            source: 'PS99:DeveloperProduct',
            priority: 1,
            gameInfo: PS99_GAME_INFO
          });

          if (discovered) discoveredAssets++;
        }
      }

      // Scan PS99 badges
      const badgesUrl = ROBLOX_ENDPOINTS.endpoints.getGameBadges(PS99_GAME_INFO.universeId);
      const badgesResponse = await this.makeRequest(badgesUrl);

      if (badgesResponse.status === 200 && badgesResponse.data?.data) {
        for (const badge of badgesResponse.data.data) {
          const discovered = await this.processAssetDiscovery(badge, {
            source: 'PS99:Badge',
            priority: 1,
            gameInfo: PS99_GAME_INFO
          });

          if (discovered) discoveredAssets++;
        }
      }

    } catch (error) {
      console.error('Error scanning PS99 game:', (error as Error).message);
    }

    console.log(`PS99 game scan complete. Discovered ${discoveredAssets} new assets.`);
  }

  /**
   * Scan Creator Hub endpoints for PS99-related content
   */
  async scanCreatorHub(): Promise<void> {
    console.log('Scanning Creator Hub for PS99-related assets...');

    let discoveredAssets = 0;
    const creatorEndpoints = [
      { url: ROBLOX_ENDPOINTS.endpoints.creatorHubModels, type: 'Model' },
      { url: ROBLOX_ENDPOINTS.endpoints.creatorHubMeshes, type: 'Mesh' },
      { url: ROBLOX_ENDPOINTS.endpoints.creatorHubAnimations, type: 'Animation' },
      { url: ROBLOX_ENDPOINTS.endpoints.creatorHubDecals, type: 'Decal' },
      { url: ROBLOX_ENDPOINTS.endpoints.creatorHubAudio, type: 'Audio' },
    ];

    for (const endpoint of creatorEndpoints) {
      try {
        // Search for PS99-related keywords
        for (const keyword of PS99_KEYWORDS.slice(0, 3)) { // Limit keywords to avoid rate limiting
          const searchUrl = `${endpoint.url}?keyword=${encodeURIComponent(keyword)}&limit=10`;
          const response = await this.makeRequest(searchUrl);

          if (response.status === 200 && response.data?.data) {
            for (const asset of response.data.data) {
              const discovered = await this.processAssetDiscovery(asset, {
                source: `CreatorHub:${endpoint.type}`,
                priority: 3,
                searchKeyword: keyword
              });

              if (discovered) discoveredAssets++;
            }
          }
        }
      } catch (error) {
        console.error(`Error scanning Creator Hub ${endpoint.type}:`, (error as Error).message);
      }
    }

    console.log(`Creator Hub scan complete. Discovered ${discoveredAssets} new assets.`);
  }

  /**
   * Process and save discovered asset
   */
  private async processAssetDiscovery(assetData: any, context: any): Promise<boolean> {
    try {
      const assetId = assetData.id || assetData.assetId || assetData.productId;
      if (!assetId) return false;

      // Check if asset already exists
      const existingAsset = await storage.getAssetByAssetId(assetId.toString());
      if (existingAsset) return false;

      // Extract asset information
      const assetInfo = {
        assetId: assetId.toString(),
        name: assetData.name || assetData.displayName || `Asset ${assetId}`,
        creator: context.developerInfo?.displayName || context.groupInfo?.name || assetData.creator?.name || 'Unknown',
        creatorId: context.developerInfo?.id?.toString() || context.groupInfo?.id?.toString() || assetData.creator?.id?.toString(),
        description: assetData.description || '',
        category: assetData.assetType || assetData.productType || context.source?.split(':')[1] || 'Unknown',
        sourceGroup: context.groupInfo?.name || context.source,
        thumbnailUrl: assetData.thumbnail?.url || null,
        robloxUrl: `https://www.roblox.com/catalog/${assetId}`,
        assetType: assetData.assetType || context.source?.split(':')[1] || 'Unknown',
        isVerified: false,
        isExclusive: this.isPS99Related(assetData.name || ''),
        metadata: {
          discoveryContext: context,
          robloxData: assetData,
          scanSource: context.source,
          priority: context.priority,
          discoveredAt: new Date().toISOString()
        }
      };

      // Create asset and discovery record
      const asset = await storage.createAsset(assetInfo);
      const discovery = await storage.createDiscovery({
        assetId: asset.assetId,
        discoveryType: 'new',
        sourceEndpoint: context.source,
        rawData: assetData,
        webhookSent: false
      });

      console.log(`Discovered new asset: ${asset.name} (${asset.assetId}) from ${context.source}`);
      return true;

    } catch (error) {
      console.error('Error processing asset discovery:', (error as Error).message);
      return false;
    }
  }

  /**
   * Check if asset name is PS99 related
   */
  private isPS99Related(name: string): boolean {
    const lowerName = name.toLowerCase();
    return PS99_KEYWORDS.some(keyword => lowerName.includes(keyword.toLowerCase()));
  }

    /**
   * Comprehensive chickenputty (13365322) tracking using ALL systems
   */
  async scanChickenputtyComprehensive(): Promise<void> {
    const chickenputty = TRACKED_DEVELOPERS.find(dev => dev.id === 13365322);
    if (!chickenputty) {
      console.log('❌ chickenputty not found in tracked developers');
      return;
    }

    console.log('🎯 COMPREHENSIVE TRACKING: chickenputty (PS99 Lead Developer)');

    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    let totalDiscovered = 0;

    try {
      // 1. Asset Inventory Scan (ALL types)
      const allAssetTypes = ['Model', 'Mesh', 'Animation', 'Decal', 'Audio', 'Package', 'Plugin', 'MeshPart', 'Place', 'Badge', 'GamePass'];

      for (const assetType of allAssetTypes) {
        try {
          const inventoryUrl = ROBLOX_ENDPOINTS.endpoints.getUserInventory(chickenputty.id, assetType);
          const response = await this.makeRequest(inventoryUrl);

          if (response.status === 200 && response.data?.data) {
            for (const asset of response.data.data) {
              const discovered = await this.processAssetDiscovery(asset, {
                source: `ChickenputtyTracking:${assetType}`,
                priority: 1,
                developerInfo: chickenputty,
                isPriorityTarget: true
              });
              if (discovered) totalDiscovered++;
            }
          }
        } catch (error) {
          console.error(`Error scanning ${assetType} for chickenputty:`, error);
        }
      }

      // 2. User Creations Deep Scan
      try {
        const creationsUrl = ROBLOX_ENDPOINTS.endpoints.getUserCreations(chickenputty.id);
        const response = await this.makeRequest(creationsUrl);

        if (response.status === 200 && response.data?.data) {
          for (const asset of response.data.data) {
            const discovered = await this.processAssetDiscovery(asset, {
              source: `ChickenputtyCreations`,
              priority: 1,
              developerInfo: chickenputty
            });
            if (discovered) totalDiscovered++;
          }
        }
      } catch (error) {
        console.error('Error scanning chickenputty creations:', error);
      }

      // 3. PS99 Game Asset Tracking
      const ps99PlaceId = "8737899170";
      try {
        // Convert place to universe
        const { convertPlaceToUniverse } = await import('./utils/convertPlaceToUniverse');
        const universeId = await convertPlaceToUniverse(ps99PlaceId);

        console.log(`🎮 Tracking PS99 Universe ${universeId} for chickenputty assets`);

        // Scan game passes
        const gamePassUrl = ROBLOX_ENDPOINTS.endpoints.getGamePasses(ps99PlaceId);
        const passResponse = await this.makeRequest(gamePassUrl);

        if (passResponse.status === 200 && passResponse.data?.data) {
          for (const gamePass of passResponse.data.data) {
            if (gamePass.seller && gamePass.seller.id === chickenputty.id) {
              await this.processAssetDiscovery(gamePass, {
                source: `ChickenputtyPS99GamePass`,
                priority: 1,
                developerInfo: chickenputty,
                gameInfo: { placeId: ps99PlaceId, universeId }
              });
              totalDiscovered++;
            }
          }
        }

        // Scan developer products via our dev product scanner
        const { devProductScanner } = await import('./devProductScanner');
        console.log('🔧 Running dev product scan for PS99...');
        await devProductScanner.performFullScan();

      } catch (error) {
        console.error('Error in PS99 tracking:', error);
      }

      // 4. Group Asset Tracking (if chickenputty is in tracked groups)
      for (const group of TRACKED_GROUPS) {
        try {
          // Check if chickenputty is in this group (would need API call)
          const groupGamesUrl = ROBLOX_ENDPOINTS.endpoints.getGroupGames(group.id);
          const groupResponse = await this.makeRequest(groupGamesUrl);

          if (groupResponse.status === 200 && groupResponse.data?.data) {
            for (const game of groupResponse.data.data) {
              // Check if chickenputty contributed to this game
              console.log(`📋 Checking group ${group.name} game: ${game.name}`);
            }
          }
        } catch (error) {
          console.error(`Error scanning group ${group.name}:`, error);
        }
      }

      console.log(`✅ Chickenputty comprehensive scan complete: ${totalDiscovered} new assets discovered`);

      // Auto-post discoveries to Discord
      if (totalDiscovered > 0) {
        try {
          await discordWebhook.sendMessage({
            embeds: [{
              title: '🎯 Priority Developer Activity',
              description: `**chickenputty** (PS99 Lead Developer) - ${totalDiscovered} new assets discovered`,
              color: 0xFF0000,
              timestamp: new Date().toISOString(),
              footer: { text: 'PS99 Asset Tracker' }
            }]
          });
        } catch (error) {
          console.error('Error sending chickenputty update to Discord:', error);
        }
      }

    } catch (error) {
      console.error('Error in comprehensive chickenputty tracking:', error);
    }
  }

  /**
   * Perform full comprehensive scan
   */
  async performFullScan(): Promise<void> {
    if (this.scanInProgress) {
      console.log('Scan already in progress, skipping...');
      return;
    }

    this.scanInProgress = true;
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    console.log('🔍 Starting enhanced Roblox scan (7-day leak detection only)...');

    try {
      await storage.updateScannerStatus('Enhanced Scanner', {
        isActive: true,
        lastScanAt: new Date(),
        scanCount: 0,
        errorCount: 0
      });

      // Run all scan types
      const robloxResults = []; // Collect results from individual scans

      // Helper function to execute scan and collect results
      const executeScan = async (scanFunction: () => Promise<void>, resultsArray: any[]) => {
          try {
              const result = await scanFunction();
              if (result) {
                  resultsArray.push(result);
              }
          } catch (error) {
              console.error("Scan failed:", error);
          }
      };

      console.log('Starting comprehensive PS99 asset scan...');

      // 0. Priority Developer Comprehensive Tracking (chickenputty)
      await this.scanChickenputtyComprehensive();

      // 1. Developer Asset Scanning
      await this.scanDeveloperAssets();

      // 2. Group Asset Scanning  
      await this.scanGroupAssets();

      // 3. Developer Product Scanning (integrated from dev-product-scanner)
      await this.scanPS99Game();

      // 4. Place to Universe ID conversion and comprehensive scanning
      await this.scanAllUniverseIds();

      // 5. Additional dev scanner methods integration
      await this.performDevScannerMethods();

      await storage.updateScannerStatus('Enhanced Scanner', {
        isActive: true,
        lastScanAt: new Date(),
        nextScanAt: new Date(Date.now() + 15 * 60 * 1000), // Next scan in 15 minutes
        scanCount: 1
      });

      // Run comprehensive scanning with ALL dev scanner base methods
      console.log('🔧 Executing ALL dev scanner base methods...');

      // 1. Comprehensive Place-to-Universe scanning
      const { convertPlaceToUniverse } = await import('./utils/convertPlaceToUniverse');
      const ps99UniverseId = await convertPlaceToUniverse(PS99_GAME_INFO.placeId);
      PS99_GAME_INFO.universeId = ps99UniverseId;
      console.log(`✅ PS99 Universe ID resolved: ${ps99UniverseId}`);

      // 2. Run integrated dev product scanner 
      const { devProductScanner } = await import('./devProductScanner');
      const devProductResults = await devProductScanner.performFullScan();
      console.log(`✅ Dev product scan complete: ${devProductResults.length} places scanned`);

      // 3. Get recent discoveries from storage (last 7 days only)
      const recentDiscoveries = await storage.getDiscoveries({ 
        limit: 100,
        since: sevenDaysAgo 
      });

      // Filter to only NEW assets discovered in last 7 days
      const newLeaksOnly = recentDiscoveries.filter(discovery => {
        const discoveryDate = new Date(discovery.discoveredAt);
        return discoveryDate >= sevenDaysAgo && !discovery.webhookSent;
      });

      // Auto-post NEW leaks only (last 7 days)
      for (const discovery of newLeaksOnly) {
        try {
          // Get full asset data
          const asset = await storage.getAssetByAssetId(discovery.assetId);
          if (asset) {
            const { discordWebhook } = await import('../discordWebhook');
            await discordWebhook.sendAssetDiscovery(asset);

            // Mark as sent
            await storage.updateDiscovery(discovery.id, { webhookSent: true });
            console.log(`✅ Posted NEW LEAK to Discord: ${asset.name} (${discovery.discoveryType})`);
          }
        } catch (error) {
          console.error(`❌ Failed to post leak to Discord:`, error);
        }
      }

      const totalChanges = devProductResults.reduce((sum, result) => sum + result.changes.length, 0);

      console.log(`✅ Enhanced scan completed (LEAK DETECTION - 7 days):
        - ${newLeaksOnly.length} new assets found (last 7 days)
        - ${totalChanges} developer product changes detected
        - Auto-posted ${newLeaksOnly.length + totalChanges} items to Discord
      `);

      console.log('Comprehensive scan completed successfully');

    } catch (error) {
      console.error('Error during comprehensive scan:', (error as Error).message);

      await storage.updateScannerStatus('Enhanced Scanner', {
        isActive: true,
        lastError: (error as Error).message,
        errorCount: 1
      });
    } finally {
      this.scanInProgress = false;
    }
  }

    /**
   * Scan ALL Universe IDs
   */
  async scanAllUniverseIds(): Promise<void> {
    console.log("Scanning all universe IDs...");
    // TODO: Implement the logic to fetch and scan all universe IDs
  }

  /**
   * Perform ALL Dev Scanner Methods
   */
  async performDevScannerMethods(): Promise<void> {
    console.log("Performing all dev scanner methods...");
    // TODO: Implement the logic to perform all dev scanner methods
  }
}

export const enhancedScanner = new EnhancedRobloxScanner();