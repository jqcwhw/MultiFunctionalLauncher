import { storage } from '../storage';
import type { InsertAsset } from '@shared/schema';

export class AssetProcessor {
  async processAsset(asset: InsertAsset): Promise<void> {
    try {
      // Check for duplicates
      const existing = await storage.getAssetByAssetId(asset.assetId);
      if (existing) {
        // Update existing asset if needed
        await this.updateExistingAsset(existing, asset);
        return;
      }

      // Enhanced categorization
      asset.category = this.enhancedCategorization(asset);
      
      // Verify asset authenticity
      asset.isVerified = this.verifyAsset(asset);
      
      // Check for exclusive content
      asset.isExclusive = this.checkExclusivity(asset);
      
      // Store processed asset
      await storage.createAsset(asset);
      
      console.log(`Processed new asset: ${asset.name} (${asset.assetId})`);
      
    } catch (error) {
      console.error(`Failed to process asset ${asset.assetId}:`, error);
    }
  }

  private async updateExistingAsset(existing: any, newData: InsertAsset): Promise<void> {
    const hasChanges = 
      existing.name !== newData.name ||
      existing.description !== newData.description ||
      existing.thumbnailUrl !== newData.thumbnailUrl;

    if (hasChanges) {
      await storage.updateAsset(existing.assetId, {
        name: newData.name,
        description: newData.description,
        thumbnailUrl: newData.thumbnailUrl,
        updatedAt: new Date()
      });

      // Create discovery record for update
      await storage.createDiscovery({
        assetId: existing.assetId,
        discoveryType: 'updated',
        sourceEndpoint: newData.sourceGroup || '',
        rawData: newData.metadata,
        webhookSent: false
      });

      console.log(`Updated existing asset: ${existing.name} (${existing.assetId})`);
    }
  }

  private enhancedCategorization(asset: InsertAsset): string {
    const name = (asset.name || '').toLowerCase();
    const description = (asset.description || '').toLowerCase();
    const combined = `${name} ${description}`;

    // Pet categories
    if (combined.match(/\b(pet|companion|buddy|animal|creature)\b/)) {
      if (combined.includes('titanic')) return 'Titanic Pet';
      if (combined.includes('huge')) return 'Huge Pet';
      if (combined.includes('exclusive')) return 'Exclusive Pet';
      if (combined.includes('legendary')) return 'Legendary Pet';
      if (combined.includes('mythical')) return 'Mythical Pet';
      return 'Pet';
    }

    // Egg categories
    if (combined.match(/\b(egg|hatch)\b/)) {
      if (combined.includes('exclusive')) return 'Exclusive Egg';
      if (combined.includes('limited')) return 'Limited Egg';
      return 'Egg';
    }

    // Item categories
    if (combined.match(/\b(potion|boost|elixir)\b/)) return 'Potion';
    if (combined.match(/\b(enchant|charm|blessing)\b/)) return 'Enchant';
    if (combined.match(/\b(area|world|zone|biome|realm)\b/)) return 'Area';
    if (combined.match(/\b(accessory|hat|gear|item)\b/)) return 'Accessory';
    if (combined.match(/\b(hoverboard|mount|vehicle)\b/)) return 'Mount';
    if (combined.match(/\b(currency|coin|gem|diamond)\b/)) return 'Currency';

    // Game mechanics
    if (combined.match(/\b(minigame|game|activity)\b/)) return 'Minigame';
    if (combined.match(/\b(quest|mission|task)\b/)) return 'Quest';
    if (combined.match(/\b(achievement|badge|reward)\b/)) return 'Achievement';

    return asset.category || 'Unknown';
  }

  private verifyAsset(asset: InsertAsset): boolean {
    // Check if creator is verified Big Games developer
    if (asset.creatorId) {
      const creatorId = parseInt(asset.creatorId);
      const isVerifiedDev = [
        19717956,   // BuildIntoGames (Owner)
        1210210,    // ForeverDev
        63844404,   // Aspernator
        2882755487, // CoderJoey
        2878290231, // CoderMitchell
        13365322,   // chickenputty
        2213470865, // CoderConner
        7707349,    // JamienChee
        3983340648, // CoderTony
        1784060946  // ZambieTheBoolean
      ].includes(creatorId);
      
      if (isVerifiedDev) return true;
    }

    // Check if from verified source group
    const verifiedSources = [
      'BIG Games Pets',
      'BIG Games™',
      'BIG Games Experimental',
      'BIG Games Super Fun'
    ];
    
    return verifiedSources.some(source => 
      asset.sourceGroup?.includes(source)
    );
  }

  private checkExclusivity(asset: InsertAsset): boolean {
    const name = (asset.name || '').toLowerCase();
    const description = (asset.description || '').toLowerCase();
    const combined = `${name} ${description}`;

    const exclusiveKeywords = [
      'titanic', 'huge', 'exclusive', 'limited', 'secret', 
      'dev', 'admin', 'staff', 'special', 'rare', 'ultra',
      'legendary', 'mythical', 'divine', 'cosmic', 'void'
    ];

    return exclusiveKeywords.some(keyword => 
      combined.includes(keyword)
    );
  }
}
