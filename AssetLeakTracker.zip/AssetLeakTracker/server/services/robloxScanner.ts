import axios from 'axios';
import { SCANNER_CONFIG } from '../config/scannerConfig';
import { storage } from '../storage';
import type { InsertAsset, InsertDiscovery } from '@shared/schema';

export class RobloxScanner {
  private rateLimitDelay = 1000; // 1 second between requests
  private lastRequestTime = 0;

  private async makeRequest(url: string, params?: any) {
    // Implement rate limiting
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    if (timeSinceLastRequest < this.rateLimitDelay) {
      await new Promise(resolve => setTimeout(resolve, this.rateLimitDelay - timeSinceLastRequest));
    }
    this.lastRequestTime = Date.now();

    try {
      const response = await axios.get(url, { params, timeout: 10000 });
      return response.data;
    } catch (error: any) {
      if (error.response?.status === 429) {
        // Rate limited - increase delay and retry
        this.rateLimitDelay = Math.min(this.rateLimitDelay * 2, 10000);
        await new Promise(resolve => setTimeout(resolve, this.rateLimitDelay));
        return this.makeRequest(url, params);
      }
      throw error;
    }
  }

  async performFullScan(): Promise<InsertAsset[]> {
    const newAssets: InsertAsset[] = [];
    
    try {
      // Update scanner status
      await storage.updateScannerStatus('Full Scan', {
        isActive: true,
        lastScanAt: new Date(),
        nextScanAt: new Date(Date.now() + SCANNER_CONFIG.SCAN_INTERVALS.FULL_SCAN)
      });

      // Scan by keywords
      for (const keyword of SCANNER_CONFIG.SEARCH_KEYWORDS) {
        const assets = await this.scanByKeyword(keyword);
        newAssets.push(...assets);
      }

      // Scan by developers
      for (const developerId of SCANNER_CONFIG.DEVELOPER_IDS.slice(0, 10)) { // Limit to avoid rate limits
        const assets = await this.scanByDeveloper(developerId);
        newAssets.push(...assets);
      }

      // Scan groups
      for (const groupId of SCANNER_CONFIG.GROUP_IDS) {
        const assets = await this.scanByGroup(groupId);
        newAssets.push(...assets);
      }

      console.log(`Full scan completed. Found ${newAssets.length} new assets.`);
      return newAssets;

    } catch (error) {
      console.error('Full scan failed:', error);
      await storage.updateScannerStatus('Full Scan', {
        isActive: false,
        lastError: error instanceof Error ? error.message : 'Unknown error',
        errorCount: 1
      });
      return [];
    }
  }

  async performScan(source: string): Promise<InsertAsset[]> {
    const newAssets: InsertAsset[] = [];
    
    try {
      await storage.updateScannerStatus(source, {
        isActive: true,
        lastScanAt: new Date()
      });

      if (source.includes('Group')) {
        const groupId = SCANNER_CONFIG.GROUP_IDS.find(id => source.includes(id.toString()));
        if (groupId) {
          const assets = await this.scanByGroup(groupId);
          newAssets.push(...assets);
        }
      } else if (source.includes('Developer')) {
        // Scan recent developer activity
        for (const developerId of SCANNER_CONFIG.DEVELOPER_IDS.slice(0, 5)) {
          const assets = await this.scanByDeveloper(developerId);
          newAssets.push(...assets);
        }
      }

      return newAssets;

    } catch (error) {
      console.error(`Scan failed for ${source}:`, error);
      await storage.updateScannerStatus(source, {
        isActive: false,
        lastError: error instanceof Error ? error.message : 'Unknown error'
      });
      return [];
    }
  }

  private async scanByKeyword(keyword: string): Promise<InsertAsset[]> {
    try {
      const data = await this.makeRequest(SCANNER_CONFIG.ROBLOX_ENDPOINTS.CATALOG, {
        keyword,
        category: 'All',
        limit: 50,
        sortType: 'Updated'
      });

      return this.processAssetResults(data.data || [], `Keyword: ${keyword}`);
    } catch (error) {
      console.error(`Keyword scan failed for ${keyword}:`, error);
      return [];
    }
  }

  private async scanByDeveloper(developerId: number): Promise<InsertAsset[]> {
    try {
      // Get user info first
      const userInfo = await this.makeRequest(`${SCANNER_CONFIG.ROBLOX_ENDPOINTS.USERS}/${developerId}`);
      
      // Search for assets by this developer
      const data = await this.makeRequest(SCANNER_CONFIG.ROBLOX_ENDPOINTS.CATALOG, {
        creatorName: userInfo.name,
        limit: 30,
        sortType: 'Updated'
      });

      return this.processAssetResults(data.data || [], `Developer: ${userInfo.name}`);
    } catch (error) {
      console.error(`Developer scan failed for ${developerId}:`, error);
      return [];
    }
  }

  private async scanByGroup(groupId: number): Promise<InsertAsset[]> {
    try {
      // Get group info
      const groupInfo = await this.makeRequest(`${SCANNER_CONFIG.ROBLOX_ENDPOINTS.GROUPS}/${groupId}`);
      
      // Search for assets by this group
      const data = await this.makeRequest(SCANNER_CONFIG.ROBLOX_ENDPOINTS.CATALOG, {
        creatorName: groupInfo.name,
        limit: 30,
        sortType: 'Updated'
      });

      return this.processAssetResults(data.data || [], `Group: ${groupInfo.name}`);
    } catch (error) {
      console.error(`Group scan failed for ${groupId}:`, error);
      return [];
    }
  }

  private async processAssetResults(results: any[], source: string): Promise<InsertAsset[]> {
    const newAssets: InsertAsset[] = [];

    for (const item of results) {
      try {
        // Check if asset already exists
        const existing = await storage.getAssetByAssetId(item.id?.toString());
        if (existing) continue;

        // Get thumbnail
        const thumbnailData = await this.makeRequest(`${SCANNER_CONFIG.ROBLOX_ENDPOINTS.THUMBNAILS}`, {
          assetIds: item.id,
          size: '150x150',
          format: 'Png'
        });

        const asset: InsertAsset = {
          assetId: item.id?.toString() || '',
          name: item.name || 'Unknown Asset',
          creator: item.creatorName || 'Unknown',
          creatorId: item.creatorId?.toString(),
          description: item.description,
          category: this.categorizeAsset(item),
          sourceGroup: source,
          thumbnailUrl: thumbnailData.data?.[0]?.imageUrl,
          robloxUrl: `https://www.roblox.com/catalog/${item.id}`,
          assetType: item.assetType || 'Unknown',
          isVerified: this.isVerifiedCreator(item.creatorId),
          isExclusive: this.isExclusiveAsset(item),
          metadata: {
            robloxData: item,
            discoverySource: source,
            scanTimestamp: new Date().toISOString()
          }
        };

        // Store asset
        await storage.createAsset(asset);
        
        // Create discovery record
        await storage.createDiscovery({
          assetId: asset.assetId,
          discoveryType: 'new',
          sourceEndpoint: source,
          rawData: item,
          webhookSent: false
        });

        newAssets.push(asset);
        
      } catch (error) {
        console.error(`Failed to process asset ${item.id}:`, error);
      }
    }

    return newAssets;
  }

  private categorizeAsset(item: any): string {
    const name = (item.name || '').toLowerCase();
    
    if (name.includes('pet') || name.includes('companion')) return 'Pet';
    if (name.includes('egg')) return 'Egg';
    if (name.includes('potion') || name.includes('boost')) return 'Potion';
    if (name.includes('area') || name.includes('world') || name.includes('zone')) return 'Area';
    if (name.includes('accessory') || name.includes('hat') || name.includes('gear')) return 'Accessory';
    if (name.includes('titanic') || name.includes('huge')) return 'Exclusive';
    
    return item.assetType || 'Unknown';
  }

  private isVerifiedCreator(creatorId: any): boolean {
    return SCANNER_CONFIG.DEVELOPER_IDS.includes(parseInt(creatorId?.toString() || '0'));
  }

  private isExclusiveAsset(item: any): boolean {
    const name = (item.name || '').toLowerCase();
    return name.includes('titanic') || 
           name.includes('huge') || 
           name.includes('exclusive') || 
           name.includes('limited') ||
           name.includes('secret');
  }
}
