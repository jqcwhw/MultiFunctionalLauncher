
import axios from 'axios';
import { SCANNER_CONFIG } from '../config/scannerConfig';
import type { DevProductChange } from './utils/devProductTypes';

class DiscordWebhookService {
  private webhookUrl: string;

  constructor() {
    this.webhookUrl = SCANNER_CONFIG.DISCORD_WEBHOOK_URL;
  }

  async sendDevProductDiscovery(change: DevProductChange): Promise<void> {
    if (!this.webhookUrl) {
      console.warn('No Discord webhook URL configured');
      return;
    }

    const embed = this.createDevProductEmbed(change);
    
    try {
      await axios.post(this.webhookUrl, {
        embeds: [embed],
        username: 'PS99 Leak Tracker',
        avatar_url: 'https://cdn.discordapp.com/icons/1234567890/avatar.png'
      });
    } catch (error) {
      console.error('Failed to send Discord webhook:', error);
      throw error;
    }
  }

  private createDevProductEmbed(change: DevProductChange) {
    const { product, type, placeName, oldProduct } = change;
    
    const isNewItem = type === 'NEW_ITEM';
    const color = isNewItem ? 0x00ff00 : 0xffaa00; // Green for new, Orange for updates
    
    let description = `**${isNewItem ? '🆕 NEW LEAK' : '🔄 UPDATED'}** from ${placeName}`;
    
    if (type === 'NEW_PRICE' && oldProduct) {
      description += `\n💰 Price changed: ~~${oldProduct.PriceInRobux}~~ → **${product.PriceInRobux}** Robux`;
    } else if (type === 'NEW_NAME' && oldProduct) {
      description += `\n📝 Name changed: ~~${oldProduct.Name}~~ → **${product.Name}**`;
    } else if (type === 'NEW_DESCRIPTION') {
      description += `\n📄 Description updated`;
    } else if (type === 'NEW_IMAGE') {
      description += `\n🖼️ Icon updated`;
    }

    const embed = {
      title: `${product.Name}`,
      description,
      color,
      fields: [
        {
          name: '💎 Price',
          value: `${product.PriceInRobux} Robux`,
          inline: true
        },
        {
          name: '🏪 Place',
          value: placeName,
          inline: true
        },
        {
          name: '🆔 Product ID',
          value: product.DeveloperProductId.toString(),
          inline: true
        }
      ],
      thumbnail: {
        url: product.IconImageAssetId 
          ? `https://assetdelivery.roblox.com/v1/asset/?id=${product.IconImageAssetId}`
          : undefined
      },
      footer: {
        text: `PS99 Leak Tracker • ${new Date().toLocaleString()}`,
        icon_url: 'https://cdn.discordapp.com/icons/1234567890/avatar.png'
      },
      url: `https://www.roblox.com/catalog/${product.DeveloperProductId}`
    };

    if (product.Description) {
      embed.fields.push({
        name: '📝 Description',
        value: product.Description.substring(0, 1024),
        inline: false
      });
    }

    return embed;
  }

  async sendAssetDiscovery(asset: any): Promise<void> {
    if (!this.webhookUrl) return;

    const embed = {
      title: `🔍 New Asset Discovered: ${asset.name}`,
      description: `New asset found from verified source`,
      color: 0x0099ff,
      fields: [
        {
          name: '👤 Creator',
          value: asset.creator,
          inline: true
        },
        {
          name: '📁 Category',
          value: asset.category,
          inline: true
        },
        {
          name: '🔗 Asset ID',
          value: asset.assetId,
          inline: true
        }
      ],
      thumbnail: {
        url: asset.thumbnailUrl || undefined
      },
      footer: {
        text: `PS99 Asset Tracker • ${new Date().toLocaleString()}`
      },
      url: asset.robloxUrl
    };

    if (asset.description) {
      embed.fields.push({
        name: '📝 Description', 
        value: asset.description.substring(0, 1024),
        inline: false
      });
    }

    try {
      await axios.post(this.webhookUrl, {
        embeds: [embed],
        username: 'PS99 Asset Tracker',
        avatar_url: 'https://cdn.discordapp.com/icons/1234567890/avatar.png'
      });
    } catch (error) {
      console.error('Failed to send asset discovery webhook:', error);
      throw error;
    }
  }
}

export const discordWebhook = new DiscordWebhookService();
