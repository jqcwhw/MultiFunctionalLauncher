/**
 * Developer Product Types and Constants
 * Integrated from dev-product-scanner
 */

export class DevProductChangeTypes {
    static readonly NEW_ITEM = "newItem";
    static readonly NEW_PRICE = "newPrice";
    static readonly NEW_IMAGE = "newImage";
    static readonly NEW_NAME = "newName";
    static readonly NEW_DESCRIPTION = "newDescription";
}

export interface DeveloperProduct {
    ProductId: number;
    DeveloperProductId: number;
    Name: string;
    Description: string;
    IconImageAssetId: number | null;
    displayName?: string;
    displayDescription?: string;
    displayIcon?: number;
    PriceInRobux: number;
    placeId: number;
    universeId?: string;
}

export interface DevProductChange {
    type: keyof typeof DevProductChangeTypes;
    product: DeveloperProduct;
    oldProduct?: DeveloperProduct;
    placeName: string;
    channelId?: string;
}

export interface DevProductScanResult {
    placeId: string;
    placeName: string;
    changes: DevProductChange[];
    totalProducts: number;
    newProducts: number;
    updatedProducts: number;
    errors: string[];
}

export interface DevProductFetchOptions {
  limit?: number;
  includeInactive?: boolean;
  robloxCookie?: string;
  cursor?: string;
  sortOrder?: 'Asc' | 'Desc';
}

export interface PlaceToUniverseResult {
  placeId: string;
  universeId: string;
  convertedAt: Date;
}

export interface ComprehensiveScanResult {
  totalPlaces: number;
  totalProducts: number;
  totalChanges: number;
  methodsUsed: string[];
  scanDuration: number;
  errors: string[];
}

// Validation helpers
export function validateDeveloperProduct(product: any): product is DeveloperProduct {
    return (
        typeof product === 'object' &&
        typeof product.DeveloperProductId === 'number' &&
        typeof product.Name === 'string' &&
        typeof product.PriceInRobux === 'number' &&
        typeof product.placeId === 'number'
    );
}

export function validateField(value: any): string {
    return value !== null && value !== undefined ? value.toString() : "N/A";
}

// Price formatting utilities
export function formatRobux(amount: number): string {
    return amount.toLocaleString() + " R$";
}

export function calculatePriceChange(oldPrice: number, newPrice: number): {
    difference: number;
    percentChange: number;
    changeType: 'increase' | 'decrease' | 'same';
} {
    const difference = newPrice - oldPrice;
    const percentChange = oldPrice > 0 ? (difference / oldPrice) * 100 : 0;

    let changeType: 'increase' | 'decrease' | 'same';
    if (difference > 0) changeType = 'increase';
    else if (difference < 0) changeType = 'decrease';
    else changeType = 'same';

    return {
        difference,
        percentChange: Math.round(percentChange * 100) / 100,
        changeType
    };
}

// Asset URL builders
export function buildDevProductUrl(developerProductId: number): string {
    return `https://roblox.com/developer-products/${developerProductId}`;
}

export function buildAssetThumbnailUrl(assetId: number | null): string | null {
    if (!assetId) return null;
    return `https://rbxgleaks.pythonanywhere.com/asset/${assetId}`;
}

export function buildRobloxAssetUrl(assetId: number | null): string | null {
    if (!assetId) return null;
    return `https://assetdelivery.roblox.com/v1/asset/?id=${assetId}`;
}