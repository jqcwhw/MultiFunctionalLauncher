
/**
 * Convert Place ID to Universe ID - From dev scanner base folder
 */

import axios from 'axios';

const placeToUniverseCache = new Map<string, string>();

export async function convertPlaceToUniverse(placeId: string): Promise<string> {
  // Check cache first
  if (placeToUniverseCache.has(placeId)) {
    return placeToUniverseCache.get(placeId)!;
  }

  try {
    // Method 1: Use games API
    const response = await axios.get(`https://apis.roblox.com/universes/v1/places/${placeId}/universe`, {
      timeout: 10000,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'PS99AssetTracker/1.0'
      }
    });

    if (response.data?.universeId) {
      const universeId = response.data.universeId.toString();
      placeToUniverseCache.set(placeId, universeId);
      console.log(`✅ Converted place ${placeId} to universe ${universeId}`);
      return universeId;
    }
  } catch (error) {
    console.log(`Method 1 failed for place ${placeId}, trying method 2...`);
  }

  try {
    // Method 2: Use alternative endpoint
    const response = await axios.get(`https://games.roblox.com/v1/games/multiget-place-details?placeIds=${placeId}`, {
      timeout: 10000,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'PS99AssetTracker/1.0'
      }
    });

    if (response.data && response.data.length > 0 && response.data[0]?.universeId) {
      const universeId = response.data[0].universeId.toString();
      placeToUniverseCache.set(placeId, universeId);
      console.log(`✅ Converted place ${placeId} to universe ${universeId} (method 2)`);
      return universeId;
    }
  } catch (error) {
    console.log(`Method 2 failed for place ${placeId}, trying method 3...`);
  }

  try {
    // Method 3: Parse from place page
    const response = await axios.get(`https://www.roblox.com/games/${placeId}`, {
      timeout: 10000,
      headers: {
        'Accept': 'text/html',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    const html = response.data;
    const universeMatch = html.match(/data-universe-id="(\d+)"/);
    
    if (universeMatch && universeMatch[1]) {
      const universeId = universeMatch[1];
      placeToUniverseCache.set(placeId, universeId);
      console.log(`✅ Converted place ${placeId} to universe ${universeId} (method 3)`);
      return universeId;
    }
  } catch (error) {
    console.error(`All methods failed for place ${placeId}:`, error);
  }

  // Fallback: return place ID as universe ID (sometimes they're the same)
  console.log(`⚠️ Using place ID ${placeId} as universe ID (fallback)`);
  placeToUniverseCache.set(placeId, placeId);
  return placeId;
}

export function clearCache(): void {
  placeToUniverseCache.clear();
}

export function getCacheSize(): number {
  return placeToUniverseCache.size;
}
