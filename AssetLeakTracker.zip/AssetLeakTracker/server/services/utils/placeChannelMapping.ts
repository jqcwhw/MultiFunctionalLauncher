/**
 * Place Channel Mapping - From dev scanner base folder
 * Maps Roblox place IDs to Discord channel IDs for targeted notifications
 */

interface PlaceChannelMapping {
  placeId: string;
  placeName: string;
  channelId: string;
  priority: number;
}

class PlaceChannelMappingService {
  private mappings: PlaceChannelMapping[] = [
    {
      placeId: "8737899170", // Pet Simulator 99
      placeName: "Pet Simulator 99",
      channelId: "ps99-leaks", // Default channel name
      priority: 1
    },
    {
      placeId: "15502302041", // Dev Pet Simulator 99  
      placeName: "Pet Simulator 99 [BETA]",
      channelId: "ps99-dev-leaks",
      priority: 1
    },
    {
      placeId: "15588442388", // Pro Trading Plaza
      placeName: "Pro Trading Plaza",
      channelId: "trading-plaza-leaks", 
      priority: 2
    }
  ];

  getAllPlaceIds(): string[] {
    return this.mappings.map(mapping => mapping.placeId);
  }

  getAllChannelIds(): string[] {
    return this.mappings.map(mapping => mapping.channelId);
  }

  getChannelForPlace(placeId: string): string | undefined {
    const mapping = this.mappings.find(m => m.placeId === placeId);
    return mapping?.channelId;
  }

  getPlaceForChannel(channelId: string): string | undefined {
    const mapping = this.mappings.find(m => m.channelId === channelId);
    return mapping?.placeId;
  }

  getAllMappings(): PlaceChannelMapping[] {
    return [...this.mappings];
  }

  addMapping(placeId: string, placeName: string, channelId: string, priority: number = 3): void {
    this.mappings.push({ placeId, placeName, channelId, priority });
  }

  removeMapping(placeId: string): void {
    this.mappings = this.mappings.filter(m => m.placeId !== placeId);
  }
}

export const placeChannelMapping = new PlaceChannelMappingService();