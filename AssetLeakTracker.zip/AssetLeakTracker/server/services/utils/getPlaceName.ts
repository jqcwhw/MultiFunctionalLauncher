
/**
 * Get Place Name - From dev scanner base folder
 */

import axios from 'axios';

const placeNameCache = new Map<string, string>();

export async function getPlaceName(placeId: string): Promise<string> {
  // Check cache first
  if (placeNameCache.has(placeId)) {
    return placeNameCache.get(placeId)!;
  }

  try {
    // Method 1: Use games API
    const response = await axios.get(`https://games.roblox.com/v1/games/multiget-place-details?placeIds=${placeId}`, {
      timeout: 10000,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'PS99AssetTracker/1.0'
      }
    });

    if (response.data && response.data.length > 0 && response.data[0]?.name) {
      const placeName = response.data[0].name;
      placeNameCache.set(placeId, placeName);
      console.log(`✅ Resolved place ${placeId} name: ${placeName}`);
      return placeName;
    }
  } catch (error) {
    console.log(`Method 1 failed for place ${placeId}, trying method 2...`);
  }

  try {
    // Method 2: Parse from place page
    const response = await axios.get(`https://www.roblox.com/games/${placeId}`, {
      timeout: 10000,
      headers: {
        'Accept': 'text/html',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    const html = response.data;
    
    // Try to extract title from meta tags
    let titleMatch = html.match(/<meta property="og:title" content="([^"]+)"/);
    if (!titleMatch) {
      titleMatch = html.match(/<title>([^<]+)<\/title>/);
    }
    
    if (titleMatch && titleMatch[1]) {
      let placeName = titleMatch[1].replace(' - Roblox', '').trim();
      placeNameCache.set(placeId, placeName);
      console.log(`✅ Resolved place ${placeId} name: ${placeName} (method 2)`);
      return placeName;
    }
  } catch (error) {
    console.error(`All methods failed for place ${placeId}:`, error);
  }

  // Fallback name
  const fallbackName = `Place ${placeId}`;
  placeNameCache.set(placeId, fallbackName);
  return fallbackName;
}

export function clearPlaceNameCache(): void {
  placeNameCache.clear();
}

export function getPlaceNameCacheSize(): number {
  return placeNameCache.size;
}
