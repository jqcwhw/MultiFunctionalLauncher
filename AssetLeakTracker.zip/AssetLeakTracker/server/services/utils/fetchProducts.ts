/**
 * Product Fetcher - From dev scanner base folder
 * Fetches developer products from Roblox places using multiple methods
 */

import axios from 'axios';
import { convertPlaceToUniverse } from './convertPlaceToUniverse';

export interface DeveloperProduct {
  ProductId: number;
  DeveloperProductId: number;
  Name: string;
  Description: string;
  IconImageAssetId: number | null;
  PriceInRobux: number;
  placeId: number;
  universeId?: number;
}

interface FetchOptions {
  robloxCookie?: string;
  includeInactive?: boolean;
  limit?: number;
}

class ProductFetcher {
  private async makeRequest(url: string, options: FetchOptions = {}): Promise<any> {
    const headers: any = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'User-Agent': 'PS99AssetTracker/1.0'
    };

    if (options.robloxCookie) {
      headers['Cookie'] = `.ROBLOSECURITY=${options.robloxCookie}`;
      headers['X-CSRF-TOKEN'] = 'placeholder'; // Will be handled by axios interceptors
    }

    try {
      const response = await axios.get(url, { 
        headers,
        timeout: 10000,
        validateStatus: (status) => status < 500
      });

      return response;
    } catch (error) {
      console.error(`Request failed for ${url}:`, error);
      throw error;
    }
  }

  async fetchProducts(placeId: string, options: FetchOptions = {}): Promise<DeveloperProduct[]> {
    try {
      // Convert place ID to universe ID
      const universeId = await convertPlaceToUniverse(placeId);

      // Try multiple endpoints
      const endpoints = [
        `https://games.roblox.com/v1/games/${placeId}/developer-products`,
        `https://apis.roblox.com/developer-products/v1/universe-developer-products?universeId=${universeId}`,
        `https://economy.roblox.com/v2/developer-products/universe/${universeId}`
      ];

      let products: DeveloperProduct[] = [];

      for (const endpoint of endpoints) {
        try {
          console.log(`Trying endpoint: ${endpoint}`);
          const response = await this.makeRequest(endpoint, options);

          if (response.status === 200 && response.data?.data) {
            const fetchedProducts = response.data.data.map((product: any) => ({
              ProductId: product.ProductId || product.id,
              DeveloperProductId: product.DeveloperProductId || product.id,
              Name: product.Name || product.name,
              Description: product.Description || product.description || '',
              IconImageAssetId: product.IconImageAssetId || product.iconImageAssetId,
              PriceInRobux: product.PriceInRobux || product.priceInRobux || 0,
              placeId: parseInt(placeId),
              universeId: parseInt(universeId)
            }));

            products.push(...fetchedProducts);
            console.log(`✅ Fetched ${fetchedProducts.length} products from ${endpoint}`);
            break; // Use first successful endpoint
          }
        } catch (error) {
          console.log(`❌ Endpoint ${endpoint} failed:`, error);
          continue;
        }
      }

      // Filter duplicates
      const uniqueProducts = products.filter((product, index, self) => 
        index === self.findIndex(p => p.DeveloperProductId === product.DeveloperProductId)
      );

      // Filter inactive products if requested
      if (!options.includeInactive) {
        return uniqueProducts.filter(product => product.PriceInRobux > 0);
      }

      return uniqueProducts;

    } catch (error) {
      console.error(`Error fetching products for place ${placeId}:`, error);
      return [];
    }
  }

  async fetchMultiplePlaces(placeIds: string[], options: FetchOptions = {}): Promise<Map<string, DeveloperProduct[]>> {
    const results = new Map<string, DeveloperProduct[]>();

    for (const placeId of placeIds) {
      try {
        const products = await this.fetchProducts(placeId, options);
        results.set(placeId, products);

        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error(`Failed to fetch products for place ${placeId}:`, error);
        results.set(placeId, []);
      }
    }

    return results;
  }
}

export const productFetcher = new ProductFetcher();