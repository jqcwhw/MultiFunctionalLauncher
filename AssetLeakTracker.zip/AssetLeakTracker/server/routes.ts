import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { z } from "zod";
import { insertAssetSchema, insertDiscoverySchema } from "@shared/schema";
import cron from "node-cron";
import { RobloxScanner } from "./services/robloxScanner";
import { enhancedScanner } from "./services/enhancedRobloxScanner";
import { devProductScanner } from "./services/devProductScanner";
import { devProductEmbedService } from "./services/devProductEmbedService";
import { discordWebhook } from "./services/discordWebhook";
import { AssetProcessor } from "./services/assetProcessor";

const robloxScanner = new RobloxScanner();
const assetProcessor = new AssetProcessor();

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const broadcast = (data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  // Assets API
  app.get("/api/assets", async (req, res) => {
    try {
      const { limit = 50, offset = 0, category, verified, exclusive } = req.query;
      const assets = await storage.getAssets({
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
        category: category as string,
        verified: verified === 'true',
        exclusive: exclusive === 'true'
      });
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assets" });
    }
  });

  app.get("/api/assets/:assetId", async (req, res) => {
    try {
      const asset = await storage.getAssetByAssetId(req.params.assetId);
      if (!asset) {
        return res.status(404).json({ error: "Asset not found" });
      }
      res.json(asset);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch asset" });
    }
  });

  // Recent discoveries API
  app.get('/api/discoveries', async (req, res) => {
    try {
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const discoveries = await storage.getDiscoveries({ 
        limit: 50,
        since: sevenDaysAgo 
      });
      res.json(discoveries);
    } catch (error) {
      console.error('Error fetching discoveries:', error);
      res.status(500).json({ error: 'Failed to fetch discoveries' });
    }
  });

  // Scanner status API
  app.get("/api/scanner/status", async (req, res) => {
    try {
      const statuses = await storage.getScannerStatuses();
      res.json(statuses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch scanner status" });
    }
  });

  // Manual scan trigger
  app.post("/api/scanner/scan", async (req, res) => {
    try {
      const { source } = req.body;
      await robloxScanner.performScan(source);
      res.json({ success: true, message: "Scan initiated" });
    } catch (error) {
      res.status(500).json({ error: "Failed to initiate scan" });
    }
  });

  // Test webhook
  app.post("/api/webhook/test", async (req, res) => {
    try {
      const result = await discordWebhook.sendTestMessage();
      res.json({ success: true, result });
    } catch (error) {
      res.status(500).json({ error: "Failed to send test webhook" });
    }
  });

  // Statistics API
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });

  // Webhook logs API
  app.get("/api/webhook/logs", async (req, res) => {
    try {
      const { limit = 50 } = req.query;
      const logs = await storage.getWebhookLogs(parseInt(limit as string));
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch webhook logs" });
    }
  });

  // Update asset verification
  app.patch("/api/assets/:assetId/verify", async (req, res) => {
    try {
      const { verified } = req.body;
      await storage.updateAssetVerification(req.params.assetId, verified);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update asset verification" });
    }
  });

  // Export data
  app.get("/api/export/assets", async (req, res) => {
    try {
      const assets = await storage.getAllAssets();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="ps99-assets.json"');
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: "Failed to export assets" });
    }
  });

  // Schedule automated scans with enhanced scanner and dev products
  cron.schedule('*/15 * * * *', async () => {
    console.log('Running comprehensive automated scan...');
    try {
      // Run enhanced scanner
      await enhancedScanner.performFullScan();

      // Run developer product scanner
      const devProductResults = await devProductScanner.performFullScan();

      // Send Discord notifications for dev product changes
      for (const result of devProductResults) {
        for (const change of result.changes) {
          try {
            await devProductEmbedService.sendChangeNotification(change);
          } catch (embedError) {
            console.error('Failed to send dev product Discord notification:', embedError);
          }
        }
      }

      // Get recent discoveries to broadcast
      const discoveries = await storage.getRecentDiscoveries(10);

      for (const discovery of discoveries) {
        if (!discovery.webhookSent) {
          // Send Discord notification
          await discordWebhook.sendDiscoveryNotification(discovery);

          // Broadcast to connected WebSocket clients
          broadcast({
            type: 'new_discovery',
            data: discovery
          });
        }
      }

      // Broadcast scan status update
      broadcast({
        type: 'scan_completed',
        data: {
          timestamp: new Date().toISOString(),
          devProductChanges: devProductResults.reduce((sum, r) => sum + r.changes.length, 0),
          enhancedScanCompleted: true
        }
      });

    } catch (error) {
      console.error('Automated scan failed:', error);
    }
  });

  // Manual scan trigger for immediate testing
  app.post("/api/scanner/scan", async (req, res) => {
    try {
      console.log('Manual comprehensive scan triggered...');

      // Run both enhanced scanner and dev product scanner
      const [enhancedResults, devProductResults] = await Promise.allSettled([
        enhancedScanner.performFullScan(),
        devProductScanner.performFullScan()
      ]);

      const results = {
        enhanced: enhancedResults.status === 'fulfilled' ? 'success' : 'failed',
        devProducts: devProductResults.status === 'fulfilled' ? {
          status: 'success',
          results: devProductResults.value
        } : 'failed'
      };

      res.json({ 
        success: true, 
        message: 'Comprehensive scan completed',
        results
      });
    } catch (error) {
      console.error('Manual scan failed:', error);
      res.status(500).json({ error: "Failed to initiate scan" });
    }
  });

  // Developer products specific endpoints
  app.get("/api/dev-products/places", async (req, res) => {
    try {
      const mappings = devProductScanner.getPlaceMappings();
      res.json(mappings);
    } catch (error) {
      res.status(500).json({ error: "Failed to get place mappings" });
    }
  });

  // Manual dev product scan with ALL methods
  app.post("/api/dev-products/scan", async (req, res) => {
    try {
      console.log('🚀 Starting comprehensive dev product scan with ALL base methods...');
      const results = await devProductScanner.performFullScan();
      res.json({ 
        success: true, 
        results,
        message: 'Comprehensive scan completed using ALL dev scanner base methods'
      });
    } catch (error) {
      console.error('Dev product scan failed:', error);
      res.status(500).json({ error: "Failed to scan developer products" });
    }
  });

  // Test all dev scanner utilities
  app.get("/api/dev-scanner/test-utilities", async (req, res) => {
    try {
      const { convertPlaceToUniverse } = await import('./services/utils/convertPlaceToUniverse');
      const { getPlaceName } = await import('./services/utils/getPlaceName');
      const { placeChannelMapping } = await import('./services/utils/placeChannelMapping');
      const { productFetcher } = await import('./services/utils/fetchProducts');

      // Test all utilities
      const testPlaceId = '8737899170'; // PS99

      const results = {
        placeToUniverse: await convertPlaceToUniverse(testPlaceId),
        placeName: await getPlaceName(testPlaceId),
        channelMapping: placeChannelMapping.getChannelForPlace(testPlaceId),
        allMappings: placeChannelMapping.getAllMappings(),
        allPlaceIds: placeChannelMapping.getAllPlaceIds(),
        productFetchTest: await productFetcher.fetchProducts(testPlaceId, { limit: 5 })
      };

      res.json({ success: true, results, message: 'All dev scanner utilities tested successfully' });
    } catch (error) {
      console.error('Utility test failed:', error);
      res.status(500).json({ error: "Failed to test utilities" });
    }
  });

  // Schedule status updates
  cron.schedule('*/30 * * * * *', async () => {
    try {
      const statuses = await storage.getScannerStatuses();
      broadcast({
        type: 'scanner_status',
        data: statuses
      });

      const stats = await storage.getStats();
      broadcast({
        type: 'stats_update',
        data: stats
      });
    } catch (error) {
      console.error('Status update failed:', error);
    }
  });

  return httpServer;
}