/**
 * PS99 Developer and Asset Tracking Configuration
 * Based on dev scanner base folder specifications
 */

// PS99 Main Game Configuration
export const PS99_GAME_INFO = {
  placeId: "8737899170", // Pet Simulator 99 main place
  universeId: "", // Will be resolved dynamically
  name: "Pet Simulator 99",
  creator: "Big Games"
};

// Priority developers from chickenputty profile and PS99 team
export const TRACKED_DEVELOPERS = [
  // Priority 1 - Lead PS99 Developer
  {
    id: 13365322,
    username: "chickenputty",
    displayName: "chickenputty",
    priority: 1,
    role: "PS99 Lead Developer",
    isVerified: true,
    trackAllAssets: true
  },

  // Priority 2 - Core PS99 Team (from affiliates/staff)
  {
    id: 1547288,
    username: "BuildIntoGames",
    displayName: "Preston",
    priority: 2,
    role: "Big Games Founder",
    isVerified: true
  },
  {
    id: 168476,
    username: "ChickenEngineer",
    displayName: "ChickenEngineer",
    priority: 2,
    role: "PS99 Engineer",
    isVerified: true
  },

  // Priority 3 - PS99 Staff and Contributors
  {
    id: 0, // Will be resolved from profile
    username: "CoderMitchell",
    displayName: "Coder Mitchell",
    priority: 3,
    role: "PS99 Developer"
  },
  {
    id: 0, // Will be resolved from profile
    username: "CoderTony",
    displayName: "Coder Tony",
    priority: 3,
    role: "PS99 Developer"
  },
  {
    id: 0, // Will be resolved from profile
    username: "ForeverDev",
    displayName: "David (ForeverDev)",
    priority: 3,
    role: "PS99 Developer"
  }
];

// Big Games and affiliated groups
export const TRACKED_GROUPS = [
  {
    id: 5060810,
    name: "Big Games",
    priority: 1,
    isMainGroup: true
  },
  {
    id: 0, // To be resolved
    name: "Big Games Pets",
    priority: 2
  }
];

// PS99 related keywords for asset detection
export const PS99_KEYWORDS = [
  "pet simulator 99", "ps99", "big games pets", "pet sim",
  "pet simulator", "big games", "preston pets",
  "chickenmesh", "buildintogames", "chickenputty"
];

// Priority asset types to track
export const PRIORITY_ASSET_TYPES = [
  "Model", "Mesh", "Animation", "Decal", "Audio", "Package",
  "Plugin", "Place", "GamePass", "DeveloperProduct", "Badge"
];

export function getHighPriorityDevelopers() {
  return TRACKED_DEVELOPERS.filter(dev => dev.priority <= 2);
}

export function getAllDeveloperIds() {
  return TRACKED_DEVELOPERS.map(dev => dev.id).filter(id => id > 0);
}

export function getAllGroupIds() {
  return TRACKED_GROUPS.map(group => group.id).filter(id => id > 0);
}