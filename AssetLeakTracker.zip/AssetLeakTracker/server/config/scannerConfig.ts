export const SCANNER_CONFIG = {
  // Discord webhook URL from environment or fallback
  DISCORD_WEBHOOK_URL: process.env.DISCORD_WEBHOOK_URL || 
    "https://discord.com/api/webhooks/1372706521896714290/eyNmByLsMLHfa_UwYCc98dPW5aGYqMgkGwuGLvp7WI6mYPWD_ph9RpjH0iEBXYYwv5F8",

  // Big Games Group IDs to monitor
  GROUP_IDS: [
    3959677,  // BIG Games Pets
    2703304,  // BIG Games™
    4981455,  // BIG Games Experimental
    10026748, // BIG Games Super Fun
  ],

  // Verified BIG Games Developer IDs (Only tracking confirmed staff)
  DEVELOPER_IDS: [
    19717956,   // BuildIntoGames (Owner/Founder)
    1210210,    // ForeverDev (Lead Developer)
    63844404,   // Aspernator (Developer)
    2882755487, // CoderJoey (Developer) 
    2878290231, // CoderMitchell (Developer)
    13365322,   // chickenputty (Developer)
    2213470865, // CoderConner (Developer)
    7707349,    // JamienChee (Developer)
    3983340648, // CoderTony (Developer)
    1784060946, // ZambieTheBoolean (Developer)
    3687735502, // Additional verified dev
    100984526,  // Additional verified dev
    1909623504  // Additional verified dev
  ],

  // Current PS99 Places to monitor for leaks
  GAME_IDS: [
    "8737899170",   // Pet Simulator 99 (Main)
    "15502302041",  // Pet Simulator 99 (Development/Testing)
    "2262441883",   // Pet Simulator X (for comparison)
    "5378474052",   // Another PS99 testing place
    "13822889606"   // Additional PS99 place
  ],

  // Asset types to track
  ASSET_TYPES: [
    "Mesh", "Model", "Animation", "Decal", "Audio", "Package", 
    "Plugin", "Place", "GamePass"
  ],

  // Search keywords
  SEARCH_KEYWORDS: [
    "pet simulator 99", "ps99", "big games pets", "pet sim",
    "pet simulator", "big games", "preston pets", 
    "chickenmesh", "buildintogames"
  ],

  // Roblox API endpoints
  ROBLOX_ENDPOINTS: {
    CATALOG: "https://catalog.roblox.com/v1/search/items",
    ASSETS: "https://assetdelivery.roblox.com/v1/asset",
    THUMBNAILS: "https://thumbnails.roblox.com/v1/assets",
    USERS: "https://users.roblox.com/v1/users",
    GROUPS: "https://groups.roblox.com/v1/groups",
    GAMES: "https://games.roblox.com/v1/games"
  },

  // Rate limiting
  RATE_LIMITS: {
    REQUESTS_PER_MINUTE: 60,
    BURST_LIMIT: 10,
    RETRY_AFTER: 5000 // ms
  },

  // Scan intervals
  SCAN_INTERVALS: {
    FULL_SCAN: 2 * 60 * 1000,        // 2 minutes
    QUICK_SCAN: 30 * 1000,           // 30 seconds
    STATUS_UPDATE: 30 * 1000,        // 30 seconds
    RETRY_FAILED: 5 * 60 * 1000      // 5 minutes
  },
  // PS99 Game Places to monitor with universe conversion
  PS99_PLACES: [
    "8737899170",  // Pet Simulator 99 Main (Universe: 3317771874)
    "2262441883",  // Pet Simulator 99 Beta/Test  
    "5378474052"   // Pet Simulator 99 Additional
  ],

  // PS99 Universe IDs (converted from places)
  PS99_UNIVERSES: [
    "3317771874",  // Pet Simulator 99 Main Universe
  ]
};