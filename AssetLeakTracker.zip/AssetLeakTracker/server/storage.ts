import { 
  users, assets, discoveries, scannerStatus, webhookLogs,
  type User, type InsertUser, type Asset, type InsertAsset,
  type Discovery, type InsertDiscovery, type ScannerStatus, type InsertScannerStatus,
  type WebhookLog, type InsertWebhookLog
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, gte } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;

  // Asset methods
  getAssets(filters?: {
    category?: string;
    sourceGroup?: string;
    isVerified?: boolean;
    isExclusive?: boolean;
    since?: Date;
    limit?: number;
    offset?: number;
  }): Promise<Asset[]>;
  getAllAssets(): Promise<Asset[]>;
  getAssetByAssetId(assetId: string): Promise<Asset | undefined>;
  getAssetsByRobloxId(robloxId: string): Promise<Asset[]>;
  createAsset(insertAsset: InsertAsset): Promise<Asset>;
  updateAsset(assetId: string, updates: Partial<Asset>): Promise<Asset>;
  updateAssetVerification(assetId: string, isVerified: boolean): Promise<Asset>;

  // Discovery methods
  getRecentDiscoveries(limit?: number): Promise<Discovery[]>;
  createDiscovery(insertDiscovery: InsertDiscovery): Promise<Discovery>;
  updateDiscoveryWebhookStatus(discoveryId: string, sent: boolean): Promise<void>;
  updateDiscovery(id: string, updates: Partial<InsertDiscovery>): Promise<Discovery>;

  // Scanner status methods
  getScannerStatuses(): Promise<ScannerStatus[]>;
  updateScannerStatus(source: string, updates: Partial<ScannerStatus>): Promise<ScannerStatus>;

  // Webhook log methods
  getWebhookLogs(limit?: number): Promise<WebhookLog[]>;
  createWebhookLog(insertWebhookLog: InsertWebhookLog): Promise<WebhookLog>;

  // Stats methods
  getStats(): Promise<{
    totalAssets: number;
    recentDiscoveries: number;
    verifiedAssets: number;
    activeSources: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id.toString()));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Asset methods
  async getAssets(filters?: {
    category?: string;
    sourceGroup?: string;
    isVerified?: boolean;
    isExclusive?: boolean;
    since?: Date;
    limit?: number;
    offset?: number;
  }): Promise<Asset[]> {
    let query = db.select().from(assets).orderBy(desc(assets.discoveredAt));

    if (filters) {
      const conditions = [];

      if (filters.category) {
        conditions.push(eq(assets.category, filters.category));
      }

      if (filters.sourceGroup) {
        conditions.push(eq(assets.sourceGroup, filters.sourceGroup));
      }

      if (filters.isVerified !== undefined) {
        conditions.push(eq(assets.isVerified, filters.isVerified));
      }

      if (filters.isExclusive !== undefined) {
        conditions.push(eq(assets.isExclusive, filters.isExclusive));
      }

      if (filters.since) {
        conditions.push(gte(assets.discoveredAt, filters.since));
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }

      if (filters.limit) {
        query = query.limit(filters.limit);
      }

      if (filters.offset) {
        query = query.offset(filters.offset);
      }
    }

    return await query;
  }

  async getAllAssets(): Promise<Asset[]> {
    return await db.select().from(assets);
  }

  async getAssetByAssetId(assetId: string): Promise<Asset | undefined> {
    const [asset] = await db.select().from(assets).where(eq(assets.assetId, assetId));
    return asset || undefined;
  }

  async getAssetsByRobloxId(robloxId: string): Promise<Asset[]> {
    return await db
      .select()
      .from(assets)
      .where(eq(assets.assetId, robloxId))
      .orderBy(desc(assets.discoveredAt));
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const [asset] = await db
      .insert(assets)
      .values({
        id: crypto.randomUUID(),
        ...insertAsset,
      })
      .returning();
    return asset;
  }

  async updateAsset(assetId: string, updates: Partial<Asset>): Promise<Asset> {
    const [asset] = await db
      .update(assets)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(assets.assetId, assetId))
      .returning();
    return asset;
  }

  async updateAssetVerification(assetId: string, isVerified: boolean): Promise<Asset> {
    const [asset] = await db
      .update(assets)
      .set({ isVerified, updatedAt: new Date() })
      .where(eq(assets.assetId, assetId))
      .returning();
    return asset;
  }

  // Discovery methods
  async getRecentDiscoveries(limit = 50): Promise<Discovery[]> {
    return await db
      .select()
      .from(discoveries)
      .orderBy(desc(discoveries.discoveredAt))
      .limit(limit);
  }

  async createDiscovery(insertDiscovery: InsertDiscovery): Promise<Discovery> {
    const [discovery] = await db
      .insert(discoveries)
      .values(insertDiscovery)
      .returning();
    return discovery;
  }

  async updateDiscoveryWebhookStatus(discoveryId: string, sent: boolean): Promise<void> {
    await db
      .update(discoveries)
      .set({ 
        webhookSent: sent, 
        webhookSentAt: sent ? new Date() : null 
      })
      .where(eq(discoveries.id, discoveryId));
  }

  async updateDiscovery(id: string, updates: Partial<InsertDiscovery>): Promise<Discovery> {
    const [discovery] = await db
      .update(discoveries)
      .set(updates)
      .where(eq(discoveries.id, id))
      .returning();
    return discovery;
  }

  // Scanner status methods
  async getScannerStatuses(): Promise<ScannerStatus[]> {
    return await db.select().from(scannerStatus);
  }

  async updateScannerStatus(source: string, updates: Partial<ScannerStatus>): Promise<ScannerStatus> {
    const [status] = await db
      .update(scannerStatus)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(scannerStatus.source, source))
      .returning();

    if (!status) {
      // Create new scanner status if it doesn't exist
      const [newStatus] = await db
        .insert(scannerStatus)
        .values({
          id: crypto.randomUUID(),
          source,
          ...updates,
        })
        .returning();
      return newStatus;
    }

    return status;
  }

  // Webhook log methods
  async getWebhookLogs(limit = 50): Promise<WebhookLog[]> {
    return await db
      .select()
      .from(webhookLogs)
      .orderBy(desc(webhookLogs.sentAt))
      .limit(limit);
  }

  async createWebhookLog(insertWebhookLog: InsertWebhookLog): Promise<WebhookLog> {
    const [log] = await db
      .insert(webhookLogs)
      .values({
        id: crypto.randomUUID(),
        ...insertWebhookLog,
      })
      .returning();
    return log;
  }

  // Stats methods
  async getStats(): Promise<{
    totalAssets: number;
    recentDiscoveries: number;
    verifiedAssets: number;
    activeSources: number;
  }> {
    const [totalAssetsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(assets);

    const [recentDiscoveriesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(discoveries)
      .where(sql`discovered_at > NOW() - INTERVAL '24 hours'`);

    const [verifiedAssetsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(assets)
      .where(eq(assets.isVerified, true));

    const [activeSourcesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(scannerStatus)
      .where(eq(scannerStatus.isActive, true));

    return {
      totalAssets: totalAssetsResult.count || 0,
      recentDiscoveries: recentDiscoveriesResult.count || 0,
      verifiedAssets: verifiedAssetsResult.count || 0,
      activeSources: activeSourcesResult.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();