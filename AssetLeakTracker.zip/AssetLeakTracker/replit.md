# replit.md

## Overview

This is a comprehensive full-stack TypeScript application built as a Pet Simulator 99 (PS99) asset tracking system. The project monitors Roblox assets and developer products related to Big Games' Pet Simulator 99, automatically discovering new content, tracking price changes, and posting discoveries to Discord webhooks. It features a modern web dashboard for viewing and managing tracked assets, with integrated developer product scanning capabilities extracted from the original dev-product-scanner codebase.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
The application uses a monorepo structure with three main directories:
- `client/` - React frontend built with Vite
- `server/` - Express.js backend API
- `shared/` - Common TypeScript schemas and types

### Technology Stack
- **Frontend**: React 18, TypeScript, Vite, TailwindCSS, Shadcn/ui components
- **Backend**: Express.js, TypeScript, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time**: WebSocket connections for live updates
- **Styling**: TailwindCSS with custom Discord-themed design system
- **Build**: ESBuild for production bundling

## Key Components

### Frontend Architecture
- **Component Library**: Uses Radix UI primitives with custom styling via Shadcn/ui
- **State Management**: TanStack Query for server state, React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Updates**: WebSocket hook for live asset discoveries
- **UI Framework**: Custom Discord-themed design system with dark mode

### Backend Architecture
- **API Layer**: RESTful Express.js endpoints with TypeScript
- **Database Layer**: Drizzle ORM with PostgreSQL, type-safe queries
- **Services**: Modular service architecture including:
  - Enhanced Roblox scanner with comprehensive endpoint registry
  - Developer product scanner (integrated from dev-product-scanner)
  - Discord webhook and embed services
  - Asset processing and verification
- **Real-time**: WebSocket server for broadcasting live updates
- **Scheduling**: Cron jobs for automated scanning (15-minute intervals)

### Data Layer
The database schema includes:
- `users` - User authentication and management
- `assets` - Tracked Roblox assets with metadata
- `discoveries` - Asset discovery events and types
- `scanner_status` - Scanner monitoring and health tracking

## Data Flow

### Asset Discovery Pipeline
1. **Scheduled Scanning**: Cron jobs trigger scans of Roblox APIs and group endpoints
2. **Asset Processing**: New assets are categorized, verified, and enhanced with metadata
3. **Database Storage**: Processed assets stored with discovery tracking
4. **Real-time Broadcasting**: WebSocket clients receive live updates
5. **Discord Integration**: Webhook notifications sent for significant discoveries

### Client-Server Communication
- REST API for CRUD operations on assets and configuration
- WebSocket connection for real-time updates
- TanStack Query for efficient data fetching and caching

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL (serverless Postgres)
- **UI Components**: Radix UI primitives for accessible components
- **HTTP Client**: Axios for external API requests
- **Real-time**: Native WebSocket API
- **Validation**: Zod for runtime type checking
- **Styling**: TailwindCSS with PostCSS

### Roblox Integration
- Multiple Roblox API endpoints for asset discovery
- Group monitoring for Big Games affiliated groups
- Asset delivery endpoints for content access
- Rate limiting and error handling for API stability

### Discord Integration
- Webhook URL configuration for notifications
- Rich embed formatting for asset discoveries
- Webhook logging and retry mechanisms

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend development
- Express server with TypeScript compilation via tsx
- Database migrations handled by Drizzle Kit
- Environment variables for configuration

### Production Build
- Frontend: Vite production build with optimization
- Backend: ESBuild compilation to single bundle
- Static assets served from `dist/public`
- Database: Neon serverless PostgreSQL

### Environment Configuration
- `DATABASE_URL` - PostgreSQL connection string
- `DISCORD_WEBHOOK_URL` - Discord webhook for notifications
- `NODE_ENV` - Environment specification
- Additional configuration in `scannerConfig.ts`

### Key Architectural Decisions

**Database Choice**: PostgreSQL with Drizzle ORM chosen for type safety, complex queries, and serverless compatibility with Neon.

**Monorepo Structure**: Shared types and schemas between client/server reduce duplication and maintain consistency.

**Real-time Updates**: WebSocket integration provides live dashboard updates without polling overhead.

**Service Architecture**: Modular services (scanner, webhook, processor) enable independent testing and scaling.

**Developer Product Integration**: Full integration of dev-product-scanner codebase with TypeScript conversion and enhanced error handling.

**UI Framework**: Shadcn/ui with Radix primitives provides accessible, customizable components with minimal bundle size.

**Rate Limiting**: Built-in rate limiting for Roblox API requests prevents service disruption and maintains compliance.

## Recent Changes

### December 2024 - Dev Product Scanner Integration
- ✓ Extracted and integrated all dev-product-scanner files
- ✓ Created comprehensive developer product scanning services
- ✓ Added Discord embed generation for product changes (price, image, name, description)
- ✓ Implemented place-to-universe ID conversion utilities
- ✓ Added automated scanning for PS99 places (8737899170, 2262441883, 5378474052)
- ✓ Enhanced route handlers with dev product specific endpoints
- ✓ Integrated scheduled scanning with both enhanced scanner and dev products