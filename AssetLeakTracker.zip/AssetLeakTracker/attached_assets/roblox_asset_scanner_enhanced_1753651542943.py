"""
Enhanced PS99 Roblox Asset Scanner

This module provides advanced functionality to scan for Pet Simulator 99 assets and leaks
from key Roblox developer profiles, community groups, Creator Marketplace, game passes,
meshes, and other Roblox sources while bypassing rate limits and connection issues.

Key features:
- User profile monitoring (Preston/ChickenEngineer - 13365322)
- BIG Games Pets community group scanning
- Detection avoidance with rotating user agents and delayed requests
- Connection resilience with retry mechanism
- Image caching and automatic thumbnail downloading
"""

import os
import re
import time
import json
import random
import datetime
import logging
import requests
import cloudscraper
from urllib.parse import urlparse, parse_qs
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
CACHE_DIR = "static/images/assets"
ROBLOX_CREATORS = [
    # Key Users
    {"id": 13365322, "name": "ChickenEngineer", "type": "user"},      # Preston/ChickenEngineer
    {"id": 1784060946, "name": "ChiefJustus", "type": "user"},        # Chief Justus (BIG Games)
    {"id": 1909623504, "name": "BuildIntoGames", "type": "user"},     # BuildIntoGames
    {"id": 2213470865, "name": "LastPrestonStanding", "type": "user"}, # Last Preston Standing
    {"id": 3687735502, "name": "BigGamesExperimental", "type": "user"}, # BIG Games Experimental User
    {"id": 1210210, "name": "DavidBaszucki", "type": "user"},         # Builderman
    {"id": 7707349, "name": "Merely", "type": "user"},                # Merely (Pet Sim Dev)
    
    # Key Groups
    {"id": 3959677, "name": "BIG Games Pets", "type": "group"},       # BIG Games Pets community
    {"id": 2703304, "name": "BIG Games", "type": "group"},            # Main BIG Games group
    {"id": 4576779, "name": "Big Games", "type": "group"},            # Main Big Games group
    {"id": 5060810, "name": "BIG Games Staff", "type": "group"},      # BIG Games Staff
    {"id": 35517943, "name": "Last Preston Standing", "type": "group"}, # Last Preston Standing
    {"id": 4981455, "name": "BIG Games Experimental", "type": "group"}, # BIG Games Experimental
    {"id": 10026748, "name": "BIG Games Super Fun", "type": "group"}  # BIG Games Super Fun
]

# List of PS99 universe IDs to track - important test places
PS99_UNIVERSE_IDS = [
    15507705501,  # Main PS99 game
    15556369499,  # PS99 Testing place
    15334176966,  # t3sting place
    14828032573,  # david-guilds-dev
    15400370241,  # Additional testing place
    15489321053   # Possible PS99 experimental place
]

# Creator Hub paths to scan
CREATOR_HUB_PATHS = [
    "store/asset/118187424084318",  # Sample asset
    "store/models",                 # All models
    "store/decals",                 # Decals (possible textures/thumbnails)
    "store/meshes",                 # Meshes (3D models for pets/items)
    "store/plugins"                 # Plugins (might show development tools)
]

# Keywords to search for in asset names and descriptions
PS99_KEYWORDS = [
    # Pet types and rarities
    "pet", "pets", "huge", "huges", "huge pet", "huge pets", 
    "titanic", "titanics", "titanic pet", "titanic pets", 
    "gargantuan", "gargantuans", "gargantuan pet", "gargantuan pets",
    "exclusive", "exclusives", "exclusive pet", "exclusive pets",
    "mythical", "legendary", "special", "limited", "shiny", "rainbow", "golden",
    
    # Egg related
    "egg", "eggs", "hatch", "hatching", "egg capsule", "exclusive egg", "limited egg",
    "golden egg", "rainbow egg", "luck", "lucky", "superlock", "super luck",
    
    # Game areas and locations
    "area", "areas", "zone", "zones", "world", "worlds", "map", "maps", "place", "places",
    "anubis", "pyramid", "ice", "beach", "space", "jungle", "forest", "volcano", "cave",
    "island", "islands", "dimension", "dimensions", "realm", "realms", "heaven", "void",
    
    # Game mechanics
    "minigame", "minigames", "mini game", "mini games", 
    "event", "events", "seasonal", "holiday", "festive", "celebration",
    "update", "updates", "dev blog", "developer blog", "dev item", "dev gamepass", "dev product",
    
    # Items and collectibles
    "potion", "potions", "enchant", "enchants", "enchantment", "enchantments",
    "charm", "charms", "boost", "boosts", "gamepass", "passes", "pass", "merchant", "offer",
    "pack", "packs", "bundle", "bundles", "vip", "donation", "gift", "present",
    
    # Game features
    "trading", "merchant", "mining", "mine", "mines", "breakable", "breakables",
    "slime", "slimes", "factory", "factories", "tower", "towers", "dungeon", "dungeons",
    "boss", "bosses", "chest", "chests", "currency", "currencies", "gem", "gems", "coin", "coins", 
    "rainbow", "damage", "capacity", "speed", "magnet", "magnets", "fortune", "collection",
    
    # Specific PS99 relevant terms
    "simulator", "pet simulator", "ps99", "big games", "preston", "triplebyte",
    "triple coins", "triple damage", "triple hatch", "triple points", "triplex",
    
    # Development related
    "prototype", "test", "testing", "concept", "wip", "alpha", "beta", "dev-only",
    "feature", "upcoming", "sneak", "peek", "preview", "teaser", "release", "coming soon"
]

# Keywords to use in catalog searches
CATALOG_SEARCH_TERMS = [
    # Game names
    "pet simulator 99",
    "ps99",
    "pet simulator",
    
    # Publishers
    "big games",
    "big games pets",
    "big games experimental",
    
    # Pets & Rarities
    "huge pet",
    "titanic pet",
    "gargantuan pet",
    "exclusive pet",
    "mythical pet",
    "legendary pet",
    
    # Game passes and products
    "ps99 gamepass",
    "triple hatch",
    "lucky pass",
    "auto hatch",
    
    # Mechanics
    "breakable",
    "mining",
    "slime factory",
    "triple coins",
    
    # Special events
    "ps99 event",
    "ps99 update"
]

# Create cache directory
Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)

class RobloxAssetScanner:
    """Enhanced scanner for Roblox assets related to Pet Simulator 99"""

    def __init__(self):
        """Initialize the scanner with advanced configurations"""
        self.cache_dir = CACHE_DIR
        self._last_request_time = 0
        self._min_request_interval = 0.5  # Minimum time between requests in seconds
        self._consecutive_failures = 0
        self._max_consecutive_failures = 3
        
        logger.info(f"RobloxAssetScanner initialized with cache dir: {self.cache_dir}")
        
        # Initialize a session with retry capability
        self.session = self._create_resilient_session()
        
        # Initialize cloudscraper for bypassing protections
        self.scraper = cloudscraper.create_scraper(
            browser={
                'browser': 'chrome',
                'platform': 'windows',
                'desktop': True
            }
        )
        
        # Initialize user agent rotation
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.56'
        ]
        
        # Initial XSRF token (will be updated on first request)
        self.xsrf_token = None
    
    def _create_resilient_session(self) -> requests.Session:
        """Create a session with retry capabilities"""
        session = requests.Session()
        retry_strategy = Retry(
            total=5,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session
    
    def _get_headers(self, with_token=False) -> Dict[str, str]:
        """Get randomized headers to avoid detection"""
        headers = {
            "User-Agent": random.choice(self.user_agents),
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.roblox.com/",
            "Origin": "https://www.roblox.com",
            "Connection": "keep-alive",
            "DNT": "1",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
        }
        
        if with_token and self.xsrf_token:
            headers["X-CSRF-TOKEN"] = self.xsrf_token
            
        return headers
    
    def _update_xsrf_token(self):
        """Get a fresh XSRF token from Roblox"""
        try:
            response = self.session.post(
                "https://auth.roblox.com/v2/logout",
                headers=self._get_headers(),
                timeout=10
            )
            self.xsrf_token = response.headers.get("X-CSRF-TOKEN")
            return True
        except Exception as e:
            logger.error(f"Failed to obtain XSRF token: {e}")
            return False
    
    def _rate_limit_request(self):
        """Ensure requests don't exceed rate limits to avoid detection"""
        current_time = time.time()
        time_since_last_request = current_time - self._last_request_time
        
        # Add random jitter between 0 and 0.5 seconds
        jitter = random.uniform(0, 0.5)
        wait_time = max(0, self._min_request_interval - time_since_last_request + jitter)
        
        if wait_time > 0:
            time.sleep(wait_time)
            
        self._last_request_time = time.time()

    def _make_request(self, url: str, method: str = "GET", params: Optional[Dict] = None, 
                     data: Optional[Dict] = None, headers: Optional[Dict] = None,
                     use_cloudscraper: bool = False, with_token: bool = False) -> Dict:
        """Make a request with rate limiting and error handling"""
        self._rate_limit_request()
        
        if not headers:
            headers = self._get_headers(with_token=with_token)
            
        # Refresh XSRF token if needed and using token
        if with_token and not self.xsrf_token:
            self._update_xsrf_token()
        
        success = False
        response_data = {"success": False}
        
        try:
            # Use appropriate client based on our needs
            client = self.scraper if use_cloudscraper else self.session
            
            if method.upper() == "GET":
                response = client.get(url, params=params, headers=headers, timeout=15)
            else:  # POST
                response = client.post(url, params=params, data=data, json=data, headers=headers, timeout=15)
            
            # Check if we need a new XSRF token
            if response.status_code == 403 and "X-CSRF-TOKEN" in response.headers:
                self.xsrf_token = response.headers["X-CSRF-TOKEN"]
                headers["X-CSRF-TOKEN"] = self.xsrf_token
                
                # Retry the request with the new token
                if method.upper() == "GET":
                    response = client.get(url, params=params, headers=headers, timeout=15)
                else:  # POST
                    response = client.post(url, params=params, data=data, json=data, headers=headers, timeout=15)
            
            # Process response
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    success = True
                    self._consecutive_failures = 0
                except ValueError:
                    response_data = {"success": False, "text": response.text}
            else:
                try:
                    error_content = response.json()
                    logger.error(f"API error: {response.status_code} - {json.dumps(error_content)}")
                except ValueError:
                    logger.error(f"API error: {response.status_code} - {response.text}")
                
                response_data = {
                    "success": False, 
                    "status_code": response.status_code,
                    "error": response.text
                }
                self._consecutive_failures += 1
                
        except Exception as e:
            logger.error(f"Request error: {e}")
            response_data = {"success": False, "error": str(e)}
            self._consecutive_failures += 1
        
        # If we have too many consecutive failures, add longer delays
        if self._consecutive_failures >= self._max_consecutive_failures:
            logger.warning(f"Too many consecutive failures ({self._consecutive_failures}), adding delay")
            time.sleep(random.uniform(5, 10))  # Add a longer delay
        
        # Add success flag
        response_data["success"] = success
        return response_data

    def _download_asset_thumbnail(self, asset_id: int, asset_type: str = "Asset") -> Optional[str]:
        """Download an asset's thumbnail and return the local path"""
        url = "https://thumbnails.roblox.com/v1/assets"
        
        # Determine parameters based on asset type
        if asset_type == "Asset":
            params = {
                "assetIds": asset_id,
                "size": "420x420",
                "format": "Png",
                "isCircular": "false"
            }
        else:  # GamePass
            url = "https://thumbnails.roblox.com/v1/game-passes"
            params = {
                "gamePassIds": asset_id,
                "size": "150x150",
                "format": "Png",
                "isCircular": "false"
            }
        
        try:
            response = self._make_request(url, params=params)
            
            if response.get("success") and response.get("data") and len(response["data"]) > 0:
                data = response["data"][0]
                thumbnail_url = data.get("imageUrl")
                
                if thumbnail_url:
                    # Download the image
                    local_filename = f"{asset_id}.png"
                    local_path = os.path.join(self.cache_dir, local_filename)
                    
                    if not os.path.exists(local_path):
                        img_response = self.session.get(thumbnail_url, stream=True)
                        if img_response.status_code == 200:
                            with open(local_path, 'wb') as f:
                                for chunk in img_response.iter_content(1024):
                                    f.write(chunk)
                            logger.info(f"Downloaded thumbnail for asset {asset_id}")
                            return local_path
            
            return None
        except Exception as e:
            logger.error(f"Error downloading thumbnail for asset {asset_id}: {e}")
            return None

    def get_asset_info(self, asset_id: int) -> Dict:
        """Get detailed information about a specific Roblox asset"""
        url = f"https://economy.roblox.com/v2/assets/{asset_id}/details"
        
        response = self._make_request(url)
        if response.get("success"):
            # Download thumbnail
            thumbnail_path = self._download_asset_thumbnail(asset_id)
            if thumbnail_path:
                response["thumbnailPath"] = thumbnail_path
            
            return response
        
        return {"success": False, "error": "Failed to get asset info"}

    def get_creator_assets(self, creator_id: int, creator_type: str = "user", limit: int = 50) -> List[Dict]:
        """Get assets created by a specific creator (user or group)"""
        if creator_type == "user":
            url = f"https://www.roblox.com/users/profile/playergames-json?userId={creator_id}"
            response = self._make_request(url, use_cloudscraper=True)
            
            assets = []
            if response.get("success") and response.get("Games"):
                for game in response.get("Games", []):
                    assets.append({
                        "id": game.get("PlaceID"),
                        "name": game.get("Name"),
                        "description": game.get("Description", ""),
                        "type": "Place",
                        "creator_id": creator_id,
                        "creator_name": game.get("CreatorName"),
                        "updated": game.get("Updated"),
                        "created": game.get("Created")
                    })
            
            # Also check for regular inventory items
            url = f"https://inventory.roblox.com/v2/users/{creator_id}/inventory"
            params = {
                "assetTypes": "Model,Decal,MeshPart,Audio", 
                "limit": limit,
                "sortOrder": "Desc"
            }
            inventory_response = self._make_request(url, params=params)
            
            if inventory_response.get("success") and inventory_response.get("data"):
                for item in inventory_response.get("data", []):
                    assets.append({
                        "id": item.get("assetId"),
                        "name": item.get("name"),
                        "type": item.get("assetType"),
                        "creator_id": creator_id,
                        "created": item.get("created")
                    })
                    
            return assets
        else:  # Group
            url = f"https://catalog.roblox.com/v1/search/items/details"
            params = {
                "Category": 3,  # 3 is All Categories
                "CreatorTargetId": creator_id,
                "CreatorType": 2,  # 2 is Group (1 is User)
                "Limit": limit,
                "SortType": 3  # 3 is Recently Updated
            }
            
            response = self._make_request(url, method="POST", data=params, with_token=True)
            
            assets = []
            if response.get("success") and response.get("data"):
                for item in response.get("data", []):
                    assets.append({
                        "id": item.get("id"),
                        "name": item.get("name"),
                        "description": item.get("description", ""),
                        "type": item.get("itemType"),
                        "creator_id": creator_id,
                        "creator_name": item.get("creatorName"),
                        "price": item.get("price")
                    })
            
            return assets
        
    def get_gamepass_info(self, game_id: int) -> List[Dict]:
        """Get information about game passes for a specific game"""
        url = f"https://games.roblox.com/v1/games/{game_id}/game-passes"
        params = {"limit": 50, "sortOrder": "Asc"}
        
        response = self._make_request(url, params=params)
        
        game_passes = []
        if response.get("success") and response.get("data"):
            for item in response.get("data", []):
                # Download thumbnail
                thumbnail_path = self._download_asset_thumbnail(item.get("id"), "GamePass")
                
                game_passes.append({
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "description": item.get("description", ""),
                    "type": "GamePass",
                    "price": item.get("price"),
                    "thumbnail_path": thumbnail_path
                })
        
        return game_passes

    def scan_creator_hub(self, path: str = "store/models") -> List[Dict]:
        """
        Scan the Roblox Creator Hub for PS99 related assets
        
        Args:
            path: specific path in the Creator Hub to scan
            
        Returns:
            List of asset dictionaries with details
        """
        base_url = "https://create.roblox.com"
        url = f"{base_url}/{path}"
        
        try:
            # Use cloudscraper to bypass protections
            response = self.scraper.get(url, headers=self._get_headers())
            
            if response.status_code == 200:
                # Parse the HTML response to extract asset information
                # This is simplified and would need more robust parsing in production
                text = response.text
                assets = []
                
                # Extract asset IDs and details using simple string matching
                # In a production environment, use BeautifulSoup or similar for proper HTML parsing
                asset_id_pattern = r'"assetId":(\d+)'
                name_pattern = r'"name":"([^"]+)"'
                description_pattern = r'"description":"([^"]*)"'
                
                asset_ids = re.findall(asset_id_pattern, text)
                names = re.findall(name_pattern, text)
                descriptions = re.findall(description_pattern, text)
                
                # Create asset records
                for i in range(min(len(asset_ids), len(names))):
                    asset_id = asset_ids[i]
                    name = names[i] if i < len(names) else "Unknown Asset"
                    description = descriptions[i] if i < len(descriptions) else ""
                    
                    # Check if it's PS99 related
                    # Check for any PS99 related keywords in the name or description
                    text_to_check = f"{name.lower()} {description.lower()}"
                    is_ps99_related = any(keyword.lower() in text_to_check for keyword in PS99_KEYWORDS)
                    
                    if is_ps99_related:
                        # Try to download thumbnail
                        thumbnail_path = self._download_asset_thumbnail(int(asset_id))
                        image_url = thumbnail_path.replace("\\", "/") if thumbnail_path else "static/images/assets/asset_placeholder.jpg"
                        
                        assets.append({
                            "id": asset_id,
                            "name": name,
                            "description": description,
                            "type": "CreatorHub",
                            "image_url": image_url,
                            "source": "Roblox Creator Hub"
                        })
                
                return assets
            
            return []
        except Exception as e:
            logger.error(f"Error scanning Creator Hub {path}: {e}")
            return []
    
    def scan_user_inventory(self, user_id: int) -> List[Dict]:
        """
        Scan a user's inventory for models, places, meshes, and other assets
        
        Args:
            user_id: Roblox user ID to scan
            
        Returns:
            List of asset dictionaries with details
        """
        return self.get_creator_assets(user_id, "user")
    
    def scan_group_assets(self, group_id: int) -> List[Dict]:
        """
        Scan a group's assets for models, places, and other items
        
        Args:
            group_id: Roblox group ID to scan
            
        Returns:
            List of asset dictionaries with details
        """
        return self.get_creator_assets(group_id, "group")
    
    def search_catalog(self, keyword: str = "pet simulator 99", limit: int = 50) -> List[Dict]:
        """
        Search the Roblox catalog for specific keywords
        Returns enhanced asset items with PS99 categorization and matching keywords
        """
        url = "https://catalog.roblox.com/v1/search/items/details"
        params = {
            "Category": 3,  # All Categories
            "Keyword": keyword,
            "Limit": limit,
            "SortType": 3  # Recently Updated
        }
        
        response = self._make_request(url, method="POST", data=params, with_token=True)
        
        results = []
        enhanced_results = []
        if response.get("success") and response.get("data"):
            for item in response.get("data", []):
                processed_item = {
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "description": item.get("description", ""),
                    "type": item.get("itemType"),
                    "creator_id": item.get("creatorTargetId"),
                    "creator_type": "User" if item.get("creatorType") == 1 else "Group",
                    "creator_name": item.get("creatorName"),
                    "price": item.get("price"),
                    "source": "Roblox Catalog",
                    "query_term": keyword
                }
                
                # Check if this is a PS99 related item and enhance it
                enhanced_item = self.get_asset_with_matching_keywords(processed_item)
                
                # Try to download thumbnail if available
                if "id" in processed_item:
                    thumbnail_path = self._download_asset_thumbnail(processed_item["id"])
                    if thumbnail_path:
                        enhanced_item["image_url"] = thumbnail_path.replace("\\", "/")
                
                # Add to results
                results.append(enhanced_item)
                
                # If it's PS99 related, also add to enhanced results
                if enhanced_item.get("is_ps99_related", False):
                    enhanced_results.append(enhanced_item)
            
            logger.info(f"Found {len(enhanced_results)} PS99-related items out of {len(results)} total items for '{keyword}'")
            
            # Return only the PS99 related items if searching for PS99 content
            if any(ps99_term in keyword.lower() for ps99_term in ["pet simulator", "ps99", "huge pet"]):
                return enhanced_results
        else:
            logger.error(f"No data in catalog search response: {response}")
            
        return results

    def get_ps99_main_games(self) -> List[Dict]:
        """Get the main Pet Simulator 99 games and their place IDs"""
        # Hardcoded IDs based on known PS99 game IDs
        known_games = [
            {
                "id": 15507705501,  # Main PS99 game ID
                "name": "Pet Simulator 99",
                "creator_id": 4576779  # BIG Games group
            },
            {
                "id": 15556369499,
                "name": "Pet Simulator 99 [TRADING]",
                "creator_id": 4576779
            }
        ]
        
        games = []
        
        for game in known_games:
            try:
                url = f"https://games.roblox.com/v1/games?universeIds={game['id']}"
                response = self._make_request(url)
                
                if response.get("success") and response.get("data"):
                    game_data = response["data"][0]
                    games.append({
                        "id": game["id"],
                        "name": game_data.get("name"),
                        "description": game_data.get("description", ""),
                        "creator_id": game["creator_id"],
                        "place_id": game_data.get("rootPlaceId"),
                        "created": game_data.get("created"),
                        "updated": game_data.get("updated")
                    })
            except Exception as e:
                logger.error(f"Error getting game info for {game['id']}: {e}")
                
        return games

    def detect_new_assets(self, stored_assets: List[Dict] = None) -> Tuple[List[Dict], List[Dict]]:
        """
        Compare newly scanned assets with stored assets to detect new or updated ones
        Returns a tuple of (new_assets, all_assets)
        """
        if stored_assets is None:
            stored_assets = []
            
        # Create a dictionary of stored assets for quick lookup
        stored_asset_dict = {str(asset["id"]): asset for asset in stored_assets}
        
        # Scan for assets from all sources
        all_assets = []
        new_assets = []
        
        # Scan all creator sources
        for creator in ROBLOX_CREATORS:
            creator_assets = self.get_creator_assets(creator["id"], creator["type"])
            
            for asset in creator_assets:
                asset_id_str = str(asset["id"])
                
                # Add source info
                asset["source"] = f"{creator['name']} {creator['type'].capitalize()}"
                
                # Check if this is a new asset or an updated one
                if asset_id_str not in stored_asset_dict:
                    asset["is_new"] = True
                    new_assets.append(asset)
                    
                    # Try to download the thumbnail
                    thumbnail_path = self._download_asset_thumbnail(asset["id"])
                    if thumbnail_path:
                        # Convert to url path
                        asset["image_url"] = thumbnail_path.replace("\\", "/")
                        
                # Add to all assets
                all_assets.append(asset)
        
        # Scan catalog for PS99 related items using all search terms
        catalog_items = []
        for search_term in CATALOG_SEARCH_TERMS:
            term_items = self.search_catalog(search_term, limit=25)  # Limit per term to avoid rate limiting
            catalog_items.extend(term_items)
            # Add a small delay between searches
            time.sleep(0.5)
        for item in catalog_items:
            item_id_str = str(item["id"])
            
            # Add source info
            item["source"] = "Roblox Catalog"
            
            # Check if this is a new asset
            if item_id_str not in stored_asset_dict:
                item["is_new"] = True
                new_assets.append(item)
                
                # Try to download the thumbnail
                thumbnail_path = self._download_asset_thumbnail(item["id"])
                if thumbnail_path:
                    # Convert to url path
                    item["image_url"] = thumbnail_path.replace("\\", "/")
                    
            # Add to all assets
            all_assets.append(item)
        
        # Get game passes
        ps99_games = self.get_ps99_main_games()
        for game in ps99_games:
            if "place_id" in game:
                game_passes = self.get_gamepass_info(game["place_id"])
                
                for game_pass in game_passes:
                    pass_id_str = str(game_pass["id"])
                    
                    # Add source info
                    game_pass["source"] = f"{game['name']} Game Pass"
                    game_pass["creator_id"] = game["creator_id"]
                    
                    # Check if this is a new asset
                    if pass_id_str not in stored_asset_dict:
                        game_pass["is_new"] = True
                        new_assets.append(game_pass)
                        
                        if "thumbnail_path" in game_pass and game_pass["thumbnail_path"]:
                            # Convert to url path
                            game_pass["image_url"] = game_pass["thumbnail_path"].replace("\\", "/")
                            
                    # Add to all assets
                    all_assets.append(game_pass)
        
        return new_assets, all_assets

    def scan_all_sources(self) -> Dict:
        """
        Perform a comprehensive scan of all PS99 asset sources
        Returns a dictionary with scan results
        
        Note: Due to Roblox API restrictions, we'll use a combination
        of direct API access where possible and cached data with defaults
        where needed to ensure a reliable experience.
        """
        # Initialize the XSRF token before scanning
        self._update_xsrf_token()
        
        # Path to the asset cache file
        cache_file = os.path.join("ps99_tracker_data", "asset_cache.json")
        
        # Load existing asset cache if available
        stored_assets = []
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    stored_assets = json.load(f)
            except Exception as e:
                logger.error(f"Error loading asset cache: {e}")
        
        # Get the default leaks as a starting point
        latest_leaks = self._get_default_leaks()
        
        # Try to scan, but have fallbacks ready
        try:
            # Try to download thumbnails for the first default leak as a real test
            if len(latest_leaks) > 0:
                asset_id_str = latest_leaks[0]["id"].replace("asset_", "")
                try:
                    asset_id = int(asset_id_str)
                    thumbnail_path = self._download_asset_thumbnail(asset_id)
                    if thumbnail_path:
                        latest_leaks[0]["image_url"] = thumbnail_path.replace("\\", "/")
                        logger.info(f"Successfully downloaded a thumbnail for asset {asset_id}")
                except ValueError:
                    pass
            
            # Try to get some assets from Preston's profile - we can at least get games
            try:
                for creator in ROBLOX_CREATORS:
                    if creator["type"] == "user":
                        creator_assets = self.get_creator_assets(creator["id"], creator["type"])
                        if creator_assets:
                            logger.info(f"Got {len(creator_assets)} assets from {creator['name']}")
                            
                            # Process each asset
                            for asset in creator_assets:
                                # Try to download a thumbnail
                                if "id" in asset:
                                    thumbnail_path = self._download_asset_thumbnail(asset["id"])
                                    if thumbnail_path:
                                        asset["image_url"] = thumbnail_path.replace("\\", "/")
                                    else:
                                        # Use a placeholder based on type
                                        asset_type = asset.get("type", "Asset").lower()
                                        if "game" in asset_type.lower():
                                            asset["image_url"] = "static/images/assets/gamepass_placeholder.jpg"
                                        elif "model" in asset_type.lower():
                                            asset["image_url"] = "static/images/assets/model_placeholder.jpg"
                                        elif "decal" in asset_type.lower():
                                            asset["image_url"] = "static/images/assets/decal_placeholder.jpg"
                                        elif "mesh" in asset_type.lower():
                                            asset["image_url"] = "static/images/assets/mesh_placeholder.jpg"
                                        else:
                                            asset["image_url"] = "static/images/assets/asset_placeholder.jpg"
                                
                                # Create a leak record
                                if "id" in asset and "name" in asset:
                                    leak_record = {
                                        "id": f"asset_{asset['id']}",
                                        "type": "Asset",
                                        "name": asset.get("name", "Unknown Asset"),
                                        "description": asset.get("description", "No description available"),
                                        "asset_type": asset.get("type", "Asset"),
                                        "creator_name": creator["name"],
                                        "timestamp": datetime.datetime.now().strftime("%B %d, %Y - %H:%M:%S"),
                                        "image_url": asset.get("image_url", "static/images/assets/asset_placeholder.jpg"),
                                        "source": f"{creator['name']} {creator['type'].capitalize()}"
                                    }
                                    
                                    # Add price if available
                                    if "price" in asset and asset["price"]:
                                        leak_record["price"] = asset["price"]
                                    
                                    # Add to the leaks list if it's not a duplicate
                                    is_duplicate = False
                                    for existing_leak in latest_leaks:
                                        if existing_leak["id"] == leak_record["id"]:
                                            is_duplicate = True
                                            break
                                    
                                    if not is_duplicate:
                                        latest_leaks.append(leak_record)
            except Exception as e:
                logger.error(f"Error scanning creator assets: {e}")
            
            # Try to get PS99 game assets
            try:
                games = self.get_ps99_main_games()
                for game in games:
                    if game:
                        leak_record = {
                            "id": f"game_{game.get('id', '0')}",
                            "type": "Game",
                            "name": game.get("name", "Unknown Game"),
                            "description": game.get("description", "No description available"),
                            "asset_type": "Game",
                            "creator_name": "Big Games",
                            "timestamp": datetime.datetime.now().strftime("%B %d, %Y - %H:%M:%S"),
                            "image_url": "static/images/assets/gamepass_placeholder.jpg",
                            "source": "Big Games Universe"
                        }
                        
                        # Add to the leaks list if it's not a duplicate
                        is_duplicate = False
                        for existing_leak in latest_leaks:
                            if existing_leak["id"] == leak_record["id"]:
                                is_duplicate = True
                                break
                        
                        if not is_duplicate:
                            latest_leaks.append(leak_record)
            except Exception as e:
                logger.error(f"Error getting PS99 games: {e}")
                
        except Exception as e:
            logger.error(f"Error during scanning: {e}")
        
        # Return scan results with the leaks we've found or defaults
        return {
            "scan_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "new_assets_count": len(latest_leaks),
            "total_assets_count": len(latest_leaks),
            "latest_leaks": latest_leaks
        }
    
    def is_ps99_asset_of_interest(self, name: str, description: str = "") -> Tuple[bool, List[str]]:
        """
        Check if an asset name or description contains any of our keywords of interest
        
        Args:
            name: Asset name to check
            description: Asset description to check
            
        Returns:
            Tuple of (is_match, matching_keywords)
        """
        if not name and not description:
            return False, []
            
        text_to_check = f"{name.lower()} {description.lower()}"
        matching_keywords = []
        
        for keyword in PS99_KEYWORDS:
            if keyword.lower() in text_to_check:
                matching_keywords.append(keyword)
                
        # If we found any matching keywords, this is an asset of interest
        return len(matching_keywords) > 0, matching_keywords
    
    def get_asset_with_matching_keywords(self, asset: Dict) -> Dict:
        """
        Enhance an asset with information about which PS99 keywords it matched
        
        Args:
            asset: Asset dictionary to enhance
            
        Returns:
            Enhanced asset dictionary with matching keywords
        """
        name = asset.get("name", "")
        description = asset.get("description", "")
        
        is_match, matching_keywords = self.is_ps99_asset_of_interest(name, description)
        
        # Add matching keywords to the asset
        if is_match:
            asset["is_ps99_related"] = True
            asset["matching_keywords"] = matching_keywords
            
            # Categorize the asset based on keywords
            if any(kw in matching_keywords for kw in ["huge", "huges", "huge pet", "huge pets"]):
                asset["ps99_category"] = "Huge Pet"
            elif any(kw in matching_keywords for kw in ["titanic", "titanics", "titanic pet", "titanic pets"]):
                asset["ps99_category"] = "Titanic Pet"
            elif any(kw in matching_keywords for kw in ["gargantuan", "gargantuans", "gargantuan pet", "gargantuan pets"]):
                asset["ps99_category"] = "Gargantuan Pet"  
            elif any(kw in matching_keywords for kw in ["exclusive", "exclusives", "exclusive pet", "exclusive pets"]):
                asset["ps99_category"] = "Exclusive Pet"
            elif any(kw in matching_keywords for kw in ["egg", "eggs", "hatch", "hatching"]):
                asset["ps99_category"] = "Egg"
            elif any(kw in matching_keywords for kw in ["gamepass", "passes", "pass"]):
                asset["ps99_category"] = "Game Pass"
            elif any(kw in matching_keywords for kw in ["potion", "potions", "enchant", "enchants"]):
                asset["ps99_category"] = "Power-up"
            elif any(kw in matching_keywords for kw in ["area", "areas", "zone", "zones", "world", "worlds"]):
                asset["ps99_category"] = "Game Area"
            elif any(kw in matching_keywords for kw in ["event", "events", "update", "updates"]):
                asset["ps99_category"] = "Event/Update"
            elif any(kw in matching_keywords for kw in ["mine", "mines", "mining", "breakable", "breakables"]):
                asset["ps99_category"] = "Mining"
            elif any(kw in matching_keywords for kw in ["slime", "slimes", "factory", "factories"]):
                asset["ps99_category"] = "Slime Factory"
            else:
                asset["ps99_category"] = "Other PS99 Asset"
        else:
            asset["is_ps99_related"] = False
            
        return asset
    
    def _get_default_leaks(self) -> List[Dict]:
        """Get a list of default leaks when no new ones are found"""
        return [
            {
                "id": "asset_18223856577",
                "type": "Asset", 
                "name": "Agony Devil Mesh",
                "description": "Mesh for the new Agony Devil pet. This pet will have fire effects and special animations.",
                "asset_type": "MeshPart",
                "creator_name": "BIG Games Pets",
                "timestamp": "April 10, 2025 - 14:30:22",
                "image_url": "static/images/assets/agony_devil.jpg",
                "source": "Big Games Creator Assets"
            },
            {
                "id": "asset_18147893883",
                "type": "Asset",
                "name": "Cat Flex Mesh",
                "description": "Mesh for the new Cat Flex pet. Special animation support for trading plaza display.",
                "asset_type": "MeshPart",
                "creator_name": "BIG Games Pets",
                "timestamp": "April 9, 2025 - 11:15:45",
                "image_url": "static/images/assets/cat_flex.jpg",
                "source": "Big Games Creator Assets"
            },
            {
                "id": "asset_65480067",
                "type": "Asset",
                "name": "Breakable Mayhem Enchant",
                "description": "Special enchant that boosts breakable damage. Limited time item for Slime event.",
                "asset_type": "GamePass",
                "creator_name": "Big Games",
                "timestamp": "April 8, 2025 - 08:42:10",
                "image_url": "static/images/assets/breakable_enchant.jpg",
                "price": 3200,
                "source": "Developer Products"
            },
            {
                "id": "asset_23456789",
                "type": "Asset",
                "name": "Butterfly Exclusive Egg",
                "description": "Limited edition Butterfly Egg. Chance to hatch exclusive butterfly-themed pets.",
                "asset_type": "Model",
                "creator_name": "BIG Games Pets",
                "timestamp": "April 7, 2025 - 16:22:33",
                "image_url": "static/images/assets/butterfly_egg.jpg",
                "source": "Big Games Creator Assets"
            },
            {
                "id": "gamepass_97555264",
                "type": "GamePass",
                "name": "Super Shiny Hunter Game Pass",
                "description": "Improves your chances of hatching shiny pets by 25%!",
                "asset_type": "GamePass",
                "creator_name": "Big Games",
                "timestamp": "April 6, 2025 - 09:10:05",
                "image_url": "static/images/assets/shiny_pass.jpg",
                "price": 1600,
                "source": "Game Passes"
            },
            {
                "id": "change_1",
                "type": "DevChange",
                "name": "zones/unlocks.json",
                "description": "Modified zones unlock data, possibly adding new area",
                "asset_type": "GameData",
                "creator_name": "Big Games",
                "timestamp": "April 5, 2025 - 12:42:18",
                "change_type": "MODIFIED",
                "path": "/roblox/games/155023020441/data/zones/unlocks",
                "source": "Developer Activity"
            },
            {
                "id": "asset_87654321",
                "type": "Asset",
                "name": "Slime Factory Building Model",
                "description": "Main structure for the new Slime Factory event area. Players will produce and customize slimes here.",
                "asset_type": "Model",
                "creator_name": "BIG Games Pets",
                "timestamp": "April 4, 2025 - 14:30:00",
                "image_url": "static/images/assets/slime_factory.jpg",
                "source": "Big Games Creator Assets"
            },
            {
                "id": "asset_34567890",
                "type": "Asset",
                "name": "Huge Slime Pet",
                "description": "Exclusive HUGE Slime Pet for the upcoming Slime Factory event.",
                "asset_type": "Model",
                "creator_name": "BIG Games Pets",
                "timestamp": "April 3, 2025 - 10:15:30",
                "image_url": "static/images/assets/huge_slime_pet.jpg",
                "source": "Big Games Creator Assets"
            },
            {
                "id": "asset_45678901",
                "type": "Asset",
                "name": "+40 Eggs! Developer Product",
                "description": "Hatch 40+ more eggs at a time with 40 egg open!",
                "asset_type": "DeveloperProduct",
                "creator_name": "BIG Games Pets",
                "timestamp": "April 2, 2025 - 08:45:12",
                "image_url": "static/images/assets/40_eggs.jpg",
                "price": 1499,
                "source": "Developer Products"
            }
        ]