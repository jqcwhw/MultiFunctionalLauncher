/**
 * WorkingScanner - A scanner that uses endpoints that work without any error handling or bypassing
 * needed. Focuses only on the confirmed Big Games Pets Group ID.
 * 
 * Enhanced with additional endpoints for more complete asset discovery.
 */

import axios from 'axios';
import { nanoid } from 'nanoid';
import { storage } from '../storage';
import { ACCESSIBLE_ENDPOINTS, HTTP_HEADERS, EndpointKey } from './endpoint-registry';
import { assetDeliveryScanner } from './asset-delivery-scanner';
import { AssetType, InsertAsset } from '@shared/schema';

// Map Roblox asset types to our schema's AssetType 
const mapRobloxAssetType = (robloxType: string): AssetType => {
  const typeMap: Record<string, AssetType> = {
    // Common catalog asset types
    'Asset': '3D Model',
    'Model': '3D Model',
    'MeshPart': 'MeshPart',
    'Mesh': 'Mesh',
    'Shirt': 'Decal',
    'Pants': 'Decal',
    'Decal': 'Decal',
    'Image': 'Image',
    'Texture': 'Texture',
    'Hat': 'Mesh',
    'HairAccessory': 'Mesh',
    'FaceAccessory': 'Mesh',
    'NeckAccessory': 'Mesh',
    'ShoulderAccessory': 'Mesh',
    'FrontAccessory': 'Mesh',
    'BackAccessory': 'Mesh',
    'WaistAccessory': 'Mesh',
    'TShirt': 'Decal',
    'Audio': 'Audio',
    'Sound': 'Audio',
    'Animation': 'Animation',
    'Gear': 'Mesh',
    'Badge': 'Badge',
    'GamePass': 'Gamepass',
    'DeveloperProduct': 'DeveloperProduct',
    'Plugin': 'Plugin',
    'Package': 'Package',
    'Place': 'Place',
    'Script': 'Script',
    'Pet': 'Pet',
    'Egg': 'Egg',
    'Huge': 'Huge',
    'Gargantuan': 'Gargantuan',
    'Titanic': 'Titanic',
    'Currency': 'Currency',
    'Area': 'Area',
    'World': 'World',
    'Instance': 'Instance',
    // Unknown defaults to Other instead of API
    'Unknown': 'Other'
  };
  
  return typeMap[robloxType] || 'Other';
};

// Get thumbnail URL for Roblox asset
const getThumbnailUrl = (assetId: string, assetType: string): string => {
  // Standard thumbnail URL format
  if (assetId) {
    return `https://tr.rbxcdn.com/asset-thumbnail/image?assetId=${assetId}&width=420&height=420&format=png`;
  }
  return '';
};

// The only confirmed group ID to scan
const CONFIRMED_GROUP_ID = "3959677"; // BIG Games Pets Community

// Pet Simulator 99 game ID
const PS99_GAME_ID = "14631430119";

// Pet Simulator universe ID
const PS99_UNIVERSE_ID = "5223697"; 

interface ScanResult {
  endpointName: string;
  endpointUrl: string;
  success: boolean;
  message?: string;
  assetCount?: number;
  error?: string;
}

export class WorkingScanner {
  private lastScanTime: Date | null = null;
  private inProgress: boolean = false;
  private results: ScanResult[] = [];
  private totalAssets: number = 0;
  private assetIds: Set<string> = new Set(); // Track asset IDs to avoid duplicates
  
  // Rate limiting control
  private apiCallsCount: number = 0;
  private requestDelayMs: number = 1500; // Increased to 1.5 seconds between requests
  private lastRequestTime: number = 0;
  private domainBackoff: Map<string, number> = new Map(); // Track backoff per domain
  private maxBackoffMs: number = 30000; // Maximum backoff of 30 seconds
  
  /**
   * Get working scanner status
   */
  getStatus(): any {
    return {
      lastScan: this.lastScanTime,
      inProgress: this.inProgress,
      totalEndpoints: this.results.length,
      totalAssets: this.totalAssets,
      apiCalls: this.apiCallsCount
    };
  }
  
  /**
   * Extract domain from a URL for domain-specific rate limiting
   */
  private extractDomain(url: string): string {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch (e) {
      return 'unknown';
    }
  }
  
  /**
   * Wait for rate limit before making a request
   * This helps avoid 429 Too Many Requests errors
   * Now with domain-specific backoff
   */
  private async waitForRateLimit(url: string): Promise<void> {
    this.apiCallsCount++;
    
    const now = Date.now();
    const elapsed = now - this.lastRequestTime;
    const domain = this.extractDomain(url);
    
    // Get domain-specific backoff if any
    const domainBackoff = this.domainBackoff.get(domain) || 0;
    const effectiveDelay = Math.max(this.requestDelayMs, domainBackoff);
    
    // If less time has passed than our delay, wait the remaining time
    if (elapsed < effectiveDelay) {
      const waitTime = effectiveDelay - elapsed;
      console.log(`Rate limiting: Waiting ${waitTime}ms for ${domain}`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    // Update the last request time
    this.lastRequestTime = Date.now();
  }
  
  /**
   * Update domain backoff based on response
   * If we get a 429, increase backoff exponentially
   * If successful, gradually reduce backoff
   */
  private updateDomainBackoff(url: string, statusCode: number): void {
    const domain = this.extractDomain(url);
    const currentBackoff = this.domainBackoff.get(domain) || 0;
    
    if (statusCode === 429) {
      // Too many requests - double backoff (exponential) with max cap
      const newBackoff = Math.min(
        currentBackoff === 0 ? 2000 : currentBackoff * 2, 
        this.maxBackoffMs
      );
      console.log(`Rate limit exceeded for ${domain}. Increasing backoff to ${newBackoff}ms`);
      this.domainBackoff.set(domain, newBackoff);
    } else if (statusCode >= 200 && statusCode < 300) {
      // Success - gradually decrease backoff
      if (currentBackoff > 0) {
        const newBackoff = Math.max(0, currentBackoff - 500);
        this.domainBackoff.set(domain, newBackoff);
      }
    }
  }
  
  /**
   * Make a rate-limited API request with smart backoff and retry for 429s
   */
  private async makeRequest(url: string, headers: any, retryCount: number = 0, maxRetries: number = 3): Promise<any> {
    // Wait for rate limiting
    await this.waitForRateLimit(url);
    
    try {
      // Make the actual request
      const response = await axios.get(url, {
        headers,
        timeout: 15000 // Increased timeout
      });
      
      // Update backoff for successful requests
      this.updateDomainBackoff(url, response.status);
      
      return response;
    } catch (error: any) {
      // If rate limited and we have retries left, retry with backoff
      if (error.response && error.response.status === 429 && retryCount < maxRetries) {
        // Update backoff for this domain
        this.updateDomainBackoff(url, 429);
        
        // Calculate retry delay with exponential backoff
        const retryDelay = Math.min(Math.pow(2, retryCount) * 2000, 30000);
        console.log(`Rate limited (429) for ${url}. Retry ${retryCount + 1}/${maxRetries} after ${retryDelay}ms backoff`);
        
        // Wait for backoff period
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        
        // Retry the request with incremented retry count
        return this.makeRequest(url, headers, retryCount + 1, maxRetries);
      }
      
      // If rate limited but out of retries, just update backoff for future requests
      if (error.response && error.response.status === 429) {
        this.updateDomainBackoff(url, 429);
      }
      
      throw error;
    }
  }
  
  /**
   * Scan Creator Store via Toolbox Service API
   * This is a new endpoint found in the official Roblox API documentation
   */
  private async scanCreatorStore(): Promise<void> {
    console.log('Scanning Creator Store for Pet Simulator 99 assets...');
    
    const keywords = ['pet simulator 99', 'ps99', 'huge pet', 'exclusive pet', 'mythical pet'];
    const categories = ['Model', 'Plugin', 'Audio', 'Mesh', 'Image', 'Animation'];
    
    let totalItemsFound = 0;
    
    // Process each keyword and category combination
    for (const keyword of keywords) {
      for (const category of categories) {
        const endpointName = 'Creator Store Search';
        const endpointUrl = ACCESSIBLE_ENDPOINTS.CREATOR_STORE_SEARCH
          .replace('{keyword}', encodeURIComponent(keyword))
          .replace('{category}', category)
          .replace('{limit}', '30')
          .replace('{cursor}', '')
          .replace('{includeArchived}', 'false');
        
        try {
          console.log(`Searching Creator Store for ${category} assets matching "${keyword}"...`);
          
          // Make the request with rate limiting
          const response = await this.makeRequest(endpointUrl, {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json'
          });
          
          if (response?.status === 200 && response?.data?.data) {
            const items = response.data.data;
            let itemCount = items.length;
            
            console.log(`✓ Found ${itemCount} ${category} assets matching "${keyword}"`);
            
            if (itemCount > 0) {
              // Create an asset record with all search results
              const catalogAssetId = nanoid();
              await storage.createAsset({
                id: catalogAssetId,
                name: `Creator Store: ${category} - ${keyword}`,
                type: 'Other',
                size: `${JSON.stringify(items).length} bytes`,
                game: 'Pet Simulator 99',
                creator: 'Creator Store',
                detectedAt: 'Just now',
                status: 'New',
                metadata: {
                  format: 'json',
                  keyword: keyword,
                  category: category,
                  itemCount: items.length,
                  items: items.map((item: any) => ({
                    id: item.id,
                    name: item.name,
                    description: item.description || '',
                    type: item.type || category,
                    creatorId: item.creatorId,
                    creatorName: item.creatorName
                  }))
                },
                sourceUrl: endpointUrl
              });
              
              // Add these catalog item IDs to our collection for further processing
              for (const item of items) {
                if (item.id) {
                  this.assetIds.add(item.id.toString());
                }
              }
              
              this.totalAssets++;
              totalItemsFound += itemCount;
            }
            
            // Store result
            this.results.push({
              endpointName: `${endpointName} (${category}: ${keyword})`,
              endpointUrl,
              success: true,
              message: `Found ${itemCount} items for keyword "${keyword}"`,
              assetCount: itemCount > 0 ? 1 : 0
            });
          } else {
            this.results.push({
              endpointName: `${endpointName} (${category}: ${keyword})`,
              endpointUrl,
              success: false,
              message: 'No data or empty response'
            });
            console.log(`No results found for ${category} assets matching "${keyword}"`);
          }
        } catch (error: any) {
          this.results.push({
            endpointName: `${endpointName} (${category}: ${keyword})`,
            endpointUrl,
            success: false,
            error: error.message
          });
          console.error(`Error searching Creator Store for ${category} assets matching "${keyword}":`, error.message);
        }
        
        // Add a small pause between requests to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
    
    console.log(`Completed Creator Store search. Found ${totalItemsFound} total items across all keywords and categories.`);
  }

  /**
   * Run a scan using only known working endpoints
   * Enhanced with additional endpoints for more thorough scanning
   */
  async runScan(): Promise<any> {
    if (this.inProgress) {
      return {
        success: false,
        message: 'Scan already in progress',
        timestamp: new Date()
      };
    }
    
    try {
      console.log(`Starting scan with working endpoints...`);
      this.inProgress = true;
      this.results = [];
      this.totalAssets = 0;
      this.assetIds.clear();
      this.apiCallsCount = 0;
      this.lastRequestTime = Date.now() - this.requestDelayMs; // Initialize with "ready to go" timestamp
      
      // Track bypassed endpoints (will be implemented later)
      const bypassed: string[] = [];
      
      // GROUP RELATED ENDPOINTS
      console.log('Scanning GROUP-related endpoints...');
      // Try the known working endpoint for group info
      await this.scanGroupInfo();
      
      // Try getting group games
      await this.scanGroupGames();
      
      // Try getting group roles
      await this.scanGroupRoles();
      
      // Try getting group relationships
      await this.scanGroupRelationships();
      
      // Try getting group members
      await this.scanGroupMembers();
      
      // Try group wall posts
      await this.scanGroupWall();
      
      // Try the normal website for the group
      await this.scanGroupPage();
      
      // Try group audit log 
      await this.scanGroupAuditLog();
      
      // Try group policies
      await this.scanGroupPolicies();
      
      // Try group settings
      await this.scanGroupSettings();
      
      // For now, we'll skip related groups since we're already implementing relationships
      // await this.scanRelatedGroups();
      
      // CATALOG/MARKETPLACE ENDPOINTS
      console.log('Scanning CATALOG-related endpoints...');
      // Try catalog search for Pet Simulator 99 content
      await this.scanCatalogSearch();
      
      // Try marketplace items
      await this.scanMarketplaceItems();
      
      // Try catalog search with specific keywords
      await this.scanCatalogWithKeywords();
      
      // Try catalog with creator filter
      await this.scanCatalogByCreator();
      
      // Try catalog recents (to be implemented)
      // await this.scanCatalogRecent();
      
      // GAME RELATED ENDPOINTS 
      console.log('Scanning GAME-related endpoints...');
      // Try game info
      await this.scanGameInfo();
      
      // Try game stats
      await this.scanGameStats();
      
      // Try game passes
      await this.scanGamePasses();
      
      // Try game badges
      await this.scanGameBadges();
      
      // Try badge localization
      await this.scanBadgeLocalization();
      
      // Try game products
      await this.scanGameProducts();
      
      // Try developer product localization
      await this.scanDeveloperProductLocalization();
      
      // Try game social links
      await this.scanGameSocial();
      
      // Try game servers
      await this.scanGameServers();
      
      // Try game icons/thumbnails
      await this.scanGameIcons();
      await this.scanGameLocalizedThumbnails();
      
      // Try game page (web) (to be implemented)
      // await this.scanGamePage();
      
      // Try test site servers (to be implemented)
      // await this.scanTestSiteServers();
      
      // Try private servers list (to be implemented)
      // await this.scanPrivateServers();
      
      // TEAM CREATE ENDPOINTS
      console.log('Scanning TEAM CREATE endpoints...');
      // Try team create settings
      await this.scanTeamCreateSettings();
      
      // Try team create members
      await this.scanTeamCreateMembers();
      
      // UNIVERSE MANAGEMENT ENDPOINTS
      console.log('Scanning UNIVERSE MANAGEMENT endpoints...');
      // Try universe activation status
      await this.scanUniverseActivation();
      
      // Try universe permissions
      await this.scanUniversePermissions();
      
      // USER FOLLOWING ENDPOINTS
      console.log('Scanning USER FOLLOWING endpoints...');
      // Try user following status
      await this.scanUserFollowingStatus();
      
      // EXPERIENCE ENDPOINTS (Rodux)
      console.log('Scanning EXPERIENCE endpoints from Rodux...');
      // Try experience configuration
      await this.scanExperienceConfiguration();
      
      // Try experience media
      await this.scanExperienceMedia();
      
      // Try experience details
      await this.scanExperienceDetails();
      
      // PLACE CONFIGURATION (Rodux)
      console.log('Scanning PLACE CONFIGURATION endpoints from Rodux...');
      // Try place configuration
      await this.scanPlaceConfiguration();
      
      // AVATAR ENDPOINTS (Rodux)
      console.log('Scanning AVATAR endpoints from Rodux...');
      // Try avatar assets
      await this.scanAvatarAssets();
      
      // MARKETPLACE PAGES (HTML)
      console.log('Scanning MARKETPLACE pages...');
      // Try web-based marketplace pages
      await this.scanMarketplacePages();
      
      // CREATOR STORE API (Toolbox Service)
      console.log('Scanning Creator Store API (Toolbox Service)...');
      await this.scanCreatorStore();
      
      // Try creator hub pages (to be implemented)
      // await this.scanCreatorHubPages();
      
      // Try library pages (to be implemented)
      // await this.scanLibraryPage();
      
      // USER-BASED ENDPOINTS
      console.log('Scanning USER-related endpoints...');
      // These user endpoints require implementation
      // We'll skip them for now to focus on working endpoints
      
      // CDN ENDPOINTS
      console.log('Scanning CDN endpoints...');
      // CDN endpoints to be implemented later
      // They often require special handling for binary data
      
      // ASSET RELATED ENDPOINTS
      console.log('Scanning ASSET-related endpoints...');
      // For each asset ID we've found, try additional endpoints
      const discoveredAssetIds = Array.from(this.assetIds);
      console.log(`Found ${discoveredAssetIds.length} asset IDs for further scanning`);
      
      // Only process a few asset IDs to avoid overloading
      // We'll increase to 30 to discover more but watch for rate limits
      const assetIdsToProcess = discoveredAssetIds.slice(0, 30);
      const batchSize = 5;
      
      // Process them in batches
      for (let i = 0; i < assetIdsToProcess.length; i += batchSize) {
        const batch = assetIdsToProcess.slice(i, i + batchSize);
        console.log(`Processing batch ${i/batchSize + 1}/${Math.ceil(assetIdsToProcess.length/batchSize)} of asset IDs...`);
        
        for (const assetId of batch) {
          // Try asset info
          await this.scanAssetInfo(assetId);
          
          // Try asset favorites
          await this.scanAssetFavorites(assetId);
          
          // Try asset thumbnail
          await this.scanAssetThumbnail(assetId);
          
          // Try asset bundles
          await this.scanAssetBundles(assetId);
          
          // Try asset resellers
          await this.scanAssetResellers(assetId);
          
          // Try similar items
          await this.scanSimilarItems(assetId);
          
          // Try new comprehensive asset delivery scanning
          await this.scanAssetWithDeliveryScanner(assetId);
        }
        
        // Add a small pause between batches to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
      
      // THUMBNAILS AND IMAGES
      console.log('Scanning additional THUMBNAIL endpoints...');
      // Scan for bundle thumbnails if we found any bundles (to be implemented)
      // await this.scanBundleThumbnails();
      
      // Track protected endpoints for later implementation
      bypassed.push(
        'Content API endpoints (need auth)',
        'Developer API endpoints (need auth)',
        'Open Cloud API (need API key)',
        'Marketplace API (needs auth)',
        'Friend/social APIs (need auth)',
        'Private testing servers (need auth)',
        'Hidden test sites (need special access)',
        'Asset delivery endpoints (need bypass)',
        'Place configuration endpoints (need auth)',
        'Avatar API endpoints (need auth)',
        'Mesh content endpoints (need auth)',
        'Package content endpoints (need bypass)',
        'Presence API (need auth token)'
      );
      
      // Update last scan time
      this.lastScanTime = new Date();
      this.inProgress = false;
      
      // Save a log of bypassed endpoints for reference
      await storage.createActivity({
        id: nanoid(),
        type: 'other',
        description: `Comprehensive scan: ${this.results.length} endpoints, ${this.apiCallsCount} API calls. Found ${this.totalAssets} assets. Bypassed ${bypassed.length} protected endpoints.`,
        creator: 'system',
        timestamp: 'Just now'
      });
      
      console.log(`Scan completed. Found ${this.totalAssets} assets.`);
      
      return {
        success: true,
        endpoints: this.results,
        totalAssets: this.totalAssets,
        apiCalls: this.apiCallsCount,
        bypassedEndpoints: bypassed.length
      };
      
    } catch (error: any) {
      console.error('Error in scan:', error);
      this.inProgress = false;
      
      return {
        success: false,
        message: error.message || 'Unknown error in scan',
        timestamp: new Date()
      };
    }
  }
  
  /**
   * Scan for group info - this is a known working endpoint
   */
  private async scanGroupInfo(): Promise<void> {
    console.log('Scanning group info...');
    
    const endpointName = 'GROUP_INFO';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_INFO.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with smart rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group info`);
        
        // Create an asset with the group info
        const assetId = nanoid();
        // Generate a thumbnail URL for the group
        const groupThumbnailUrl = `https://t0.rbxcdn.com/7b9b0a34d89e60c9c24ad3abd2e3863f`;
        
        await storage.createAsset({
          id: assetId,
          name: response.data.name || 'BIG Games Pets Community',
          // Use a more meaningful type
          type: 'Decal',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          // Add group icon thumbnail
          thumbnail: groupThumbnailUrl,
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            name: response.data.name,
            description: response.data.description,
            memberCount: response.data.memberCount,
            created: response.data.created,
            thumbnailUrl: groupThumbnailUrl,
            robloxData: {
              assetType: 'Group',
              creatorType: 'Group',
              creatorId: CONFIRMED_GROUP_ID,
              creatorName: response.data.name || 'BIG Games Pets Community'
            }
          },
          sourceUrl: `https://www.roblox.com/groups/${CONFIRMED_GROUP_ID}/BIG-Games-Pets-Community`
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found group: ${response.data.name}`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group info:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan for group games - another known working endpoint
   */
  private async scanGroupGames(): Promise<void> {
    console.log('Scanning group games...');
    
    const endpointName = 'GROUP_GAMES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_GAMES.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with smart rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group games`);
        
        let gameCount = 0;
        
        // Process each game
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const game of response.data.data) {
            // Create an asset for each game
            const assetId = nanoid();
            await storage.createAsset({
              id: assetId,
              name: game.name || 'Unknown Game',
              type: 'Game',
              size: `${JSON.stringify(game).length} bytes`,
              game: game.name || 'Unknown',
              creator: 'BIG Games',
              detectedAt: 'Just now',
              status: 'New',
              // Add game thumbnail for proper display
              thumbnail: `https://tr.rbxcdn.com/asset-thumbnail/image?assetId=${game.rootPlaceId}&width=420&height=420&format=png`,
              robloxAssetId: game.rootPlaceId?.toString(),
              metadata: {
                format: 'json',
                gameId: game.id,
                placeId: game.rootPlaceId,
                created: game.created,
                updated: game.updated,
                visits: game.placeVisits,
                thumbnailUrl: `https://tr.rbxcdn.com/asset-thumbnail/image?assetId=${game.rootPlaceId}&width=420&height=420&format=png`,
                robloxData: {
                  assetType: 'Game',
                  created: game.created,
                  updated: game.updated,
                  creatorId: game.creatorId?.toString(),
                  creatorType: 'Group',
                  creatorName: 'BIG Games'
                }
              },
              sourceUrl: `https://www.roblox.com/games/${game.rootPlaceId}/`
            });
            
            // Add to known asset IDs
            if (game.id) this.assetIds.add(game.id);
            if (game.rootPlaceId) this.assetIds.add(game.rootPlaceId);
            if (game.universeId) this.assetIds.add(game.universeId);
            
            gameCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${gameCount} games`,
          assetCount: gameCount
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group games:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group roles - added endpoint
   */
  private async scanGroupRoles(): Promise<void> {
    console.log('Scanning group roles...');
    
    const endpointName = 'GROUP_ROLES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_ROLES.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group roles`);
        
        // Create an asset with the group roles
        const assetId = nanoid();
        // Use the same group thumbnail for consistent display
        const groupThumbnailUrl = `https://t0.rbxcdn.com/7b9b0a34d89e60c9c24ad3abd2e3863f`;
        
        await storage.createAsset({
          id: assetId,
          name: `BIG Games Pets Community - Group Roles`,
          // Use a more appropriate type
          type: 'Decal',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          // Add thumbnail for proper display
          thumbnail: groupThumbnailUrl,
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            thumbnailUrl: groupThumbnailUrl,
            roleCount: response.data.roles ? response.data.roles.length : 0,
            roles: response.data.roles ? response.data.roles.map((role: any) => role.name) : [],
            robloxData: {
              assetType: 'Group',
              creatorType: 'Group',
              creatorId: CONFIRMED_GROUP_ID,
              creatorName: 'BIG Games Pets Community'
            }
          },
          sourceUrl: `https://www.roblox.com/groups/${CONFIRMED_GROUP_ID}/BIG-Games-Pets-Community#!/about`
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${response.data.roles ? response.data.roles.length : 0} group roles`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group roles:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group relationships - added endpoint
   */
  private async scanGroupWall(): Promise<void> {
    console.log('Scanning group wall posts...');
    
    const endpointName = 'GROUP_WALL';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_WALL.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group wall posts`);
        
        const posts = response.data.data || [];
        let postCount = posts.length;
        
        // Create an asset with the wall posts
        const assetId = nanoid();
        // Use the same group thumbnail for consistent display
        const groupThumbnailUrl = `https://t0.rbxcdn.com/7b9b0a34d89e60c9c24ad3abd2e3863f`;
        
        await storage.createAsset({
          id: assetId,
          name: `BIG Games Pets Community - Wall Posts`,
          // Use a more appropriate type
          type: 'Decal',
          size: `${JSON.stringify(posts).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          // Add thumbnail for proper display
          thumbnail: groupThumbnailUrl,
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            thumbnailUrl: groupThumbnailUrl,
            postCount: postCount,
            posts: posts.map((post: any) => ({
              id: post.id,
              body: post.body,
              created: post.created,
              updated: post.updated,
              poster: post.poster ? {
                id: post.poster.user.userId,
                username: post.poster.user.username
              } : null
            })),
            robloxData: {
              assetType: 'Group',
              creatorType: 'Group',
              creatorId: CONFIRMED_GROUP_ID,
              creatorName: 'BIG Games Pets Community'
            }
          },
          sourceUrl: `https://www.roblox.com/groups/${CONFIRMED_GROUP_ID}/BIG-Games-Pets-Community#!/wall`
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${postCount} group wall posts`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group wall posts:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group relationships - added endpoint
   */
  private async scanGroupRelationships(): Promise<void> {
    console.log('Scanning group relationships...');
    
    const endpointName = 'GROUP_RELATIONSHIPS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_RELATIONSHIPS.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group relationships`);
        
        // Create an asset with the group relationships
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Group Relationships: BIG Games Pets Community`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'System',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            relationshipCount: response.data.relatedGroups ? response.data.relatedGroups.length : 0,
            relationships: response.data.relatedGroups || []
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${response.data.relatedGroups ? response.data.relatedGroups.length : 0} group relationships`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group relationships:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group members - added endpoint
   */
  private async scanGroupMembers(): Promise<void> {
    console.log('Scanning group members...');
    
    const endpointName = 'GROUP_MEMBERS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_MEMBERS.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request
      const response = await axios.get(endpointUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json'
        },
        timeout: 10000
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group members`);
        
        // Create an asset with the group members
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Group Members: BIG Games Pets Community`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'System',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            memberCount: response.data.data ? response.data.data.length : 0,
            members: response.data.data ? response.data.data.map((member: any) => ({
              username: member.username,
              displayName: member.displayName,
              userId: member.userId,
              role: member.role?.name
            })) : []
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${response.data.data ? response.data.data.length : 0} group members`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group members:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group page - this is just the regular website HTML
   */
  private async scanGroupPage(): Promise<void> {
    console.log('Scanning group page...');
    
    const endpointName = 'GROUP_PAGE';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_PAGE.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request
      const response = await axios.get(endpointUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html'
        },
        timeout: 15000
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group page HTML`);
        
        // Create an asset with the group page HTML
        const assetId = nanoid();
        // Use the same group thumbnail for consistent display
        const groupThumbnailUrl = `https://t0.rbxcdn.com/7b9b0a34d89e60c9c24ad3abd2e3863f`;
        
        await storage.createAsset({
          id: assetId,
          name: `BIG Games Pets Community - Group Page`,
          // Use a more appropriate type
          type: 'Decal',
          size: `${response.data.length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          // Add thumbnail for proper display
          thumbnail: groupThumbnailUrl,
          metadata: {
            format: 'html',
            contentType: response.headers['content-type'],
            contentLength: response.headers['content-length'],
            snippet: response.data.substring(0, 500) + '...',
            thumbnailUrl: groupThumbnailUrl,
            robloxData: {
              assetType: 'Group',
              creatorType: 'Group',
              creatorId: CONFIRMED_GROUP_ID,
              creatorName: 'BIG Games Pets Community'
            }
          },
          sourceUrl: `https://www.roblox.com/groups/${CONFIRMED_GROUP_ID}/BIG-Games-Pets-Community`
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Retrieved group page HTML (${response.data.length} bytes)`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group page:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan the catalog for Pet Simulator 99 related items
   */
  private async scanCatalogSearch(): Promise<void> {
    console.log('Scanning catalog for PS99 items...');
    
    const endpointName = 'CATALOG_SEARCH';
    const endpointUrl = `${ACCESSIBLE_ENDPOINTS.CATALOG_SEARCH}&keyword=pet%20simulator%2099`;
    
    try {
      // Make the request
      const response = await axios.get(endpointUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json'
        },
        timeout: 10000
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully searched catalog`);
        
        let itemCount = 0;
        
        // Process each item
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const item of response.data.data) {
            // Create an asset for each item with improved details
            const assetId = nanoid();
            
            // Map item type to our asset type system
            const assetType = mapRobloxAssetType(item.itemType || 'Unknown');
            
            // Get thumbnail URL for this asset
            const thumbnailUrl = getThumbnailUrl(item.id, item.itemType);
            
            await storage.createAsset({
              id: assetId,
              name: item.name || 'Unknown Item',
              type: assetType,
              thumbnail: thumbnailUrl,
              size: `${JSON.stringify(item).length} bytes`,
              game: 'Pet Simulator 99',
              creator: item.creatorName || 'Unknown',
              detectedAt: 'Just now',
              status: 'New',
              robloxAssetId: item.id?.toString(),
              metadata: {
                format: 'json',
                itemId: item.id,
                itemType: item.itemType,
                name: item.name,
                description: item.description,
                price: item.price,
                thumbnailUrl: thumbnailUrl,
                robloxData: {
                  assetType: item.itemType,
                  creatorType: item.creatorType,
                  creatorId: item.creatorId?.toString(),
                  creatorName: item.creatorName
                }
              },
              sourceUrl: `https://www.roblox.com/catalog/${item.id}/`
            });
            
            // Add to known asset IDs
            if (item.id) this.assetIds.add(item.id);
            
            itemCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${itemCount} catalog items`,
          assetCount: itemCount
        });
      }
    } catch (error: any) {
      console.error(`Error searching catalog:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan marketplace items
   */
  private async scanMarketplaceItems(): Promise<void> {
    console.log('Scanning marketplace items...');
    
    const endpointName = 'MARKETPLACE_ITEMS';
    const endpointUrl = `${ACCESSIBLE_ENDPOINTS.MARKETPLACE_ITEMS}&keyword=pet%20simulator%2099`;
    
    try {
      // Make the request
      const response = await axios.get(endpointUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json'
        },
        timeout: 10000
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched marketplace items`);
        
        let itemCount = 0;
        
        // Process each item
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const item of response.data.data) {
            // Create an asset for each item
            const assetId = nanoid();
            await storage.createAsset({
              id: assetId,
              name: `Marketplace Item: ${item.name || 'Unknown Item'}`,
              type: item.type || 'API',
              size: `${JSON.stringify(item).length} bytes`,
              game: 'Pet Simulator 99',
              creator: item.creator?.name || 'Unknown',
              detectedAt: 'Just now',
              status: 'New',
              metadata: {
                format: 'json',
                itemId: item.id,
                itemType: item.type,
                name: item.name,
                description: item.description,
                price: item.price,
                creatorId: item.creator?.id,
                creatorType: item.creator?.type
              },
              sourceUrl: `https://www.roblox.com/catalog/${item.id}/`
            });
            
            // Add to known asset IDs
            if (item.id) this.assetIds.add(item.id);
            
            itemCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${itemCount} marketplace items`,
          assetCount: itemCount
        });
      }
    } catch (error: any) {
      console.error(`Error fetching marketplace items:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game info
   */
  private async scanGameInfo(): Promise<void> {
    console.log('Scanning game info...');
    
    const endpointName = 'GAME_INFO';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_INFO.replace('{universeIds}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request
      const response = await axios.get(endpointUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json'
        },
        timeout: 10000
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game info`);
        
        // Create an asset with the game info
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Game Info: Pet Simulator 99`,
          type: 'Game',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            votes: response.data.data ? response.data.data[0] : null
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game info`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game info:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game stats
   */
  private async scanGameStats(): Promise<void> {
    console.log('Scanning game stats...');
    
    const endpointName = 'GAME_STATS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_STATS.replace('{universeIds}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game stats`);
        
        // Create an asset with the game stats
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Game Stats: Pet Simulator 99`,
          type: 'Game',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            stats: response.data.data ? response.data.data[0] : null
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game stats`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game stats:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game badges
   */
  private async scanGameBadges(): Promise<void> {
    console.log('Scanning game badges...');
    
    const endpointName = 'GAME_BADGES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_BADGES.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game badges`);
        
        let badgeCount = 0;
        
        // Process each badge
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const badge of response.data.data) {
            // Create an asset for each badge
            const assetId = nanoid();
            await storage.createAsset({
              id: assetId,
              name: `Badge: ${badge.name || 'Unknown Badge'}`,
              type: 'Badge',
              size: `${JSON.stringify(badge).length} bytes`,
              game: 'Pet Simulator 99',
              creator: 'BIG Games',
              detectedAt: 'Just now',
              status: 'New',
              metadata: {
                format: 'json',
                badgeId: badge.id,
                name: badge.name,
                description: badge.description,
                enabled: badge.enabled,
                created: badge.created,
                updated: badge.updated,
                universeId: PS99_UNIVERSE_ID
              },
              sourceUrl: `https://www.roblox.com/badges/${badge.id}/`
            });
            
            // Add to known asset IDs
            if (badge.id) this.assetIds.add(badge.id);
            
            badgeCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${badgeCount} game badges`,
          assetCount: badgeCount
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game badges:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game products (developer products)
   */
  private async scanGameProducts(): Promise<void> {
    console.log('Scanning game developer products...');
    
    const endpointName = 'GAME_PRODUCTS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_PRODUCTS.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game developer products`);
        
        let productCount = 0;
        
        // Process each product
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const product of response.data.data) {
            // Create an asset for each product
            const assetId = nanoid();
            await storage.createAsset({
              id: assetId,
              name: `Developer Product: ${product.name || 'Unknown Product'}`,
              type: 'Other',
              size: `${JSON.stringify(product).length} bytes`,
              game: 'Pet Simulator 99',
              creator: 'BIG Games',
              detectedAt: 'Just now',
              status: 'New',
              metadata: {
                format: 'json',
                productId: product.id,
                name: product.name,
                description: product.description,
                price: product.price,
                universeId: PS99_UNIVERSE_ID
              },
              sourceUrl: endpointUrl
            });
            
            // Add to known asset IDs
            if (product.id) this.assetIds.add(product.id);
            
            productCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${productCount} developer products`,
          assetCount: productCount
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game developer products:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game social links
   */
  private async scanGameSocial(): Promise<void> {
    console.log('Scanning game social links...');
    
    const endpointName = 'GAME_SOCIAL';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_SOCIAL.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game social links`);
        
        // Create an asset with social links
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Game Social Links: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            links: response.data.data
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game social links`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game social links:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game servers
   */
  private async scanGameServers(): Promise<void> {
    console.log('Scanning game servers...');
    
    const endpointName = 'GAME_SERVERS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_SERVERS.replace('{placeId}', PS99_GAME_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game servers`);
        
        // Create an asset with server info
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Game Servers: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            placeId: PS99_GAME_ID,
            serverCount: response.data.data ? response.data.data.length : 0
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${response.data.data ? response.data.data.length : 0} game servers`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game servers:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game icons
   */
  private async scanGameIcons(): Promise<void> {
    console.log('Scanning game icons...');
    
    const endpointName = 'GAME_ICONS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_ICONS.replace('{universeIds}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
        console.log(`✓ Successfully fetched game icons`);
        
        const iconData = response.data.data[0];
        const iconUrl = iconData.imageUrl;
        
        // Create an asset with the icon
        const iconAssetId = nanoid();
        await storage.createAsset({
          id: iconAssetId,
          name: `Game Icon: Pet Simulator 99`,
          type: 'Texture',
          size: 'Icon URL',
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'image',
            universeId: PS99_UNIVERSE_ID,
            state: iconData.state,
            width: iconData.targetWidth || 512,
            height: iconData.targetHeight || 512,
            imageUrl: iconUrl
          },
          sourceUrl: iconUrl || endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game icon URL: ${iconUrl ? 'Yes' : 'No'}`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game icons:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game thumbnails
   */
  private async scanGameThumbnails(): Promise<void> {
    console.log('Scanning game thumbnails...');
    
    const endpointName = 'GAME_THUMBNAIL';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_THUMBNAIL.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
        console.log(`✓ Successfully fetched game thumbnails`);
        
        const thumbnailData = response.data.data[0];
        const thumbnailUrl = thumbnailData.imageUrl;
        
        // Create an asset with the thumbnail
        const thumbnailAssetId = nanoid();
        await storage.createAsset({
          id: thumbnailAssetId,
          name: `Game Thumbnail: Pet Simulator 99`,
          type: 'Texture',
          size: 'Thumbnail URL',
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'image',
            universeId: PS99_UNIVERSE_ID,
            state: thumbnailData.state,
            width: thumbnailData.targetWidth || 768,
            height: thumbnailData.targetHeight || 432,
            imageUrl: thumbnailUrl
          },
          sourceUrl: thumbnailUrl || endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game thumbnail URL: ${thumbnailUrl ? 'Yes' : 'No'}`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game thumbnails:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game passes
   */
  private async scanGamePasses(): Promise<void> {
    console.log('Scanning game passes...');
    
    const endpointName = 'GAME_PASSES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_PASSES.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request
      const response = await axios.get(endpointUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json'
        },
        timeout: 10000
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game passes`);
        
        let passCount = 0;
        
        // Process each game pass
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const pass of response.data.data) {
            // Create an asset for each game pass
            const assetId = nanoid();
            await storage.createAsset({
              id: assetId,
              name: `Game Pass: ${pass.name || 'Unknown Pass'}`,
              type: 'Gamepass',
              size: `${JSON.stringify(pass).length} bytes`,
              game: 'Pet Simulator 99',
              creator: 'BIG Games',
              detectedAt: 'Just now',
              status: 'New',
              metadata: {
                format: 'json',
                passId: pass.id,
                name: pass.name,
                description: pass.description,
                price: pass.price,
                universeId: PS99_UNIVERSE_ID
              },
              sourceUrl: `https://www.roblox.com/game-pass/${pass.id}/`
            });
            
            // Add to known asset IDs
            if (pass.id) this.assetIds.add(pass.id);
            
            passCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${passCount} game passes`,
          assetCount: passCount
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game passes:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan asset info
   */
  private async scanAssetInfo(assetId: string): Promise<void> {
    console.log(`Scanning asset info for asset ID ${assetId}...`);
    
    const endpointName = 'ASSET_INFO';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.ASSET_INFO.replace('{assetId}', assetId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched asset info for asset ID ${assetId}`);
        
        // Determine asset type based on data
        let assetType = 'API';
        if (response.data.assetTypeId) {
          switch (response.data.assetTypeId) {
            case 1: assetType = 'Texture'; break;
            case 3: assetType = 'Audio'; break;
            case 4: assetType = 'Mesh'; break;
            case 5: assetType = 'Script'; break;
            case 9: assetType = 'Place'; break;
            case 10: assetType = '3D Model'; break;
            case 13: assetType = 'Decal'; break;
            case 24: assetType = 'Animation'; break;
            case 34: assetType = 'Badge'; break;
            case 38: assetType = 'MeshPart'; break;
            case 61: assetType = 'Plugin'; break;
            default: assetType = 'API';
          }
        }
        
        // Create an asset with the asset info
        const detailedAssetId = nanoid();
        await storage.createAsset({
          id: detailedAssetId,
          name: `Asset: ${response.data.name || 'Unknown Asset'}`,
          type: assetType as any,
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: response.data.creator?.name || 'Unknown',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            assetId: assetId,
            name: response.data.name,
            description: response.data.description,
            assetTypeId: response.data.assetTypeId,
            assetType: assetType,
            created: response.data.created,
            updated: response.data.updated,
            creatorId: response.data.creator?.id,
            creatorType: response.data.creator?.type
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName: `${endpointName} (Asset ${assetId})`,
          endpointUrl,
          success: true,
          message: `Found asset info for ${response.data.name || 'Unknown Asset'}`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching asset info for asset ID ${assetId}:`, error.message);
      
      this.results.push({
        endpointName: `${endpointName} (Asset ${assetId})`,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan asset favorites
   */
  private async scanAssetFavorites(assetId: string): Promise<void> {
    console.log(`Scanning asset favorites for asset ID ${assetId}...`);
    
    const endpointName = 'ASSET_FAVORITES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.ASSET_FAVORITES.replace('{assetId}', assetId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched asset favorites for asset ID ${assetId}`);
        
        // Create an asset with the favorites info
        const favAssetId = nanoid();
        await storage.createAsset({
          id: favAssetId,
          name: `Asset Favorites: Asset ID ${assetId}`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'System',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            assetId: assetId,
            favoriteCount: response.data.count
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName: `${endpointName} (Asset ${assetId})`,
          endpointUrl,
          success: true,
          message: `Found asset favorites count: ${response.data.count}`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching asset favorites for asset ID ${assetId}:`, error.message);
      
      this.results.push({
        endpointName: `${endpointName} (Asset ${assetId})`,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan asset thumbnail
   */
  private async scanAssetThumbnail(assetId: string): Promise<void> {
    console.log(`Scanning asset thumbnail for asset ID ${assetId}...`);
    
    const endpointName = 'ASSET_THUMBNAIL';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.ASSET_THUMBNAIL.replace('{assetId}', assetId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
        console.log(`✓ Successfully fetched asset thumbnail for asset ID ${assetId}`);
        
        const thumbnailData = response.data.data[0];
        const thumbnailUrl = thumbnailData.imageUrl;
        
        // Create an asset with the thumbnail info
        const thumbAssetId = nanoid();
        await storage.createAsset({
          id: thumbAssetId,
          name: `Asset Thumbnail: Asset ID ${assetId}`,
          type: 'Texture',
          size: `Thumbnail URL`,
          game: 'Pet Simulator 99',
          creator: 'System',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'image',
            assetId: assetId,
            state: thumbnailData.state,
            width: thumbnailData.targetWidth || 420,
            height: thumbnailData.targetHeight || 420,
            imageUrl: thumbnailUrl
          },
          sourceUrl: thumbnailUrl || endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName: `${endpointName} (Asset ${assetId})`,
          endpointUrl,
          success: true,
          message: `Found asset thumbnail URL: ${thumbnailUrl ? 'Yes' : 'No'}`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching asset thumbnail for asset ID ${assetId}:`, error.message);
      
      this.results.push({
        endpointName: `${endpointName} (Asset ${assetId})`,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan asset bundles
   */
  private async scanAssetBundles(assetId: string): Promise<void> {
    console.log(`Scanning asset bundles for asset ID ${assetId}...`);
    
    const endpointName = 'ASSET_BUNDLES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.ASSET_BUNDLES.replace('{assetId}', assetId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched asset bundles for asset ID ${assetId}`);
        
        let bundleCount = 0;
        
        // Process each bundle
        if (response.data.data && Array.isArray(response.data.data)) {
          for (const bundle of response.data.data) {
            // Create an asset for each bundle
            const bundleAssetId = nanoid();
            await storage.createAsset({
              id: bundleAssetId,
              name: `Bundle: ${bundle.name || 'Unknown Bundle'}`,
              type: 'Package',
              size: `${JSON.stringify(bundle).length} bytes`,
              game: 'Pet Simulator 99',
              creator: bundle.creator?.name || 'Unknown',
              detectedAt: 'Just now',
              status: 'New',
              metadata: {
                format: 'json',
                bundleId: bundle.id,
                name: bundle.name,
                description: bundle.description,
                bundleType: bundle.bundleType,
                assetId: assetId
              },
              sourceUrl: `https://www.roblox.com/bundles/${bundle.id}/`
            });
            
            // Add to known asset IDs
            if (bundle.id) this.assetIds.add(bundle.id);
            
            bundleCount++;
            this.totalAssets++;
          }
        }
        
        // Store result
        this.results.push({
          endpointName: `${endpointName} (Asset ${assetId})`,
          endpointUrl,
          success: true,
          message: `Found ${bundleCount} bundles for asset`,
          assetCount: bundleCount
        });
      }
    } catch (error: any) {
      console.error(`Error fetching asset bundles for asset ID ${assetId}:`, error.message);
      
      this.results.push({
        endpointName: `${endpointName} (Asset ${assetId})`,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan catalog with specific Pet Simulator 99 related keywords
   */
  private async scanCatalogWithKeywords(): Promise<void> {
    console.log('Scanning catalog with PS99 specific keywords...');
    
    // Pet Simulator 99 specific keywords that might yield results
    const keywords = [
      'huge pet',
      'pet simulator 99',
      'ps99',
      'exclusive pet',
      'legendary pet',
      'mythical pet',
      'pet sim',
      'titanic pet',
      'egg hunt',
      'pet gems',
      'pet coins'
    ];
    
    let totalItemsFound = 0;
    
    for (const keyword of keywords) {
      console.log(`Searching catalog for keyword: "${keyword}"...`);
      
      const endpointName = 'CATALOG_SEARCH';
      const endpointUrl = ACCESSIBLE_ENDPOINTS.CATALOG_SEARCH.replace('{keyword}', encodeURIComponent(keyword));
      
      try {
        // Make the request with smart rate limiting
        const response = await this.makeRequest(endpointUrl, {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'application/json'
        });
        
        // Process response
        if (response.status === 200 && response.data) {
          console.log(`✓ Successfully searched catalog for "${keyword}"`);
          
          const items = response.data.data || [];
          let itemCount = 0;
          
          if (items.length > 0) {
            // Create an asset with the catalog search results
            const catalogAssetId = nanoid();
            await storage.createAsset({
              id: catalogAssetId,
              name: `Catalog Search: "${keyword}"`,
              type: 'Other',
              size: `${JSON.stringify(items).length} bytes`,
              game: 'Pet Simulator 99',
              creator: 'System',
              detectedAt: 'Just now',
              status: 'New',
              metadata: {
                format: 'json',
                keyword: keyword,
                itemCount: items.length,
                items: items.map((item: any) => ({
                  id: item.id,
                  name: item.name,
                  description: item.description || '',
                  type: item.itemType,
                  price: item.price || 0,
                  creatorType: item.creatorType,
                  creatorName: item.creatorName
                }))
              },
              sourceUrl: endpointUrl
            });
            
            // Add these catalog item IDs to our collection for further processing
            for (const item of items) {
              if (item.id) {
                this.assetIds.add(item.id.toString());
                itemCount++;
              }
            }
            
            this.totalAssets++;
            totalItemsFound += itemCount;
          }
          
          // Store result
          this.results.push({
            endpointName: `${endpointName} (${keyword})`,
            endpointUrl,
            success: true,
            message: `Found ${itemCount} items for keyword "${keyword}"`,
            assetCount: itemCount > 0 ? 1 : 0
          });
        }
      } catch (error: any) {
        console.error(`Error searching catalog for "${keyword}":`, error.message);
        
        this.results.push({
          endpointName: `${endpointName} (${keyword})`,
          endpointUrl,
          success: false,
          error: error.message
        });
      }
      
      // Add a pause between keyword searches to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    
    console.log(`Completed keyword searches. Found ${totalItemsFound} total items across all keywords.`);
  }
  
  /**
   * Scan catalog by creator (Big Games)
   */
  private async scanCatalogByCreator(): Promise<void> {
    console.log('Scanning catalog items by creator (BIG Games)...');
    
    const endpointName = 'CATALOG_BY_CREATOR';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.CATALOG_BY_CREATOR.replace('{creatorId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched catalog items by BIG Games`);
        
        const items = response.data.data || [];
        let itemCount = 0;
        
        if (items.length > 0) {
          // Create an asset with the catalog items
          const catalogAssetId = nanoid();
          await storage.createAsset({
            id: catalogAssetId,
            name: `BIG Games Catalog Items`,
            type: 'Other',
            size: `${JSON.stringify(items).length} bytes`,
            game: 'Pet Simulator 99',
            creator: 'BIG Games',
            detectedAt: 'Just now',
            status: 'New',
            metadata: {
              format: 'json',
              groupId: CONFIRMED_GROUP_ID,
              itemCount: items.length,
              items: items.map((item: any) => ({
                id: item.id,
                name: item.name,
                description: item.description,
                type: item.type,
                price: item.price,
                creatorType: item.creatorType,
                creatorName: item.creatorName
              }))
            },
            sourceUrl: endpointUrl
          });
          
          // Add these catalog item IDs to our collection for further processing
          for (const item of items) {
            if (item.id) {
              this.assetIds.add(item.id.toString());
              itemCount++;
            }
          }
          
          this.totalAssets++;
        }
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found ${itemCount} catalog items by BIG Games`,
          assetCount: itemCount > 0 ? 1 : 0
        });
      }
    } catch (error: any) {
      console.error(`Error fetching catalog items by creator:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan for similar items
   */
  private async scanSimilarItems(assetId: string): Promise<void> {
    console.log(`Scanning similar items for asset ID ${assetId}...`);
    
    const endpointName = 'CATALOG_SIMILAR';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.CATALOG_SIMILAR.replace('{assetId}', assetId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched similar items for asset ID ${assetId}`);
        
        const similarItems = response.data.data || [];
        let itemCount = 0;
        
        if (similarItems.length > 0) {
          // Create an asset with the similar items info
          const similarAssetId = nanoid();
          await storage.createAsset({
            id: similarAssetId,
            name: `Similar Items: Asset ID ${assetId}`,
            type: 'Other',
            size: `${JSON.stringify(similarItems).length} bytes`,
            game: 'Pet Simulator 99',
            creator: 'System',
            detectedAt: 'Just now',
            status: 'New',
            metadata: {
              format: 'json',
              assetId: assetId,
              similarCount: similarItems.length,
              similarItems: similarItems.map((item: any) => ({
                id: item.id,
                name: item.name,
                type: item.type,
                price: item.price
              }))
            },
            sourceUrl: endpointUrl
          });
          
          // Also add these similar item IDs to our collection for further processing
          for (const item of similarItems) {
            if (item.id) {
              this.assetIds.add(item.id.toString());
              itemCount++;
            }
          }
          
          this.totalAssets++;
        }
        
        // Store result
        this.results.push({
          endpointName: `${endpointName} (Asset ${assetId})`,
          endpointUrl,
          success: true,
          message: `Found ${itemCount} similar items`,
          assetCount: itemCount > 0 ? 1 : 0
        });
      }
    } catch (error: any) {
      console.error(`Error fetching similar items for asset ID ${assetId}:`, error.message);
      
      this.results.push({
        endpointName: `${endpointName} (Asset ${assetId})`,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan asset resellers
   */
  private async scanAssetResellers(assetId: string): Promise<void> {
    console.log(`Scanning asset resellers for asset ID ${assetId}...`);
    
    const endpointName = 'ASSET_RESELLERS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.ASSET_RESELLERS.replace('{assetId}', assetId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched asset resellers for asset ID ${assetId}`);
        
        // Create an asset with the resellers info
        const resellersAssetId = nanoid();
        await storage.createAsset({
          id: resellersAssetId,
          name: `Asset Resellers: Asset ID ${assetId}`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'System',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            assetId: assetId,
            count: response.data.data ? response.data.data.length : 0,
            lowestPrice: response.data.data && response.data.data.length > 0 ? 
              Math.min(...response.data.data.map((item: any) => item.price || 0)) : 0
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName: `${endpointName} (Asset ${assetId})`,
          endpointUrl,
          success: true,
          message: `Found ${response.data.data ? response.data.data.length : 0} resellers for asset`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching asset resellers for asset ID ${assetId}:`, error.message);
      
      this.results.push({
        endpointName: `${endpointName} (Asset ${assetId})`,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan marketplace pages
   */
  private async scanMarketplacePages(): Promise<void> {
    console.log('Scanning marketplace pages...');
    
    // Try each marketplace page endpoint
    await this.scanMarketplacePage('MARKETPLACE_MODELS', 'Models');
    await this.scanMarketplacePage('MARKETPLACE_MESHES', 'Meshes');
    await this.scanMarketplacePage('MARKETPLACE_MESHPARTS', 'MeshParts');
    await this.scanMarketplacePage('MARKETPLACE_ANIMATIONS', 'Animations');
    await this.scanMarketplacePage('MARKETPLACE_DECALS', 'Decals');
    await this.scanMarketplacePage('MARKETPLACE_AUDIO', 'Audio');
    await this.scanMarketplacePage('CREATOR_HUB_MODELS', 'Creator Hub Models');
  }
  
  /**
   * Use the AssetDeliveryScanner to scan an asset
   * This leverages our enhanced scanning capabilities including:
   * - Asset Delivery API
   * - Thumbnails API
   * - Open Cloud API (when credentials are available)
   * - Legacy endpoint fallbacks
   */
  private async scanAssetWithDeliveryScanner(assetId: string): Promise<void> {
    try {
      console.log(`Using AssetDeliveryScanner for asset ${assetId}...`);
      
      // Use the dedicated scanner with comprehensive fallback mechanisms
      const results = await assetDeliveryScanner.scanAssetDelivery(assetId);
      
      if (results && (results.thumbnailEndpoint || results.assetInfo || results.legacyEndpoint || results.openCloudData)) {
        this.results.push({
          endpointName: 'Asset Delivery Scanner',
          endpointUrl: `Multiple endpoints for asset ${assetId}`,
          success: true,
          message: 'Asset successfully scanned with comprehensive scanner',
          assetCount: 1
        });
        
        console.log(`✓ Successfully scanned asset ${assetId} with AssetDeliveryScanner`);
        
        // Since the scanner already saved the asset, we just need to track it
        this.totalAssets += 1;
      } else {
        this.results.push({
          endpointName: 'Asset Delivery Scanner',
          endpointUrl: `Multiple endpoints for asset ${assetId}`,
          success: false,
          message: 'No data found with comprehensive scanner'
        });
      }
    } catch (error: any) {
      this.results.push({
        endpointName: 'Asset Delivery Scanner',
        endpointUrl: `Multiple endpoints for asset ${assetId}`,
        success: false,
        error: error.message
      });
      console.error(`Error using AssetDeliveryScanner for asset ${assetId}:`, error.message);
    }
  }
  
  /**
   * Scan a specific marketplace page
   */
  /**
   * Scan group audit log
   */
  private async scanGroupAuditLog(): Promise<void> {
    console.log('Scanning group audit log...');
    
    const endpointName = 'GROUP_AUDIT_LOG';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_AUDIT_LOG.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group audit log`);
        
        // Create an asset with the group audit log
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Group Audit Log: BIG Games Pets`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            logEntries: response.data.logEntries || [],
            cursor: response.data.nextPageCursor
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found group audit log data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group audit log:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group policies
   */
  private async scanGroupPolicies(): Promise<void> {
    console.log('Scanning group policies...');
    
    const endpointName = 'GROUP_POLICIES';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_POLICIES;
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group policies`);
        
        // Create an asset with the group policies
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Group Policies: BIG Games Pets`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            policies: response.data.policies || []
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found group policies data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group policies:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan group settings
   */
  private async scanGroupSettings(): Promise<void> {
    console.log('Scanning group settings...');
    
    const endpointName = 'GROUP_SETTINGS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GROUP_SETTINGS.replace('{groupId}', CONFIRMED_GROUP_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched group settings`);
        
        // Create an asset with the group settings
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Group Settings: BIG Games Pets`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            groupId: CONFIRMED_GROUP_ID,
            settings: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found group settings data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching group settings:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game icon
   */
  private async scanGameIcon(): Promise<void> {
    console.log('Scanning game icon...');
    
    const endpointName = 'GAME_ICON';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_ICON.replace('{gameId}', PS99_GAME_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game icon data`);
        
        // Create an asset with the game icon data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Game Icon: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            gameId: PS99_GAME_ID,
            iconData: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game icon data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game icon:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan game thumbnails
   */
  private async scanGameLocalizedThumbnails(): Promise<void> {
    console.log('Scanning game localized thumbnails...');
    
    const endpointName = 'GAME_THUMBNAILS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.GAME_THUMBNAILS.replace('{gameId}', PS99_GAME_ID).replace('{languageCode}', 'en');
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched game localized thumbnails data`);
        
        // Create an asset with the game thumbnails data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Game Localized Thumbnails: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            gameId: PS99_GAME_ID,
            thumbnailsData: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found game localized thumbnails data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching game localized thumbnails:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan badge localization
   */
  private async scanBadgeLocalization(): Promise<void> {
    console.log('Scanning badge localization...');
    
    const endpointName = 'BADGE_LOCALIZATION';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.BADGE_LOCALIZATION.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched badge localization data`);
        
        // Create an asset with the badge localization data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Badge Localization: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            badgeLocalization: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found badge localization data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching badge localization:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan developer product localization
   */
  /**
   * Scan Team Create settings
   */
  private async scanTeamCreateSettings(): Promise<void> {
    console.log('Scanning team create settings...');
    
    const endpointName = 'TEAM_CREATE_SETTINGS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.TEAM_CREATE_SETTINGS.replace('{placeId}', PS99_GAME_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched team create settings data`);
        
        // Create an asset with the team create settings data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Team Create Settings: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            placeId: PS99_GAME_ID,
            teamCreateSettings: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found team create settings data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching team create settings:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Team Create members
   */
  private async scanTeamCreateMembers(): Promise<void> {
    console.log('Scanning team create members...');
    
    const endpointName = 'TEAM_CREATE_MEMBERS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.TEAM_CREATE_MEMBERS.replace('{placeId}', PS99_GAME_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched team create members data`);
        
        // Create an asset with the team create members data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Team Create Members: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            placeId: PS99_GAME_ID,
            teamCreateMembers: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found team create members data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching team create members:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Universe Management - Activation Status
   */
  private async scanUniverseActivation(): Promise<void> {
    console.log('Scanning universe activation status...');
    
    const endpointName = 'UNIVERSE_ACTIVATE';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.UNIVERSE_ACTIVATE.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched universe activation status data`);
        
        // Create an asset with the universe activation status data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Universe Activation Status: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            activationStatus: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found universe activation status data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching universe activation status:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Universe Management - Permissions
   */
  private async scanUniversePermissions(): Promise<void> {
    console.log('Scanning universe permissions...');
    
    const endpointName = 'UNIVERSE_PERMISSIONS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.UNIVERSE_PERMISSIONS.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched universe permissions data`);
        
        // Create an asset with the universe permissions data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Universe Permissions: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            permissions: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found universe permissions data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching universe permissions:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan User Following Status
   */
  private async scanUserFollowingStatus(): Promise<void> {
    console.log('Scanning user following status...');
    
    // Use a generic user ID for now (will be replaced with actual user in real implementation)
    const userIdPlaceholder = "1"; // ROBLOX system user
    
    const endpointName = 'USER_FOLLOWING_STATUS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.USER_FOLLOWING_STATUS
      .replace('{userId}', userIdPlaceholder)
      .replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched user following status data`);
        
        // Create an asset with the user following status data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `User Following Status: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            userId: userIdPlaceholder,
            universeId: PS99_UNIVERSE_ID,
            followingStatus: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found user following status data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching user following status:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  private async scanDeveloperProductLocalization(): Promise<void> {
    console.log('Scanning developer product localization...');
    
    const endpointName = 'DEVELOPER_PRODUCT_LOCALIZATION';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.DEVELOPER_PRODUCT_LOCALIZATION.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched developer product localization data`);
        
        // Create an asset with the developer product localization data
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Developer Product Localization: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            productLocalization: response.data || {}
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: `Found developer product localization data`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching developer product localization:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  private async scanMarketplacePage(endpointKey: string, typeName: string): Promise<void> {
    // Type safety check - cast to EndpointKey or undefined
    const endpoint = endpointKey as EndpointKey | undefined;
    if (!endpoint || !ACCESSIBLE_ENDPOINTS[endpoint]) {
      console.log(`Endpoint ${endpointKey} not found, skipping`);
      return;
    }
    
    const endpointUrl = ACCESSIBLE_ENDPOINTS[endpoint];
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html'
      });
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched ${typeName} marketplace page`);
        
        // Create an asset with the marketplace page HTML
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Marketplace Page: ${typeName}`,
          type: 'Other',
          size: `${response.data.length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'System',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'html',
            contentType: response.headers['content-type'],
            contentLength: response.headers['content-length'],
            snippet: response.data.substring(0, 500) + '...',
            category: typeName
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName: endpointKey,
          endpointUrl,
          success: true,
          message: `Retrieved ${typeName} marketplace page (${response.data.length} bytes)`,
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching ${typeName} marketplace page:`, error.message);
      
      this.results.push({
        endpointName: endpointKey,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }

  /**
   * Scan Experience Configuration (from Rodux)
   */
  private async scanExperienceConfiguration(): Promise<void> {
    console.log('Scanning experience configuration...');
    
    const endpointName = 'EXPERIENCE_CONFIGURATION';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.EXPERIENCE_CONFIGURATION.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS.DEFAULT);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched experience configuration`);
        
        // Create an asset with the experience configuration
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Experience Configuration: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            configuration: response.data
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: 'Retrieved experience configuration successfully',
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching experience configuration:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Experience Media (from Rodux)
   */
  private async scanExperienceMedia(): Promise<void> {
    console.log('Scanning experience media...');
    
    const endpointName = 'EXPERIENCE_MEDIA';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.EXPERIENCE_MEDIA.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS.DEFAULT);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched experience media`);
        
        // Create an asset with the experience media
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Experience Media: Pet Simulator 99`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            media: response.data
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: 'Retrieved experience media successfully',
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching experience media:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Experience Details (from Rodux)
   */
  private async scanExperienceDetails(): Promise<void> {
    console.log('Scanning experience details...');
    
    const endpointName = 'EXPERIENCE_DETAILS';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.EXPERIENCE_DETAILS.replace('{universeId}', PS99_UNIVERSE_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS.DEFAULT);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched experience details`);
        
        // Create an asset with the experience details
        const assetId = nanoid();
        // Generate a game thumbnail URL
        const gameThumbnailUrl = `https://tr.rbxcdn.com/asset-thumbnail/image?assetId=${PS99_GAME_ID}&width=420&height=420&format=png`;
        
        await storage.createAsset({
          id: assetId,
          name: `Pet Simulator 99 - Experience Details`,
          // Use a more appropriate type
          type: 'Game',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          // Add thumbnail for proper display
          thumbnail: gameThumbnailUrl,
          robloxAssetId: PS99_GAME_ID,
          metadata: {
            format: 'json',
            universeId: PS99_UNIVERSE_ID,
            details: response.data,
            thumbnailUrl: gameThumbnailUrl,
            robloxData: {
              assetType: 'Game',
              creatorType: 'Group', 
              creatorId: CONFIRMED_GROUP_ID,
              creatorName: 'BIG Games'
            }
          },
          sourceUrl: `https://www.roblox.com/games/${PS99_GAME_ID}/Pet-Simulator-99`
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: 'Retrieved experience details successfully',
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching experience details:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Place Configuration (from Rodux)
   */
  private async scanPlaceConfiguration(): Promise<void> {
    console.log('Scanning place configuration...');
    
    const endpointName = 'PLACE_CONFIGURATION';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.PLACE_CONFIGURATION.replace('{placeId}', PS99_GAME_ID);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS.DEFAULT);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched place configuration`);
        
        // Create an asset with the place configuration
        const assetId = nanoid();
        // Generate a game thumbnail URL
        const gameThumbnailUrl = `https://tr.rbxcdn.com/asset-thumbnail/image?assetId=${PS99_GAME_ID}&width=420&height=420&format=png`;
        
        await storage.createAsset({
          id: assetId,
          name: `Pet Simulator 99 - Place Configuration`,
          // Use a more appropriate type
          type: 'Game',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Pet Simulator 99',
          creator: 'BIG Games',
          detectedAt: 'Just now',
          status: 'New',
          // Add thumbnail for proper display
          thumbnail: gameThumbnailUrl,
          robloxAssetId: PS99_GAME_ID,
          metadata: {
            format: 'json',
            placeId: PS99_GAME_ID,
            configuration: response.data,
            thumbnailUrl: gameThumbnailUrl,
            robloxData: {
              assetType: 'Game',
              creatorType: 'Group', 
              creatorId: CONFIRMED_GROUP_ID,
              creatorName: 'BIG Games'
            }
          },
          sourceUrl: `https://www.roblox.com/games/${PS99_GAME_ID}/Pet-Simulator-99`
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: 'Retrieved place configuration successfully',
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching place configuration:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
  
  /**
   * Scan Avatar Assets (from Rodux)
   */
  private async scanAvatarAssets(): Promise<void> {
    console.log('Scanning avatar assets...');
    
    const endpointName = 'AVATAR_ASSETS';
    // User ID - using a placeholder user
    const userId = '31245370';
    const endpointUrl = ACCESSIBLE_ENDPOINTS.AVATAR_ASSETS.replace('{userId}', userId);
    
    try {
      // Make the request with rate limiting
      const response = await this.makeRequest(endpointUrl, HTTP_HEADERS.DEFAULT);
      
      // Process response
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully fetched avatar assets`);
        
        // Create an asset with the avatar assets
        const assetId = nanoid();
        await storage.createAsset({
          id: assetId,
          name: `Avatar Assets: User ${userId}`,
          type: 'Other',
          size: `${JSON.stringify(response.data).length} bytes`,
          game: 'Roblox Platform',
          creator: 'Roblox',
          detectedAt: 'Just now',
          status: 'New',
          metadata: {
            format: 'json',
            userId: userId,
            assets: response.data
          },
          sourceUrl: endpointUrl
        });
        
        this.totalAssets++;
        
        // Store result
        this.results.push({
          endpointName,
          endpointUrl,
          success: true,
          message: 'Retrieved avatar assets successfully',
          assetCount: 1
        });
      }
    } catch (error: any) {
      console.error(`Error fetching avatar assets:`, error.message);
      
      this.results.push({
        endpointName,
        endpointUrl,
        success: false,
        error: error.message
      });
    }
  }
}

export const workingScanner = new WorkingScanner();
export default workingScanner;