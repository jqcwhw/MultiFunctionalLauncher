# PS99 Scanner Enhanced Approach

This document outlines our enhanced approach to detecting and tracking potential PS99 asset leaks before they're officially announced. Our methodology follows strict guidelines to ensure we only collect data from verified sources.

## Core Principles

1. **Verified Sources Only**: We only track assets from verified BIG Games staff and official BIG Games groups. This ensures the assets we detect are legitimate and reduces false positives.

2. **Lenient Filtering for Verified Sources**: When assets come from verified BIG Games sources, we apply more lenient filtering criteria. This catches assets that don't explicitly mention PS99 but are likely related.

3. **Confidence-Based Classification**: Assets are classified based on confidence levels, with clear labeling of "PS99 Confirmed" vs. "PS99 Unconfirmed (from verified source)."

4. **Anti-Rate Limiting**: We implement exponential backoff and request queuing to avoid API restrictions from Roblox while gathering data.

5. **Comprehensive Staff Tracking**: We monitor all staff types, including developers, designers, testers, builders, and other official roles.

## Source Verification

### BIG Games Groups
We track assets from these official groups:

- BIG Games (ID: 2703304)
- BIG Games Pets (ID: 3959677)
- BIG Games Testing (ID: 14078260)
- BIG Games Super Fun (ID: 5060810)
- BIG Games Magic Forest (ID: 4981455)

### Staff Categories
We only monitor staff with these official roles:

- Owners
- Developers
- Designers
- Testers
- Builders
- Modelers
- Artists
- QA Testers

## Keyword System

Our keyword system uses weighted categories:

### Core PS99 Keywords (Highest Weight, +10 each)
- pet simulator 99
- ps99
- pet sim 99
- petsim99
- pet simulator99

### Event Keywords (High Weight, +5 each)
- egypt
- anubis
- pyramid
- pharaoh
- sphinx
- mummy
- tomb
- hieroglyph
- scarab
- ankh
- osiris
- desert
- oasis

### General PS99 Keywords (Medium Weight, +3 each)
- gems
- coins
- enchant
- hatch
- huge
- exclusive
- mythical
- legendary
- potions
- boost
- eggs
- hhc
- merchant

### Asset Type Keywords (Low Weight, +1 each)
- pet
- weapon
- hat
- accessory
- map
- world
- zone
- area
- music
- sound
- tool
- currency

### Exclusion Keywords (Automatic Rejection)
- pets go
- petgo
- pet go

## Data Collection Process

1. **Source Identification**:
   - Maintain an updated list of verified BIG Games staff and groups
   - Check credentials against official community pages
   - Store verified sources in a secure database

2. **Asset Monitoring**:
   - Scan verified sources' recent creations (past 7 days)
   - Apply keyword matching and confidence scoring
   - Store metadata including creator, creation date, and source verification

3. **Classification**:
   - Categorize assets based on confidence score
   - Label as "PS99 Confirmed" or "PS99 Unconfirmed"
   - Record matching keywords and confidence metrics

4. **Rate Limit Management**:
   - Implement exponential backoff for API requests
   - Use multiple access patterns to avoid detection
   - Queue requests with variable delays
   - Cache results to minimize duplicate requests

## Output Format

For each detected asset, we provide:

1. **Asset Basic Info**:
   - Name
   - ID
   - Description
   - Creation Date
   - Creator Name
   - Creator ID
   - Creator Type (User/Group)

2. **PS99 Relevance**:
   - Confidence Score
   - Classification (Confirmed/Unconfirmed)
   - Matched Keywords
   - Source Verification Status

3. **Visual Data**:
   - Thumbnail/Image (when available)
   - Related assets (when applicable)

## Implementation Details

The enhanced scanner is implemented in Python with these key components:

1. **Source Verification Module**: Validates that assets come from official BIG Games sources
2. **Keyword Matching Module**: Analyzes asset names and descriptions for relevant keywords
3. **Anti-Rate Limiting Module**: Manages API requests to avoid restrictions
4. **Asset Processing Module**: Extracts and processes asset metadata
5. **Image Retrieval Module**: Captures visual data for discovered assets
6. **Data Storage Module**: Securely stores discovered assets and their metadata

## Benefits Over Previous Approaches

1. **Reduced False Positives**: By focusing only on verified sources, we eliminate most false leads
2. **Higher Detection Rate**: More lenient filtering for verified sources catches assets that don't explicitly mention PS99
3. **Better Classification**: Clear confidence levels help understand the likelihood of assets being PS99-related
4. **More Robust API Handling**: Advanced anti-rate limiting prevents scanning interruptions
5. **Comprehensive Staff Coverage**: Monitoring all staff types catches assets from various creation stages