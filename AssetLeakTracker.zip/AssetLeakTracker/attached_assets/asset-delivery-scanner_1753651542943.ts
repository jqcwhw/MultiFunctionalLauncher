/**
 * Asset Delivery Scanner
 * 
 * This file implements a specialized scanner for asset delivery endpoints
 * that can retrieve actual asset content, particularly focusing on meshes, models,
 * textures, and other game content. It includes comprehensive fallback mechanisms
 * and uses all available metadata to build detailed asset profiles.
 */

import axios from 'axios';
import { nanoid } from 'nanoid';
import { storage } from '../storage';
import { ACCESSIBLE_ENDPOINTS, PROTECTED_ENDPOINTS, HTTP_HEADERS } from './endpoint-registry';
import { AssetType, Asset } from '@shared/schema';

// We want to track ALL asset types for PS99 (not filtering)
// This list is for reference but we won't filter assets by type anymore
const PS99_ASSET_TYPES = [
  'Model', 'Mesh', 'MeshPart', 'Animation', 'Decal', 'Texture', 'Audio',
  'Badge', 'Package', 'Plugin', 'Place', 'GamePass', 'DeveloperProduct',
  'Pet', 'Egg', 'Huge', 'Gargantuan', 'Titanic', 'Currency', 'Area', 'World', 'Instance',
  'Image', 'Script', 'UI Asset', 'Game'
];

export class AssetDeliveryScanner {
  private apiCallsCount: number = 0;
  private requestDelayMs: number = 2000; // 2 seconds between requests to avoid rate limiting
  private lastRequestTime: number = 0;
  private domainBackoff: Map<string, number> = new Map(); // Track backoff per domain

  constructor() {
    console.log('Asset Delivery Scanner initialized');
  }

  /**
   * Extract domain from a URL for domain-specific rate limiting
   */
  private extractDomain(url: string): string {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch (e) {
      return 'unknown';
    }
  }

  /**
   * Wait for rate limit before making a request
   * This helps avoid 429 Too Many Requests errors
   * Now with domain-specific backoff
   */
  private async waitForRateLimit(url: string): Promise<void> {
    this.apiCallsCount++;
    
    const now = Date.now();
    const elapsed = now - this.lastRequestTime;
    const domain = this.extractDomain(url);
    
    // Get domain-specific backoff if any
    const domainBackoff = this.domainBackoff.get(domain) || 0;
    const effectiveDelay = Math.max(this.requestDelayMs, domainBackoff);
    
    // If less time has passed than our delay, wait the remaining time
    if (elapsed < effectiveDelay) {
      const waitTime = effectiveDelay - elapsed;
      console.log(`Rate limiting: Waiting ${waitTime}ms for ${domain}`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    // Update the last request time
    this.lastRequestTime = Date.now();
  }

  /**
   * Update domain backoff based on response
   * If we get a 429, increase backoff exponentially
   * If successful, gradually reduce backoff
   */
  private updateDomainBackoff(url: string, statusCode: number): void {
    const domain = this.extractDomain(url);
    const currentBackoff = this.domainBackoff.get(domain) || 0;
    
    if (statusCode === 429) {
      // Too many requests - double backoff (exponential) with max cap of 30 seconds
      const newBackoff = Math.min(
        currentBackoff === 0 ? 2000 : currentBackoff * 2, 
        30000
      );
      console.log(`Rate limit exceeded for ${domain}. Increasing backoff to ${newBackoff}ms`);
      this.domainBackoff.set(domain, newBackoff);
    } else if (statusCode >= 200 && statusCode < 300) {
      // Success - gradually decrease backoff
      if (currentBackoff > 0) {
        const newBackoff = Math.max(0, currentBackoff - 500);
        this.domainBackoff.set(domain, newBackoff);
      }
    }
  }

  /**
   * Make a rate-limited API request with smart backoff and retry for 429s
   */
  private async makeRequest(url: string, headers: any, retryCount: number = 0, maxRetries: number = 3): Promise<any> {
    // Wait for rate limiting
    await this.waitForRateLimit(url);
    
    try {
      // Make the actual request
      const response = await axios.get(url, {
        headers,
        timeout: 15000, // 15 second timeout
        responseType: 'arraybuffer' // For binary content
      });
      
      // Update backoff for successful requests
      this.updateDomainBackoff(url, response.status);
      
      const contentType = response.headers['content-type'];
      if (contentType?.includes('application/json')) {
        // Convert binary to JSON if it's JSON data
        const decoder = new TextDecoder('utf-8');
        const jsonStr = decoder.decode(response.data);
        response.data = JSON.parse(jsonStr);
      }
      
      return response;
    } catch (error: any) {
      // If rate limited and we have retries left, retry with backoff
      if (error.response && error.response.status === 429 && retryCount < maxRetries) {
        // Update backoff for this domain
        this.updateDomainBackoff(url, 429);
        
        // Calculate retry delay with exponential backoff
        const retryDelay = Math.min(Math.pow(2, retryCount) * 2000, 30000);
        console.log(`Rate limited (429) for ${url}. Retry ${retryCount + 1}/${maxRetries} after ${retryDelay}ms backoff`);
        
        // Wait for backoff period
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        
        // Retry the request with incremented retry count
        return this.makeRequest(url, headers, retryCount + 1, maxRetries);
      }
      
      // If rate limited but out of retries, just update backoff for future requests
      if (error.response && error.response.status === 429) {
        this.updateDomainBackoff(url, 429);
      }
      
      throw error;
    }
  }

  /**
   * Scan asset delivery for a specific asset ID
   * Includes comprehensive fallback mechanisms
   */
  async scanAssetDelivery(assetId: string): Promise<any> {
    console.log(`Scanning asset delivery for asset ID ${assetId}...`);
    
    const results = {
      assetId,
      legacyEndpoint: null as any,
      newEndpoint: null as any,
      thumbnailEndpoint: null as any,
      assetInfo: null as any,
      openCloudData: null as any,
      saveResult: null as any
    };
    
    try {
      // First try to get thumbnail through the thumbnails API
      await this.getThumbnailData(assetId, results);
      
      // Next try to get asset info from the economy API
      await this.getAssetInfo(assetId, results);
      
      // Try legacy asset delivery endpoint
      await this.getLegacyAsset(assetId, results);
      
      // Try Open Cloud API if available
      const openCloudResult = await this.tryOpenCloudAssetApi(assetId);
      if (openCloudResult.success) {
        results.openCloudData = openCloudResult.data;
      }
      
      // If we have results, save the asset
      if (results.thumbnailEndpoint || results.assetInfo || results.legacyEndpoint || results.openCloudData) {
        await this.saveAssetData(assetId, results);
      }
      
      return results;
    } catch (error: any) {
      console.error(`Error in asset delivery scan for ${assetId}:`, error.message);
      return {
        assetId,
        error: error.message
      };
    }
  }


  /**
   * Get thumbnail data for an asset with multiple fallback options
   */
  private async getThumbnailData(assetId: string, results: any): Promise<void> {
    try {
      // Try the standard thumbnails API first
      const thumbnailUrl = ACCESSIBLE_ENDPOINTS.ASSET_THUMBNAIL.replace('{assetId}', assetId);
      let response = await this.makeRequest(thumbnailUrl, HTTP_HEADERS);
      
      if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
        const thumbnailData = response.data.data[0];
        results.thumbnailEndpoint = {
          success: true,
          imageUrl: thumbnailData.imageUrl,
          state: thumbnailData.state,
          width: thumbnailData.targetWidth || 420,
          height: thumbnailData.targetHeight || 420
        };
        console.log(`✓ Successfully fetched thumbnail data for asset ID ${assetId}`);
        return;
      }
      
      // Fallback 1: Try the catalog thumbnail API
      try {
        const catalogThumbnailUrl = `https://www.roblox.com/asset-thumbnail/json?assetId=${assetId}&width=420&height=420&format=png`;
        response = await this.makeRequest(catalogThumbnailUrl, HTTP_HEADERS);
        
        if (response.status === 200 && response.data && response.data.Final) {
          results.thumbnailEndpoint = {
            success: true,
            imageUrl: response.data.Final,
            state: 'Completed',
            width: 420,
            height: 420,
            source: 'catalog'
          };
          console.log(`✓ Successfully fetched catalog thumbnail for asset ID ${assetId}`);
          return;
        }
      } catch (err) {
        console.error(`Catalog thumbnail fallback failed for asset ${assetId}:`, err.message);
      }
      
      // Fallback 2: Try direct CDN URL
      try {
        const cdnUrl = `https://tr.rbxcdn.com/${assetId}/420/420/Image/Png`;
        // Just test if the URL is valid - we don't need to download the image
        response = await this.makeRequest(cdnUrl, HTTP_HEADERS, 0, 1); // Just 1 retry
        
        if (response.status === 200) {
          results.thumbnailEndpoint = {
            success: true,
            imageUrl: cdnUrl,
            state: 'Completed',
            width: 420,
            height: 420,
            source: 'cdn'
          };
          console.log(`✓ Successfully found CDN thumbnail for asset ID ${assetId}`);
          return;
        }
      } catch (err) {
        console.error(`CDN thumbnail fallback failed for asset ${assetId}:`, err.message);
      }
      
      // Fallback 3: Try Asset Delivery v2 API for 3D models
      try {
        const assetDeliveryUrl = `https://assetdelivery.roblox.com/v2/assetId/${assetId}`;
        response = await this.makeRequest(assetDeliveryUrl, HTTP_HEADERS);
        
        if (response.status === 200 && response.data && response.data.locations && response.data.locations.length > 0) {
          const location = response.data.locations[0];
          results.thumbnailEndpoint = {
            success: true,
            imageUrl: location.location, // Use the asset delivery location
            state: 'Completed',
            width: 420,
            height: 420,
            source: 'assetdelivery'
          };
          console.log(`✓ Successfully found Asset Delivery v2 data for asset ID ${assetId}`);
          return;
        }
      } catch (err) {
        console.error(`Asset Delivery v2 fallback failed for asset ${assetId}:`, err.message);
      }
      
      // If all attempts fail, set failure result
      results.thumbnailEndpoint = {
        success: false,
        error: "All thumbnail retrieval methods failed",
        attempts: ["thumbnails_api", "catalog_api", "cdn_direct", "asset_delivery_v2"]
      };
    } catch (error: any) {
      console.error(`Failed to get thumbnail for asset ${assetId} (all methods):`, error.message);
      results.thumbnailEndpoint = {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Get asset info from economy API
   */
  private async getAssetInfo(assetId: string, results: any): Promise<void> {
    try {
      const assetInfoUrl = ACCESSIBLE_ENDPOINTS.ASSET_INFO.replace('{assetId}', assetId);
      const response = await this.makeRequest(assetInfoUrl, HTTP_HEADERS);
      
      if (response.status === 200 && response.data) {
        results.assetInfo = {
          success: true,
          name: response.data.Name || response.data.name,
          description: response.data.Description || response.data.description,
          assetType: response.data.AssetTypeId || response.data.assetTypeId,
          creator: {
            id: response.data.Creator?.Id || response.data.creator?.id,
            name: response.data.Creator?.Name || response.data.creator?.name,
            type: response.data.Creator?.CreatorType || response.data.creator?.creatorType
          },
          created: response.data.Created || response.data.created,
          updated: response.data.Updated || response.data.updated,
          price: response.data.PriceInRobux || response.data.price,
          sales: response.data.Sales || response.data.sales
        };
        console.log(`✓ Successfully fetched asset info for asset ID ${assetId}`);
      }
    } catch (error: any) {
      console.error(`Failed to get asset info for asset ${assetId}:`, error.message);
      results.assetInfo = {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Try legacy asset delivery endpoint
   */
  private async getLegacyAsset(assetId: string, results: any): Promise<void> {
    try {
      const legacyUrl = PROTECTED_ENDPOINTS.ASSET_DELIVERY_LEGACY.replace('{assetId}', assetId);
      const response = await this.makeRequest(legacyUrl, HTTP_HEADERS);
      
      if (response.status === 200) {
        // For binary data, determine file type
        const contentType = response.headers['content-type'] || '';
        const isText = contentType.includes('text') || contentType.includes('json');
        const fileType = this.determineFileType(contentType, assetId);
        
        results.legacyEndpoint = {
          success: true,
          contentType,
          fileType,
          size: response.data.length,
          // Don't store the full data, just info about it
          hasData: true,
          isText
        };
        
        // If it's text, try to extract some info
        if (isText) {
          try {
            const decoder = new TextDecoder('utf-8');
            const textData = decoder.decode(response.data);
            results.legacyEndpoint.preview = textData.substring(0, 200) + '...';
          } catch (e) {
            // Ignore text extraction errors
          }
        }
        
        console.log(`✓ Successfully fetched legacy asset data for asset ID ${assetId}`);
      }
    } catch (error: any) {
      console.error(`Failed to get legacy asset data for asset ${assetId}:`, error.message);
      results.legacyEndpoint = {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Determine the file type based on content type and asset ID
   */
  private determineFileType(contentType: string, assetId: string): AssetType {
    if (contentType.includes('image')) {
      return 'Image';
    } else if (contentType.includes('audio')) {
      return 'Audio';
    } else if (contentType.includes('text/xml') || contentType.includes('application/xml')) {
      return '3D Model'; // Roblox models are XML
    } else if (contentType.includes('text/plain')) {
      return 'Script';
    } else if (contentType.includes('json')) {
      return 'Other';
    } else if (contentType.includes('mesh') || contentType.includes('binary')) {
      return 'Mesh';
    } else {
      return 'Other'; // Default type that matches our schema
    }
  }

  /**
   * Save asset data to storage
   */
  private async saveAssetData(assetId: string, results: any): Promise<void> {
    // TypeScript assertion to ensure assetType is always a valid AssetType
    const ensureValidAssetType = (type: string): AssetType => {
      const validTypes: AssetType[] = [
        '3D Model', 'Texture', 'Audio', 'Script', 'UI Asset', 
        'Decal', 'Mesh', 'Game', 'Place', 'Plugin', 
        'Animation', 'Badge', 'Gamepass', 'Package', 'MeshPart',
        'Pet', 'Egg', 'Currency', 'DeveloperProduct', 'Image',
        'Huge', 'Gargantuan', 'Titanic', 'Area', 'World', 'Instance', 'Other'
      ];
      return validTypes.includes(type as AssetType) ? (type as AssetType) : 'Other';
    };
    // Determine the best name for the asset
    const assetName = results.assetInfo?.name || `Asset ID: ${assetId}`;
    
    // Determine the best asset type
    let assetType: AssetType = 'Other';
    if (results.assetInfo?.assetType) {
      // Map Roblox asset type IDs to our asset types
      const typeMap: Record<number, AssetType> = {
        1: 'Texture',
        2: 'Texture',
        3: 'Audio',
        4: 'Mesh',
        5: 'Script',
        8: 'Badge',
        9: 'Animation',
        10: '3D Model',
        11: 'Script',
        13: 'Decal',
        34: 'Game',
        35: 'Package',
        38: 'Plugin',
        41: 'MeshPart',
        66: 'Place'
      };
      assetType = typeMap[results.assetInfo.assetType] || 'Other';
    } else if (results.legacyEndpoint?.fileType) {
      // Make sure the file type is a valid AssetType
      const validTypes: AssetType[] = [
        '3D Model', 'Texture', 'Audio', 'Script', 'UI Asset', 
        'Decal', 'Mesh', 'Game', 'Place', 'Plugin', 
        'Animation', 'Badge', 'Gamepass', 'Package', 'MeshPart',
        'Pet', 'Egg', 'Currency', 'DeveloperProduct', 'Image',
        'Huge', 'Gargantuan', 'Titanic', 'Area', 'World', 'Instance', 'Other'
      ];
      
      if (validTypes.includes(results.legacyEndpoint.fileType as AssetType)) {
        assetType = results.legacyEndpoint.fileType as AssetType;
      }
    }
    
    // Create a combined metadata object with all we know
    const metadata: any = {
      assetId,
      format: results.legacyEndpoint?.contentType || 'unknown',
      robloxData: {
        assetType: assetType,
        created: results.assetInfo?.created,
        updated: results.assetInfo?.updated
      }
    };
    
    // Add creator data if available
    if (results.assetInfo?.creator) {
      metadata.robloxData.creatorId = results.assetInfo.creator.id;
      metadata.robloxData.creatorName = results.assetInfo.creator.name;
      metadata.robloxData.creatorType = results.assetInfo.creator.type;
    }
    
    // Add thumbnail data if available
    if (results.thumbnailEndpoint?.imageUrl) {
      metadata.thumbnailUrl = results.thumbnailEndpoint.imageUrl;
    }
    
    // Calculate asset size
    const size = results.legacyEndpoint?.size || 0;
    const sizeStr = size > 1024 ? `${Math.round(size / 1024)} KB` : `${size} bytes`;
    
    // Create the asset
    try {
      // Check if an asset with this robloxAssetId already exists
      const existingAssets = await storage.getAssetsByRobloxId(assetId);
      let assetToReturn;
      
      if (existingAssets && existingAssets.length > 0) {
        console.log(`Found ${existingAssets.length} existing assets for Roblox asset ID ${assetId}`);
        
        // Update the most recent one with any new information
        const mostRecentAsset = existingAssets[0]; // Assets are ordered by createdAt desc
        
        // Only update if we have new data that's better than what we already have
        const needsUpdate = (
          // If we now have a thumbnail but didn't before
          (!mostRecentAsset.thumbnail && results.thumbnailEndpoint?.imageUrl) ||
          // If we now have creator info but didn't before
          (mostRecentAsset.creator === 'Unknown' && results.assetInfo?.creator?.name) ||
          // If we now have more complete metadata
          (!mostRecentAsset.metadata?.robloxData?.created && results.assetInfo?.created)
        );
        
        if (needsUpdate) {
          // Create an update with the new info, preserving existing data
          const update = {
            ...mostRecentAsset,
            // Only update thumbnail if we have a new one and the existing one is empty
            thumbnail: !mostRecentAsset.thumbnail && results.thumbnailEndpoint?.imageUrl 
              ? results.thumbnailEndpoint.imageUrl 
              : mostRecentAsset.thumbnail,
            // Only update creator if current one is 'Unknown'
            creator: mostRecentAsset.creator === 'Unknown' && results.assetInfo?.creator?.name
              ? results.assetInfo.creator.name
              : mostRecentAsset.creator,
            // Always update the metadata to be more complete
            metadata: {
              ...(mostRecentAsset.metadata || {}),
              format: results.legacyEndpoint?.contentType || (mostRecentAsset.metadata?.format) || 'unknown',
              robloxData: {
                ...(mostRecentAsset.metadata?.robloxData || {}),
                assetType: assetType,
                created: results.assetInfo?.created || (mostRecentAsset.metadata?.robloxData?.created),
                updated: results.assetInfo?.updated || (mostRecentAsset.metadata?.robloxData?.updated),
                creatorId: results.assetInfo?.creator?.id || (mostRecentAsset.metadata?.robloxData?.creatorId),
                creatorName: results.assetInfo?.creator?.name || (mostRecentAsset.metadata?.robloxData?.creatorName),
                creatorType: results.assetInfo?.creator?.type || (mostRecentAsset.metadata?.robloxData?.creatorType)
              }
            }
          };
          
          // Update the asset
          const updatedAsset = await storage.updateAsset(mostRecentAsset.id, update);
          console.log(`✓ Updated existing asset ${mostRecentAsset.id} with new data for asset ID ${assetId}`);
          
          assetToReturn = updatedAsset;
          results.saveResult = {
            success: true,
            id: mostRecentAsset.id,
            updated: true
          };
        } else {
          console.log(`✓ Existing asset ${mostRecentAsset.id} already has complete data for asset ID ${assetId}`);
          assetToReturn = mostRecentAsset;
          results.saveResult = {
            success: true,
            id: mostRecentAsset.id,
            unchanged: true
          };
        }
      } else {
        // Create a new asset since none exists
        const newAssetId = nanoid();
        const newAsset = await storage.createAsset({
          id: newAssetId,
          name: assetName,
          thumbnail: results.thumbnailEndpoint?.imageUrl,
          type: assetType,
          size: sizeStr,
          game: 'Pet Simulator 99',
          creator: results.assetInfo?.creator?.name || 'Unknown',
          detectedAt: 'Just now',
          status: 'New',
          metadata,
          robloxAssetId: assetId,
          sourceUrl: `https://www.roblox.com/catalog/${assetId}/`
        });
        
        console.log(`✓ Successfully saved asset data for asset ID ${assetId}`);
        assetToReturn = newAsset;
        results.saveResult = {
          success: true,
          id: newAssetId,
          created: true
        };
        
        // Also create activity for this discovery
        await storage.createActivity({
          id: nanoid(),
          type: 'new',
          description: `Discovered new asset: ${assetName}`,
          creator: 'Asset Delivery Scanner',
          timestamp: 'Just now'
        });
      }
    } catch (error: any) {
      console.error(`Failed to save asset data for asset ${assetId}:`, error.message);
      results.saveResult = {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Attempt to retrieve asset data using Open Cloud API
   * This requires API key authentication
   */
  async tryOpenCloudAssetApi(assetId: string): Promise<any> {
    try {
      // Check if we have API key configured
      const apiKey = process.env.ROBLOX_API_KEY;
      if (!apiKey) {
        return {
          success: false,
          error: 'No Roblox API key configured'
        };
      }
      
      const openCloudUrl = PROTECTED_ENDPOINTS.OPEN_CLOUD_GET.replace('{assetId}', assetId);
      
      // Make the request with API key authentication
      const response = await axios.get(openCloudUrl, {
        headers: {
          'x-api-key': apiKey,
          'Accept': 'application/json'
        },
        timeout: 15000 // 15 second timeout
      });
      
      if (response.status === 200 && response.data) {
        console.log(`✓ Successfully retrieved asset data from Open Cloud API for asset ID ${assetId}`);
        return {
          success: true,
          data: response.data
        };
      }
      
      return {
        success: false,
        error: 'No data returned from Open Cloud API'
      };
    } catch (error: any) {
      console.error(`Failed to get asset from Open Cloud API for asset ${assetId}:`, error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * Batch scan multiple asset IDs
   */
  async batchScanAssets(assetIds: string[]): Promise<any[]> {
    console.log(`Starting batch scan of ${assetIds.length} assets...`);
    
    const results = [];
    const batchSize = 5;
    
    // Process them in batches to avoid overwhelming the API
    for (let i = 0; i < assetIds.length; i += batchSize) {
      const batch = assetIds.slice(i, i + batchSize);
      console.log(`Processing batch ${Math.floor(i/batchSize) + 1}/${Math.ceil(assetIds.length/batchSize)} of asset IDs...`);
      
      // Process each asset in the batch
      const batchPromises = batch.map(assetId => this.scanAssetDelivery(assetId));
      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults);
      
      // Add a small pause between batches to avoid rate limiting
      if (i + batchSize < assetIds.length) {
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }
    
    console.log(`Batch scan completed. Processed ${results.length} assets.`);
    return results;
  }
}

// Create singleton instance
export const assetDeliveryScanner = new AssetDeliveryScanner();