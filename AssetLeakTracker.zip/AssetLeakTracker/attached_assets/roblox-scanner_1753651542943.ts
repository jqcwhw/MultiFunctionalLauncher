import axios from 'axios';
import { nanoid } from 'nanoid';
import { storage } from '../storage';
import {
  ACCESSIBLE_ENDPOINTS,
  PROTECTED_ENDPOINTS,
  ROBLOX_IDS,
  ASSET_TYPES,
  PS99_CATEGORIES,
  SEARCH_KEYWORDS
} from './endpoint-registry';

interface ScanResult {
  source: string;
  items: ScanItem[];
  success: boolean;
  message?: string;
  timestamp: Date;
}

interface ScanItem {
  id: string;
  name: string;
  type: string;
  source: string;
  url: string;
  thumbnailUrl?: string;
  creatorId: string;
  creatorType: 'User' | 'Group';
  creatorName: string;
  description?: string;
  created?: Date;
  updated?: Date;
  price?: number;
  isLimited?: boolean;
  metadata?: any;
}

/**
 * RobloxScanner class
 * Handles scanning of all Roblox endpoints to find Pet Simulator 99 assets
 */
export class RobloxScanner {
  private storageInterface;
  private scanResults: ScanResult[] = [];
  private inProgress: boolean = false;
  private lastScanTime: Date | null = null;
  
  // Default request config for API calls
  private defaultRequestConfig = {
    headers: {
      'User-Agent': 'RobloxAssetTracker/1.0',
      'Accept': 'application/json,text/html',
    },
    timeout: 10000
  };
  
  constructor(storageInterface: any) {
    this.storageInterface = storageInterface;
    console.log('RobloxScanner initialized with comprehensive endpoint registry');
  }
  
  /**
   * Get scanner status
   */
  getStatus(): any {
    return {
      inProgress: this.inProgress,
      lastScanTime: this.lastScanTime,
      resultsCount: this.scanResults.reduce((total, result) => total + result.items.length, 0),
      sources: this.scanResults.map(result => ({
        source: result.source,
        count: result.items.length,
        success: result.success,
        message: result.message
      }))
    };
  }
  
  /**
   * Run a full scan of all accessible endpoints
   * Note: Protected endpoints will be skipped until authentication/bypass code is provided
   */
  async runFullScan(includeProtected: boolean = false): Promise<ScanResult[]> {
    if (this.inProgress) {
      return [{ 
        source: 'Scanner',
        items: [],
        success: false,
        message: 'Scan already in progress',
        timestamp: new Date()
      }];
    }
    
    try {
      console.log('Starting full scan...');
      this.inProgress = true;
      this.scanResults = [];
      
      // Scan creator assets
      await this.scanCreatorAssets();
      
      // Scan store locations
      await this.scanStoreLocations();
      
      // Scan external blogs
      await this.scanBlogs();
      
      // Scan confirmed IDs only
      
      // Scan the only confirmed group - Big Games Pets Group
      const confirmedGroupId = ROBLOX_IDS.groups.bigGamesMain;
      if (confirmedGroupId) {
        console.log(`Scanning confirmed Big Games Pets Group ID: ${confirmedGroupId}`);
        await this.scanGroup(confirmedGroupId);
      }
      
      // Update last scan time
      this.lastScanTime = new Date();
      this.inProgress = false;
      
      console.log(`Full scan completed. Found ${this.scanResults.reduce((total, result) => total + result.items.length, 0)} items.`);
      return this.scanResults;
      
    } catch (error) {
      console.error('Error in full scan:', error);
      this.inProgress = false;
      
      return [{
        source: 'Error',
        items: [],
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error in full scan',
        timestamp: new Date()
      }];
    }
  }
  
  /**
   * Scan creator assets - the marketplace for asset types
   */
  private async scanCreatorAssets(): Promise<void> {
    const results: ScanItem[] = [];
    console.log('Scanning creator assets...');
    
    for (const assetUrl of ACCESSIBLE_ENDPOINTS.creatorAssets) {
      try {
        console.log(`Scanning creator asset URL: ${assetUrl}`);
        
        const response = await axios.get(assetUrl, this.defaultRequestConfig);
        
        if (response.status === 200) {
          // Process HTML response to extract assets
          const html = response.data;
          
          // Simple check to see if the page contains PS99 content
          const hasPetSimContent = 
            typeof html === 'string' && 
            (html.toLowerCase().includes('pet simulator') || 
             html.toLowerCase().includes('ps99'));
          
          // If we found PS99 content, log it as an asset
          if (hasPetSimContent) {
            console.log(`Found Pet Simulator 99 content at ${assetUrl}`);
            
            // Create an asset item for the page itself
            const item: ScanItem = {
              id: nanoid(),
              name: `PS99 Assets - ${new URL(assetUrl).pathname.split('/').pop() || 'Unknown'}`,
              type: 'Creator Assets Page',
              source: assetUrl,
              url: assetUrl,
              creatorId: 'system',
              creatorType: 'User',
              creatorName: 'Asset Tracker',
              description: `Pet Simulator 99 content found at ${assetUrl}`,
              created: new Date(),
              metadata: {
                pageType: 'creator_assets',
                contentFound: true,
                timestamp: new Date().toISOString()
              }
            };
            
            results.push(item);
            
            // Store the asset
            await this.storageInterface.createAsset({
              id: item.id,
              name: item.name,
              assetType: item.type,
              source: item.source,
              sourceUrl: item.url,
              creatorId: item.creatorId,
              thumbnailUrl: item.thumbnailUrl || '',
              metadata: JSON.stringify(item.metadata || {})
            });
          }
        }
      } catch (error) {
        console.error(`Error scanning creator asset URL ${assetUrl}:`, error);
      }
    }
    
    // Add to scan results
    this.scanResults.push({
      source: 'Creator Assets',
      items: results,
      success: true,
      timestamp: new Date()
    });
  }
  
  /**
   * Scan store locations with keywords
   */
  private async scanStoreLocations(): Promise<void> {
    const results: ScanItem[] = [];
    console.log('Scanning store locations...');
    
    for (const storeUrl of ACCESSIBLE_ENDPOINTS.storeSearch) {
      try {
        console.log(`Scanning store URL: ${storeUrl}`);
        
        const response = await axios.get(storeUrl, this.defaultRequestConfig);
        
        if (response.status === 200) {
          const html = response.data;
          
          // Check for asset cards in the HTML
          let assetCards = [];
          if (typeof html === 'string') {
            // Extract asset cards using regex
            const assetCardMatches = html.match(/<div[^>]*class="asset-card"[^>]*>([\s\S]*?)<\/div>/g);
            if (assetCardMatches && assetCardMatches.length > 0) {
              assetCards = assetCardMatches;
            }
          }
          
          console.log(`Found ${assetCards.length} asset cards at ${storeUrl}`);
          
          // If we found asset cards, log it
          if (assetCards.length > 0) {
            const item: ScanItem = {
              id: nanoid(),
              name: `Store Assets - ${new URL(storeUrl).searchParams.get('keyword') || 'Unknown'}`,
              type: 'Store Search Results',
              source: storeUrl,
              url: storeUrl,
              creatorId: 'system',
              creatorType: 'User',
              creatorName: 'Asset Tracker',
              description: `Found ${assetCards.length} assets at ${storeUrl}`,
              created: new Date(),
              metadata: {
                pageType: 'store_search',
                assetCount: assetCards.length,
                keyword: new URL(storeUrl).searchParams.get('keyword'),
                timestamp: new Date().toISOString()
              }
            };
            
            results.push(item);
            
            // Store the asset
            await this.storageInterface.createAsset({
              id: item.id,
              name: item.name,
              assetType: item.type,
              source: item.source,
              sourceUrl: item.url,
              creatorId: item.creatorId,
              thumbnailUrl: item.thumbnailUrl || '',
              metadata: JSON.stringify(item.metadata || {})
            });
          }
        }
      } catch (error) {
        console.error(`Error scanning store URL ${storeUrl}:`, error);
      }
    }
    
    // Add to scan results
    this.scanResults.push({
      source: 'Store Locations',
      items: results,
      success: true,
      timestamp: new Date()
    });
  }
  
  /**
   * Scan external blogs for PS99 content
   */
  private async scanBlogs(): Promise<void> {
    const results: ScanItem[] = [];
    console.log('Scanning blogs...');
    
    for (const blog of ACCESSIBLE_ENDPOINTS.blogs) {
      try {
        console.log(`Scanning blog: ${blog}`);
        
        const response = await axios.get(blog, {
          ...this.defaultRequestConfig,
          headers: {
            ...this.defaultRequestConfig.headers,
            'Accept': 'text/html,application/json'
          }
        });
        
        if (response.status === 200) {
          const html = response.data;
          
          // Calculate hash of content to check for changes later
          const contentHash = Buffer.from(typeof html === 'string' ? html : JSON.stringify(html))
            .toString('base64')
            .substring(0, 100); // Just keep the first 100 chars of hash
          
          // Get previous hash from database if it exists
          const previousHash = await this.storageInterface.getSetting(`blog_hash_${blog}`);
          
          // If content has changed or we haven't seen this blog before
          if (!previousHash || previousHash.value !== contentHash) {
            await this.storageInterface.updateSetting(`blog_hash_${blog}`, contentHash);
            
            console.log(`Found new or changed content at ${blog}`);
            
            // Create an asset for the blog
            const item: ScanItem = {
              id: nanoid(),
              name: `Blog Update - ${new URL(blog).hostname}`,
              type: 'Blog Post',
              source: blog,
              url: blog,
              creatorId: 'system',
              creatorType: 'User',
              creatorName: 'Asset Tracker',
              created: new Date(),
              metadata: {
                contentHash,
                contentSize: typeof html === 'string' ? html.length : JSON.stringify(html).length,
                timestamp: new Date().toISOString()
              }
            };
            
            results.push(item);
            
            // Store the asset
            await this.storageInterface.createAsset({
              id: item.id,
              name: item.name,
              assetType: item.type,
              source: item.source,
              sourceUrl: item.url,
              creatorId: item.creatorId,
              thumbnailUrl: item.thumbnailUrl || '',
              metadata: JSON.stringify(item.metadata || {})
            });
            
            // Look for API endpoints in the HTML
            if (typeof html === 'string') {
              const apiMatches = html.match(/https?:\/\/[^"\s>)}']+\/api\/[^"\s>)}']*/g) || [];
              if (apiMatches && apiMatches.length > 0) {
                console.log(`Found ${apiMatches.length} potential API endpoints in ${blog}`);
                
                // Log each API endpoint found
                for (const apiUrl of apiMatches) {
                  // Create an asset for each API endpoint
                  const apiItem: ScanItem = {
                    id: nanoid(),
                    name: `API Endpoint - ${new URL(apiUrl).pathname}`,
                    type: 'API Endpoint',
                    source: blog,
                    url: apiUrl,
                    creatorId: 'system',
                    creatorType: 'User',
                    creatorName: 'Asset Tracker',
                    created: new Date(),
                    metadata: {
                      parentBlog: blog,
                      apiPath: new URL(apiUrl).pathname,
                      timestamp: new Date().toISOString()
                    }
                  };
                  
                  results.push(apiItem);
                  
                  // Store the API endpoint asset
                  await this.storageInterface.createAsset({
                    id: apiItem.id,
                    name: apiItem.name,
                    assetType: apiItem.type,
                    source: apiItem.source,
                    sourceUrl: apiItem.url,
                    creatorId: apiItem.creatorId,
                    thumbnailUrl: apiItem.thumbnailUrl || '',
                    metadata: JSON.stringify(apiItem.metadata || {})
                  });
                }
              }
            }
          }
        }
      } catch (error) {
        console.error(`Error scanning blog ${blog}:`, error);
      }
    }
    
    // Add to scan results
    this.scanResults.push({
      source: 'Blogs',
      items: results,
      success: true,
      timestamp: new Date()
    });
  }
  
  /**
   * Scan a Roblox user for assets
   */
  private async scanUser(userId: string): Promise<void> {
    const results: ScanItem[] = [];
    console.log(`Scanning user: ${userId}`);
    
    // Get user info first
    try {
      const userInfoUrl = `${ACCESSIBLE_ENDPOINTS.apiEndpoints.users.base}/${userId}`;
      const userResponse = await axios.get(userInfoUrl, this.defaultRequestConfig);
      
      if (userResponse.status === 200 && userResponse.data) {
        const userData = userResponse.data;
        const developerName = userData.name || 'Unknown Developer';
        
        console.log(`Scanning user: ${developerName} (${userId})`);
        
        // Attempt to get user's economy API information
        try {
          // Attempt to get user's catalog items via public endpoint
          const assetsUrl = `${ACCESSIBLE_ENDPOINTS.apiEndpoints.catalog.base}`;
          const requestBody = {
            Category: 1,
            CreatorTargetId: userId,
            CreatorType: 'User',
            Limit: 50,
            SortType: 'Relevance'
          };
          
          const assetsResponse = await axios.post(assetsUrl, requestBody, this.defaultRequestConfig);
          
          if (assetsResponse.status === 200 && assetsResponse.data && assetsResponse.data.data) {
            const assets = assetsResponse.data.data;
            
            console.log(`Found ${assets.length} assets for user ${developerName}`);
            
            for (const asset of assets) {
              const isRelevant = this.isPetSimulatorRelated(asset);
              
              // Currently including all assets regardless of relevance as requested
              const item: ScanItem = {
                id: asset.id.toString(),
                name: asset.name || `Asset ${asset.id}`,
                type: asset.assetType || 'Unknown Type',
                source: `User: ${developerName}`,
                url: `https://www.roblox.com/catalog/${asset.id}`,
                thumbnailUrl: asset.thumbnailUrl,
                creatorId: userId,
                creatorType: 'User',
                creatorName: developerName,
                description: asset.description,
                created: asset.created ? new Date(asset.created) : undefined,
                updated: asset.updated ? new Date(asset.updated) : undefined,
                price: asset.price,
                isLimited: asset.isLimited || asset.isLimitedUnique,
                metadata: {
                  assetType: asset.assetType,
                  relevanceScore: isRelevant ? 100 : 25,  // We assign a score but don't filter
                  source: 'user_assets'
                }
              };
              
              results.push(item);
              
              // Store the asset
              await this.storageInterface.createAsset({
                id: item.id,
                name: item.name,
                assetType: item.type,
                source: item.source,
                sourceUrl: item.url,
                creatorId: item.creatorId,
                thumbnailUrl: item.thumbnailUrl || '',
                metadata: JSON.stringify(item.metadata || {})
              });
            }
          }
        } catch (error) {
          console.error(`Error scanning user ${userId} assets:`, error);
        }
      }
    } catch (error) {
      console.error(`Error fetching user info for ${userId}:`, error);
    }
    
    // Add to scan results
    this.scanResults.push({
      source: `User: ${userId}`,
      items: results,
      success: true,
      timestamp: new Date()
    });
  }
  
  /**
   * Scan a Roblox group for assets
   */
  private async scanGroup(groupId: string): Promise<void> {
    const results: ScanItem[] = [];
    console.log(`Scanning group: ${groupId}`);
    
    // Get group info first
    try {
      const groupInfoUrl = `${ACCESSIBLE_ENDPOINTS.apiEndpoints.groups.base}/${groupId}`;
      const groupResponse = await axios.get(groupInfoUrl, this.defaultRequestConfig);
      
      if (groupResponse.status === 200 && groupResponse.data) {
        const groupData = groupResponse.data;
        const groupName = groupData.name || 'Unknown Group';
        
        console.log(`Scanning group: ${groupName} (${groupId})`);
        
        // Attempt to get group's catalog items via public endpoint
        try {
          const assetsUrl = `${ACCESSIBLE_ENDPOINTS.apiEndpoints.catalog.base}`;
          const requestBody = {
            Category: 1,
            CreatorTargetId: groupId,
            CreatorType: 'Group',
            Limit: 50,
            SortType: 'Relevance'
          };
          
          const assetsResponse = await axios.post(assetsUrl, requestBody, this.defaultRequestConfig);
          
          if (assetsResponse.status === 200 && assetsResponse.data && assetsResponse.data.data) {
            const assets = assetsResponse.data.data;
            
            console.log(`Found ${assets.length} assets for group ${groupName}`);
            
            for (const asset of assets) {
              const isRelevant = this.isPetSimulatorRelated(asset);
              
              // Currently including all assets regardless of relevance as requested
              const item: ScanItem = {
                id: asset.id.toString(),
                name: asset.name || `Asset ${asset.id}`,
                type: asset.assetType || 'Unknown Type',
                source: `Group: ${groupName}`,
                url: `https://www.roblox.com/catalog/${asset.id}`,
                thumbnailUrl: asset.thumbnailUrl,
                creatorId: groupId,
                creatorType: 'Group',
                creatorName: groupName,
                description: asset.description,
                created: asset.created ? new Date(asset.created) : undefined,
                updated: asset.updated ? new Date(asset.updated) : undefined,
                price: asset.price,
                isLimited: asset.isLimited || asset.isLimitedUnique,
                metadata: {
                  assetType: asset.assetType,
                  relevanceScore: isRelevant ? 100 : 25, // We assign a score but don't filter
                  source: 'group_assets'
                }
              };
              
              results.push(item);
              
              // Store the asset
              await this.storageInterface.createAsset({
                id: item.id,
                name: item.name,
                assetType: item.type,
                source: item.source,
                sourceUrl: item.url,
                creatorId: item.creatorId,
                thumbnailUrl: item.thumbnailUrl || '',
                metadata: JSON.stringify(item.metadata || {})
              });
            }
          }
        } catch (error) {
          console.error(`Error scanning group ${groupId} assets:`, error);
        }
      }
    } catch (error) {
      console.error(`Error fetching group info for ${groupId}:`, error);
    }
    
    // Add to scan results
    this.scanResults.push({
      source: `Group: ${groupId}`,
      items: results,
      success: true,
      timestamp: new Date()
    });
  }
  
  /**
   * Scan a Roblox game for assets
   */
  private async scanGame(gameId: string): Promise<void> {
    const results: ScanItem[] = [];
    console.log(`Scanning game: ${gameId}`);
    
    // Get game info first
    try {
      const gameInfoUrl = `${ACCESSIBLE_ENDPOINTS.apiEndpoints.games.base}?universeIds=${gameId}`;
      const gameResponse = await axios.get(gameInfoUrl, this.defaultRequestConfig);
      
      if (gameResponse.status === 200 && gameResponse.data && gameResponse.data.data && gameResponse.data.data.length > 0) {
        const gameData = gameResponse.data.data[0];
        const gameName = gameData.name || 'Unknown Game';
        
        console.log(`Scanning game: ${gameName} (${gameId})`);
        
        // Add the game itself as an asset
        const gameAsset: ScanItem = {
          id: gameId,
          name: gameName,
          type: 'Game',
          source: 'Roblox Games',
          url: `https://www.roblox.com/games/${gameId}`,
          thumbnailUrl: gameData.thumbnailUrl,
          creatorId: gameData.creator.id.toString(),
          creatorType: gameData.creator.type as 'User' | 'Group',
          creatorName: gameData.creator.name,
          description: gameData.description,
          created: gameData.created ? new Date(gameData.created) : undefined,
          updated: gameData.updated ? new Date(gameData.updated) : undefined,
          metadata: {
            placeId: gameData.rootPlaceId,
            universeId: gameData.id,
            playing: gameData.playing,
            visits: gameData.visits,
            source: 'game_data'
          }
        };
        
        results.push(gameAsset);
        
        // Store the game asset
        await this.storageInterface.createAsset({
          id: gameAsset.id,
          name: gameAsset.name,
          assetType: gameAsset.type,
          source: gameAsset.source,
          sourceUrl: gameAsset.url,
          creatorId: gameAsset.creatorId,
          thumbnailUrl: gameAsset.thumbnailUrl || '',
          metadata: JSON.stringify(gameAsset.metadata || {})
        });
        
        // Game passes require a different endpoint, most require auth
        // Will be implemented when bypass code is provided
      }
    } catch (error) {
      console.error(`Error fetching game info for ${gameId}:`, error);
    }
    
    // Add to scan results
    this.scanResults.push({
      source: `Game: ${gameId}`,
      items: results,
      success: true,
      timestamp: new Date()
    });
  }
  
  /**
   * This function used to check if an item is related to Pet Simulator 99,
   * but now it always returns true as we want to collect ALL assets without any filtering
   */
  private isPetSimulatorRelated(item: any): boolean {
    // Per user request: No filtering at all - return true for ALL assets
    return true;
  }
}

// Export the scanner instance
export const robloxScanner = new RobloxScanner(storage);