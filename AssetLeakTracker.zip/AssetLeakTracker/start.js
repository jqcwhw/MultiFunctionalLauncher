const { spawn } = require('child_process');

console.log('🚀 Starting PS99 Asset Tracker with comprehensive scanning...');

// Environment setup
process.env.NODE_ENV = 'development';

// Start the development server
const server = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  shell: true,
  env: {
    ...process.env,
    NODE_ENV: 'development'
  }
});

server.on('error', (error) => {
  console.error('❌ Failed to start server:', error);
  process.exit(1);
});

server.on('close', (code) => {
  console.log(`Server process exited with code ${code}`);
  process.exit(code);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down PS99 Asset Tracker...');
  server.kill('SIGINT');
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down PS99 Asset Tracker...');
  server.kill('SIGTERM');
});