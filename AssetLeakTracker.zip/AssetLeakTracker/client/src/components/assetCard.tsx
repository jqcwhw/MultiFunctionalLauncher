import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface Asset {
  id: string;
  assetId: string;
  name: string;
  creator: string;
  category: string;
  sourceGroup?: string;
  thumbnailUrl?: string;
  isVerified: boolean;
  isExclusive: boolean;
  discoveredAt: string;
}

interface AssetCardProps {
  asset: Asset;
  discoveryType: string;
  onClick: () => void;
}

export default function AssetCard({ asset, discoveryType, onClick }: AssetCardProps) {
  const getDiscoveryBadge = () => {
    switch (discoveryType) {
      case 'new':
        return <Badge className="bg-success text-white">NEW</Badge>;
      case 'updated':
        return <Badge className="bg-warning text-black">UPDATED</Badge>;
      case 'verified':
        return <Badge className="bg-discord-blue text-white">VERIFIED</Badge>;
      default:
        return null;
    }
  };

  const getCategoryBadge = () => {
    if (asset.isExclusive) {
      return <Badge className="bg-error text-white">EXCLUSIVE</Badge>;
    }
    if (asset.category === 'Pet') {
      return <Badge className="bg-discord-blue text-white">PET</Badge>;
    }
    if (asset.category === 'Egg') {
      return <Badge className="bg-warning text-black">EGG</Badge>;
    }
    return <Badge variant="secondary">{asset.category}</Badge>;
  };

  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const discovered = new Date(dateString);
    const diffInSeconds = Math.floor((now.getTime() - discovered.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  return (
    <Card 
      className={cn(
        "p-4 bg-discord-dark border-gray-700 hover:border-discord-blue transition-colors cursor-pointer",
        "flex items-center space-x-4"
      )}
      onClick={onClick}
    >
      <div className="w-16 h-16 bg-gray-600 rounded-lg overflow-hidden flex-shrink-0">
        {asset.thumbnailUrl ? (
          <img 
            src={asset.thumbnailUrl} 
            alt={asset.name}
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = `https://images.unsplash.com/photo-1591154669695-5f2a8d20c089?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64`;
            }}
          />
        ) : (
          <div className="w-full h-full bg-gray-600 flex items-center justify-center text-gray-400 text-xs">
            No Image
          </div>
        )}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-2 mb-1">
          <h4 className="font-medium truncate">{asset.name}</h4>
          {getDiscoveryBadge()}
          {getCategoryBadge()}
        </div>
        <p className="text-sm text-discord-muted">by {asset.creator}</p>
        <p className="text-xs text-discord-muted font-mono">ID: {asset.assetId}</p>
      </div>
      
      <div className="text-right flex-shrink-0">
        <p className="text-sm text-discord-muted">{getTimeAgo(asset.discoveredAt)}</p>
        <p className="text-xs text-discord-muted">{asset.sourceGroup}</p>
      </div>
    </Card>
  );
}
