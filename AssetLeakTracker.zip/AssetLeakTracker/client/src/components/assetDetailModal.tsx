import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Download, Check, Clock, AlertCircle } from "lucide-react";

interface Asset {
  id: string;
  assetId: string;
  name: string;
  creator: string;
  creatorId?: string;
  description?: string;
  category: string;
  sourceGroup?: string;
  thumbnailUrl?: string;
  robloxUrl?: string;
  isVerified: boolean;
  isExclusive: boolean;
  discoveredAt: string;
  createdAt?: string;
}

interface AssetDetailModalProps {
  asset: Asset;
  isOpen: boolean;
  onClose: () => void;
}

export default function AssetDetailModal({ asset, isOpen, onClose }: AssetDetailModalProps) {
  const handleViewOnRoblox = () => {
    if (asset.robloxUrl) {
      window.open(asset.robloxUrl, '_blank');
    }
  };

  const handleDownloadAsset = () => {
    const downloadUrl = `https://assetdelivery.roblox.com/v1/asset/?id=${asset.assetId}`;
    window.open(downloadUrl, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-screen overflow-y-auto bg-discord-gray border-gray-700 text-white">
        <DialogHeader className="border-b border-gray-700 pb-4">
          <DialogTitle className="text-xl font-bold">Asset Details</DialogTitle>
        </DialogHeader>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              {/* Asset preview image */}
              <div className="w-full h-64 bg-gray-600 rounded-lg overflow-hidden mb-4">
                {asset.thumbnailUrl ? (
                  <img 
                    src={asset.thumbnailUrl} 
                    alt={asset.name}
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = `https://images.unsplash.com/photo-1591154669695-5f2a8d20c089?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=256`;
                    }}
                  />
                ) : (
                  <div className="w-full h-full bg-gray-600 flex items-center justify-center text-gray-400">
                    No Preview Available
                  </div>
                )}
              </div>
              
              {/* Asset Actions */}
              <div className="space-y-2">
                <Button 
                  onClick={handleViewOnRoblox}
                  className="w-full bg-discord-blurple hover:bg-blue-600"
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View on Roblox
                </Button>
                <Button 
                  onClick={handleDownloadAsset}
                  variant="secondary"
                  className="w-full bg-gray-700 hover:bg-gray-600"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download Asset File
                </Button>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-lg">{asset.name}</h4>
                <p className="text-discord-muted">by {asset.creator}</p>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-discord-muted">Asset ID:</span>
                  <span className="font-mono">{asset.assetId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-discord-muted">Created:</span>
                  <span>{asset.createdAt ? new Date(asset.createdAt).toLocaleDateString() : 'Unknown'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-discord-muted">Source Group:</span>
                  <span>{asset.sourceGroup || 'Unknown'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-discord-muted">Status:</span>
                  <Badge className={asset.isVerified ? "bg-success text-white" : "bg-warning text-black"}>
                    {asset.isVerified ? 'Verified' : 'Unverified'}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-discord-muted">Category:</span>
                  <span>{asset.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-discord-muted">Exclusive:</span>
                  <Badge className={asset.isExclusive ? "bg-error text-white" : "bg-gray-600 text-white"}>
                    {asset.isExclusive ? 'Yes' : 'No'}
                  </Badge>
                </div>
              </div>
              
              {asset.description && (
                <div className="pt-4 border-t border-gray-700">
                  <h5 className="font-medium mb-2">Description</h5>
                  <p className="text-sm text-discord-light">{asset.description}</p>
                </div>
              )}
              
              <div className="pt-4 border-t border-gray-700">
                <h5 className="font-medium mb-2">Discovery Timeline</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full"></div>
                    <span>Discovered {new Date(asset.discoveredAt).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-discord-blue rounded-full"></div>
                    <span>Posted to Discord webhook</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-warning rounded-full"></div>
                    <span>Verification {asset.isVerified ? 'completed' : 'in progress'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
