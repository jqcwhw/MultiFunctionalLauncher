import { Card, CardContent } from "@/components/ui/card";
import { Box, Star, Users, Zap } from "lucide-react";

interface Stats {
  totalAssets: number;
  newDiscoveries: number;
  activeGroups: number;
  webhookPosts: number;
  newAssetsToday: number;
  newDiscoveriesToday: number;
  webhookPostsToday: number;
}

interface StatsOverviewProps {
  stats?: Stats;
}

export default function StatsOverview({ stats }: StatsOverviewProps) {
  const defaultStats = {
    totalAssets: 0,
    newDiscoveries: 0,
    activeGroups: 5,
    webhookPosts: 0,
    newAssetsToday: 0,
    newDiscoveriesToday: 0,
    webhookPostsToday: 0,
  };

  const currentStats = stats || defaultStats;

  const statCards = [
    {
      title: "Total Assets",
      value: currentStats.totalAssets.toLocaleString(),
      change: `+${currentStats.newAssetsToday}`,
      changeLabel: "this hour",
      icon: Box,
      iconColor: "text-discord-blue",
      iconBg: "bg-discord-blue bg-opacity-20",
    },
    {
      title: "New Discoveries",
      value: currentStats.newDiscoveries,
      change: `+${currentStats.newDiscoveriesToday}`,
      changeLabel: "last 10 min",
      icon: Star,
      iconColor: "text-success",
      iconBg: "bg-success bg-opacity-20",
    },
    {
      title: "Active Groups",
      value: currentStats.activeGroups,
      change: "",
      changeLabel: "Big Games ecosystem",
      icon: Users,
      iconColor: "text-warning",
      iconBg: "bg-warning bg-opacity-20",
    },
    {
      title: "Webhook Posts",
      value: currentStats.webhookPosts,
      change: `+${currentStats.webhookPostsToday}`,
      changeLabel: "today",
      icon: Zap,
      iconColor: "text-discord-blurple",
      iconBg: "bg-discord-blurple bg-opacity-20",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <Card key={index} className="bg-discord-gray border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-discord-muted text-sm">{stat.title}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 ${stat.iconBg} rounded-lg flex items-center justify-center`}>
                <stat.icon className={`${stat.iconColor} text-xl h-6 w-6`} />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              {stat.change && (
                <span className="text-success">{stat.change}</span>
              )}
              <span className="text-discord-muted ml-1">{stat.changeLabel}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
