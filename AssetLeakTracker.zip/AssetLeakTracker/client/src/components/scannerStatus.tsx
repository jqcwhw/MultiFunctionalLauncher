import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ScannerStatusItem {
  id: string;
  source: string;
  isActive: boolean;
  lastScanAt?: string;
  nextScanAt?: string;
  errorCount: number;
  rateLimited: boolean;
}

interface ScannerStatusProps {
  statuses: ScannerStatusItem[];
}

export default function ScannerStatus({ statuses }: ScannerStatusProps) {
  const getStatusColor = (status: ScannerStatusItem) => {
    if (!status.isActive) return "bg-gray-500";
    if (status.rateLimited) return "bg-warning";
    if (status.errorCount > 0) return "bg-error";
    return "bg-success";
  };

  const getStatusText = (status: ScannerStatusItem) => {
    if (!status.isActive) return "Inactive";
    if (status.rateLimited) return "Rate Limited";
    if (status.errorCount > 0) return "Error";
    return "Active";
  };

  const getNextScanCountdown = () => {
    // Simple countdown - in real implementation, this would be calculated from nextScanAt
    const now = new Date();
    const seconds = 59 - now.getSeconds();
    const minutes = 1;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="bg-discord-gray border-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Scanner Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {statuses.length === 0 ? (
            <div className="text-center text-discord-muted py-4">
              No scanner status available
            </div>
          ) : (
            statuses.map((status) => (
              <div key={status.id} className="flex items-center justify-between">
                <span className="text-sm text-discord-muted">{status.source}</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 ${getStatusColor(status)} rounded-full`}></div>
                  <span className="text-xs">{getStatusText(status)}</span>
                </div>
              </div>
            ))
          )}
          
          {/* Default scanner sources if no data */}
          {statuses.length === 0 && (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm text-discord-muted">BIG Games Pets</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span className="text-xs">Active</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-discord-muted">BIG Games™</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span className="text-xs">Active</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-discord-muted">BIG Games Testing</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-warning rounded-full"></div>
                  <span className="text-xs">Rate Limited</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-discord-muted">Developer Accounts</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <span className="text-xs">149 Active</span>
                </div>
              </div>
            </>
          )}
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-700">
          <div className="flex items-center justify-between text-sm">
            <span className="text-discord-muted">Next scan in:</span>
            <span className="font-mono">{getNextScanCountdown()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
