import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Search, 
  Bell, 
  Users, 
  BarChart3, 
  Settings,
  PawPrint
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Asset Scanner", href: "/scanner", icon: Search },
  { name: "Alerts", href: "/alerts", icon: Bell, badge: 3 },
  { name: "Groups", href: "/groups", icon: Users },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-discord-gray border-r border-gray-700 flex flex-col">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-discord-blue to-discord-blurple rounded-lg flex items-center justify-center">
            <PawPrint className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-bold">PS99 Tracker</h1>
            <p className="text-xs text-discord-muted">Big Games Monitor</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <a
                    className={cn(
                      "flex items-center space-x-3 p-3 rounded-lg transition-colors",
                      isActive
                        ? "bg-discord-blurple text-white"
                        : "hover:bg-gray-700 text-discord-light hover:text-white"
                    )}
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.name}</span>
                    {item.badge && (
                      <span className="ml-auto bg-error text-white text-xs px-2 py-1 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      {/* Discord Status */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-2 text-sm">
          <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
          <span className="text-discord-light">Discord Connected</span>
        </div>
        <p className="text-xs text-discord-muted mt-1">Webhook active</p>
      </div>
    </div>
  );
}
