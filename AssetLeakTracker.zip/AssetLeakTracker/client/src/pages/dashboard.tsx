import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Sidebar from "@/components/sidebar";
import StatsOverview from "@/components/statsOverview";
import AssetCard from "@/components/assetCard";
import ScannerStatus from "@/components/scannerStatus";
import AssetDetailModal from "@/components/assetDetailModal";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";
import { FolderSync, Bell, Download, Settings, ExternalLink, TestTube } from "lucide-react";
import { apiRequest } from "@/lib/api";

interface Asset {
  id: string;
  assetId: string;
  name: string;
  creator: string;
  creatorId?: string;
  description?: string;
  category: string;
  sourceGroup?: string;
  thumbnailUrl?: string;
  robloxUrl?: string;
  isVerified: boolean;
  isExclusive: boolean;
  discoveredAt: string;
}

interface Discovery {
  id: string;
  assetId: string;
  discoveryType: string;
  discoveredAt: string;
  asset: Asset;
}

export default function Dashboard() {
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const { toast } = useToast();

  // WebSocket connection for real-time updates
  const { isConnected, lastMessage } = useWebSocket();

  // Fetch recent discoveries
  const { data: discoveries = [], isLoading: loadingDiscoveries, refetch: refetchDiscoveries } = useQuery({
    queryKey: ['/api/discoveries'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Fetch scanner status
  const { data: scannerStatuses = [], refetch: refetchStatus } = useQuery({
    queryKey: ['/api/scanner/status'],
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  // Fetch statistics
  const { data: stats, refetch: refetchStats } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: 30000,
  });

  // Handle real-time updates
  if (lastMessage) {
    const message = JSON.parse(lastMessage);
    
    if (message.type === 'new_asset') {
      toast({
        title: "New Asset Discovered!",
        description: `${message.data.name} by ${message.data.creator}`,
      });
      refetchDiscoveries();
      refetchStats();
    } else if (message.type === 'scanner_status' || message.type === 'stats_update') {
      refetchStatus();
      refetchStats();
    }
  }

  const handleManualScan = async () => {
    try {
      await apiRequest('POST', '/api/scanner/scan', { source: 'Manual Scan' });
      toast({
        title: "Scan Initiated",
        description: "Manual scan has been started successfully.",
      });
    } catch (error) {
      toast({
        title: "Scan Failed",
        description: "Failed to initiate manual scan.",
        variant: "destructive",
      });
    }
  };

  const handleTestWebhook = async () => {
    try {
      await apiRequest('POST', '/api/webhook/test', {});
      toast({
        title: "Webhook Test Sent",
        description: "Test message sent to Discord webhook successfully.",
      });
    } catch (error) {
      toast({
        title: "Webhook Test Failed",
        description: "Failed to send test message to Discord webhook.",
        variant: "destructive",
      });
    }
  };

  const handleExportData = async () => {
    try {
      const response = await fetch('/api/export/assets');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ps99-assets.json';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Export Successful",
        description: "Asset data has been exported successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export asset data.",
        variant: "destructive",
      });
    }
  };

  const filteredDiscoveries = discoveries.filter((discovery: Discovery) => 
    categoryFilter === "All" || discovery.asset.category === categoryFilter
  );

  const getLastScanTime = () => {
    if (!scannerStatuses.length) return "Never";
    const latestScan = scannerStatuses.reduce((latest, status) => 
      new Date(status.lastScanAt || 0) > new Date(latest.lastScanAt || 0) ? status : latest
    );
    return latestScan.lastScanAt ? new Date(latestScan.lastScanAt).toLocaleString() : "Never";
  };

  return (
    <div className="min-h-screen flex bg-discord-dark text-white">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <header className="bg-discord-gray border-b border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Asset Discovery Dashboard</h2>
              <p className="text-discord-muted">Real-time monitoring of PS99 and Big Games content</p>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-success animate-pulse' : 'bg-error'}`}></div>
                <span className="text-sm font-medium">
                  {isConnected ? 'Scanner Active' : 'Scanner Offline'}
                </span>
              </div>
              <div className="text-sm text-discord-muted">
                Last scan: {getLastScanTime()}
              </div>
              <Button 
                onClick={handleManualScan}
                className="bg-discord-blurple hover:bg-blue-600"
              >
                <FolderSync className="mr-2 h-4 w-4" />
                Scan Now
              </Button>
            </div>
          </div>
        </header>

        {/* Stats Overview */}
        <div className="p-6 border-b border-gray-700">
          <StatsOverview stats={stats} />
        </div>

        {/* Main Content Grid */}
        <div className="flex-1 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
            
            {/* Recent Discoveries Panel */}
            <div className="lg:col-span-2">
              <Card className="bg-discord-gray border-gray-700 h-full">
                <CardHeader className="border-b border-gray-700">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold">Recent Discoveries</CardTitle>
                    <Tabs value={categoryFilter} onValueChange={setCategoryFilter}>
                      <TabsList className="bg-gray-700">
                        <TabsTrigger value="All" className="data-[state=active]:bg-discord-blurple">All</TabsTrigger>
                        <TabsTrigger value="Pet" className="data-[state=active]:bg-discord-blurple">Pets</TabsTrigger>
                        <TabsTrigger value="Egg" className="data-[state=active]:bg-discord-blurple">Items</TabsTrigger>
                        <TabsTrigger value="Exclusive" className="data-[state=active]:bg-discord-blurple">Eggs</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                </CardHeader>
                
                <CardContent className="p-6">
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {loadingDiscoveries ? (
                        <div className="text-center text-discord-muted py-8">
                          Loading discoveries...
                        </div>
                      ) : filteredDiscoveries.length === 0 ? (
                        <div className="text-center text-discord-muted py-8">
                          No discoveries found
                        </div>
                      ) : (
                        filteredDiscoveries.map((discovery: Discovery) => (
                          <AssetCard
                            key={discovery.id}
                            asset={discovery.asset}
                            discoveryType={discovery.discoveryType}
                            onClick={() => setSelectedAsset(discovery.asset)}
                          />
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
            
            {/* Right Sidebar */}
            <div className="space-y-6">
              
              {/* Scanner Status */}
              <ScannerStatus statuses={scannerStatuses} />
              
              {/* Quick Actions */}
              <Card className="bg-discord-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={handleTestWebhook}
                    className="w-full bg-discord-blurple hover:bg-blue-600"
                  >
                    <TestTube className="mr-2 h-4 w-4" />
                    Test Discord Webhook
                  </Button>
                  <Button 
                    onClick={handleExportData}
                    variant="secondary"
                    className="w-full bg-gray-700 hover:bg-gray-600"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Export Asset Data
                  </Button>
                  <Button 
                    variant="secondary"
                    className="w-full bg-gray-700 hover:bg-gray-600"
                  >
                    <FolderSync className="mr-2 h-4 w-4" />
                    Update User IDs
                  </Button>
                  <Button 
                    variant="secondary"
                    className="w-full bg-warning hover:bg-orange-500 text-black"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Scanner Settings
                  </Button>
                </CardContent>
              </Card>
              
              {/* Discord Activity */}
              <Card className="bg-discord-gray border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">Discord Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {discoveries.slice(0, 3).map((discovery: Discovery) => (
                      <div key={discovery.id} className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-success bg-opacity-20 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Bell className="h-4 w-4 text-success" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm">Posted {discovery.asset.name} discovery</p>
                          <p className="text-xs text-discord-muted">
                            {new Date(discovery.discoveredAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))}
                    {discoveries.length === 0 && (
                      <div className="text-center text-discord-muted py-4 text-sm">
                        No recent activity
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Asset Detail Modal */}
      {selectedAsset && (
        <AssetDetailModal
          asset={selectedAsset}
          isOpen={!!selectedAsset}
          onClose={() => setSelectedAsset(null)}
        />
      )}
    </div>
  );
}
